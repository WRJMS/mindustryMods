const 高能量xen液体 = extendContent(Liquid,"高能量xen液体",{})
高能量xen液体.heatCapacity = 1.1;
高能量xen液体.explosiveness = 100;
高能量xen液体.viscosity = 0.5;
高能量xen液体.color = Color.valueOf("#CAEEFF")
高能量xen液体.lightColor = Color.valueOf("#CAEEFF")

const 相位xen液体 = extendContent(Liquid,"相位xen液体",{})
相位xen液体.heatCapacity = 1.5;
相位xen液体.explosiveness = 1000;
相位xen液体.viscosity = 0.5;
相位xen液体.temperature = 0
相位xen液体.color = Color.valueOf("#CAEEFF")
相位xen液体.lightColor = Color.valueOf("#CAEEFF")

const xen液体 = extendContent(Liquid,"xen液体",{})
xen液体.heatCapacity = 0.2;
xen液体.temperature = 2;
xen液体.viscosity = 0.725;
xen液体.color = Color.valueOf("#AEDFFF")

const 复合钢 = extendContent(Item,"复合钢",{});
复合钢.color = Color.valueOf("cedbe3")
复合钢.type = ItemType.material;

const 铱板 = extendContent(Item,"铱板",{});
铱板.color = Color.valueOf("f7f7f7")
铱板.type = ItemType.material;

const 致密合金 = extendContent(Item,"致密合金",{});
致密合金.color = Color.valueOf("#151C23")
致密合金.type = ItemType.material;

const darkenergy = extendContent(Item,"darkenergy",{});
darkenergy.color = Color.valueOf("9400d3");
darkenergy.explosiveness = 10;
darkenergy.radioactivity = 25;
darkenergy.localizedName = "暗能量";
darkenergy.description = "最强大的能量，被用作于武器";

//if(typeof(require) !== "undefined"){ 
	require("items/JS");
	require("blocks/large-zate-factory");
	require("blocks/Cafac");
	require("blocks/穿刺炮");
	require("blocks/laserWall");
	require("blocks/反物质炮");
	require("blocks/电磁脉冲炮");
	require("blocks/liquid-mass-driver");
	require("blocks/SelfChargeAbleTurret");
	require("blocks/FinalTurret");
	
	require("blocks/chargewall");
	require("blocks/脉冲近防炮");
	require("blocks/液压机");
	require("blocks/巨浪炮");
	require("blocks/升能器");
	require("blocks/相位液体工厂");
	require("blocks/点防御激光器");
	require("blocks/冲击液体工厂");
	require("blocks/大型相织布工厂");
	require("blocks/对空炮");
	require("blocks/粉沙机");
	require("blocks/附着炮");
	require("blocks/复合钢工厂");
	require("blocks/热电炮");
	require("blocks/H2O固化器");
	require("blocks/零位能量反应堆");
	require("blocks/多重硅冶炼厂");
	require("blocks/岩浆发电机");
	require("blocks/小型铱工厂");
	//require("units/坍缩者");
	require("blocks/激光");
	require("blocks/闪电炮");
	require("blocks/聚变爆破器");
	require("blocks/TowardGate");
	require("Functions/SpriteDrawf");
	require("blocks/原子炮");
	require("blocks/轨道炮");
	require("blocks/ActiveSuperWeapon");
	require("blocks/粒子对撞机");
	//require("blocks/OutCoreItemsLoader");
	require("blocks/effect/重构器");
	require("blocks/effect/JumpTile");
	
	require("mechs/机甲-掠夺者");
	require("mechs/机甲-Liv");
	require("units/ruin");
//}
 

