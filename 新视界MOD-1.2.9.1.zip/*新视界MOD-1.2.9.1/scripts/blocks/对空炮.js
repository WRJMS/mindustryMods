const 震慑2 = extendContent(StatusEffect,"震慑2",{});
震慑2.damageMultiplier = 1.125;
震慑2.damage = 3;
震慑2.armorMultiplier = 1.125;
震慑2.speedMultiplier = 0.75;
震慑2.color = Color.valueOf("#dd7538");
震慑2.effect = newEffect(12,e => {
	Draw.color(Color.valueOf("#dd7538"),Color.valueOf("#FFF7CC"),e.fin());
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 0.425);
    }}) 
    Angles.randLenVectors(e.id, 20, 64 * e.fin(), e.rotation, 360,d);
    Draw.color(Color.valueOf("#404040"),Color.valueOf("#787878"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 3);
    }}) 
    Angles.randLenVectors(e.id, 10, 1 + 40 * e.fin(), e.rotation, 360,c);
             });
震慑2.color = Color.valueOf("#B4E6FF");



const 光矛分裂 = extend(BasicBulletType,{})
光矛分裂.speed = 2,
光矛分裂.splashDamageRadius = 10,
光矛分裂.splashDamage = 5,
光矛分裂.bulletWidth = 10,
光矛分裂.pierce = true,
光矛分裂.bulletHeight = 10,
光矛分裂.bulletShrink = 0,
光矛分裂.lifetime =15,
光矛分裂.backColor = Color.valueOf("d7d77f"),
光矛分裂.frontColor = Color.valueOf("fef8c4"),
光矛分裂.despawnEffect = Fx.none,
光矛分裂.hitEffect = Fx.none



const 尾迹 = newEffect(25,e => {
	Draw.color(Color.valueOf("#C2FF83"),Color.valueOf("#D9FFB4"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 光矛2 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
            Effects.effect(尾迹,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
        }
        }
   })
光矛2.speed = 10,
光矛2.damage = 150,
光矛2.knockback = 0.2,
光矛2.splashDamageRadius = 40,
光矛2.splashDamage = 125,
光矛2.bulletWidth = 15,
光矛2.bulletHeight = 75,
光矛2.drag = 0,
光矛2.collidesTiles = true,
光矛2.pierce = false,
光矛2.collides = true,
光矛2.collidesAir = true,
光矛2.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("C2FF83"),Color.valueOf("D9FFB4"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛2.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("C2FF83"),Color.valueOf("D9FFB4"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
光矛2.fragBullets = 5,
光矛2.fragBullet = 光矛分裂,
光矛2.ammoMultiplier = 1,
光矛2.homingPower = 0,
光矛2.homingRange = 300,
光矛2.lifetime = 50,
光矛2.explodeRange = 100,
光矛2.bulletSprite = "新视界-矛子弹";
光矛2.backColor = Color.valueOf("C2FF83"),
光矛2.trailColor = Color.valueOf("C2FF83"),
光矛2.frontColor = Color.valueOf("D9FFB4"),
光矛2.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("C2FF83"),Color.valueOf("D9FFB4"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
    光矛2.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("C2FF83"),Color.valueOf("D9FFB4"),e.fin());
	Lines.stroke(e.fout() * 1.125);
    Lines.circle(e.x, e.y, e.fin() * 37);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 8);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 12, 1 + 40 * e.fin(), e.rotation, 100,d);
        });
        

//-------------------------------------
        const 尾迹2 = newEffect(25,e => {
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 光矛1 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
            Effects.effect(尾迹2,Color.valueOf("696AFF00"), b.x, b.y, b.rot());
        }
        }
   })
光矛1.speed = 10,
光矛1.damage = 225,
光矛1.knockback = 0.2,
光矛1.bulletWidth = 15,
光矛1.bulletHeight = 75,
光矛1.drag = 0,
光矛1.collidesTiles = true,
光矛1.pierce = false,
光矛1.collides = true,
光矛1.collidesAir = true,
光矛1.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛1.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
光矛1.ammoMultiplier = 1,
光矛1.homingPower = 0,
光矛1.homingRange = 300,
光矛1.lifetime = 50,
光矛1.explodeRange = 100,
光矛1.bulletSprite = "新视界-矛子弹";
光矛1.backColor = Color.valueOf("696AFF"),
光矛1.trailColor = Color.valueOf("696AFF"),
光矛1.frontColor = Color.valueOf("a5b8fa"),
光矛1.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
        
        
光矛1.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 8);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
        });
//-------------------
        const 尾迹3 = newEffect(25,e => {
	Draw.color(Color.valueOf("#FF986D"),Color.valueOf("#FFC4AA"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 光矛3 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
            Effects.effect(尾迹3,Color.valueOf("FF986D00"), b.x, b.y, b.rot());
        }
        }
   })
光矛3.speed = 10,
光矛3.damage = 0,
光矛3.knockback = 0.2,
光矛3.splashDamageRadius = 64,
光矛3.splashDamage = 225,
光矛3.bulletWidth = 15,
光矛3.bulletHeight = 75,
光矛3.drag = 0,
光矛3.collidesTiles = true,
光矛3.pierce = false,
光矛3.collides = true,
光矛3.collidesAir = true,
光矛3.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("FF986D"),Color.valueOf("FFC4AA"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛3.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("FF986D"),Color.valueOf("FFC4AA"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
光矛3.ammoMultiplier = 1,
光矛3.homingPower = 0,
光矛3.homingRange = 300,
光矛3.lifetime = 50,
光矛3.explodeRange = 100,
光矛3.bulletSprite = "新视界-矛子弹";
光矛3.backColor = Color.valueOf("FF986D"),
光矛3.trailColor = Color.valueOf("FF986D"),
光矛3.frontColor = Color.valueOf("FFC4AA"),
光矛3.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("FF986D"),Color.valueOf("FFC4AA"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
        光矛3.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("FF986D"),Color.valueOf("FFC4AA"),e.fin());
	Lines.stroke(e.fout() * 1.725);
    Lines.circle(e.x, e.y, e.fin() * 14);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 12, 1 + 40 * e.fin(), e.rotation, 100,d);
        });
//-------------------
const 尾迹4 = newEffect(25,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 光矛4 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
            Effects.effect(尾迹4,Color.valueOf("dd753800"), b.x, b.y, b.rot());
        }
        }
   })
光矛4.speed = 15,
光矛4.damage = 175,
光矛4.knockback = 0.2,
光矛4.bulletWidth = 15,
光矛4.bulletHeight = 75,
光矛4.drag = 0,
光矛4.collidesTiles = true,
光矛4.pierce = true,
光矛4.collides = true,
光矛4.collidesAir = true,
光矛4.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛4.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
光矛4.ammoMultiplier = 1,
光矛4.homingPower = 0,
光矛4.homingRange = 300,
光矛4.lifetime = 30,
光矛4.status = 震慑2;
光矛4.statusDuration = 90;
光矛4.explodeRange = 100,
光矛4.bulletSprite = "新视界-矛子弹";
光矛4.backColor = Color.valueOf("dd7538"),
光矛4.trailColor = Color.valueOf("#FFF4BC"),
光矛4.frontColor = Color.valueOf("FFF4BC"),
光矛4.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
光矛4.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
    const d = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.275, 45);
            }})
            Angles.randLenVectors(e.id, 10, 1 + e.fin() * 40,d);
        });
//------------------
const 尾迹5 = newEffect(17.25,e => {
	Draw.color(Color.valueOf("abdbff"),Color.valueOf("F0f8ff"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 30);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 30 * e.fin(),e.rotation, 0,d);
        });

const 光矛5 = extend(BasicBulletType,{
        update(b){
        	const target = Units.closestTarget(b.getTeam(), b.x,b.y,500)
            if (target != null) {
                b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.4));
                }
        if(b.timer.get(1,0.5)){
            Effects.effect(尾迹5,Color.valueOf("abdbff00"), b.x, b.y, b.rot());
        }
        }
   })
光矛5.speed = 8,
光矛5.damage = 40,
光矛5.knockback = 0.2,
光矛5.bulletWidth = 8.725,
光矛5.bulletHeight = 40,
光矛5.drag = 0,
光矛5.reloadMultiplier = 7.5,
光矛5.ammoMultiplier = 6,
光矛5.collidesTiles = true,
光矛5.pierce = false,
光矛5.collides = true,
光矛5.collidesAir = true,
光矛5.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("abdbff"),Color.valueOf("F0f8ff"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛5.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("abdbff"),Color.valueOf("F0f8ff"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
光矛5.homingRange = 300,
光矛5.lifetime = 55,
光矛5.explodeRange = 100,
光矛5.bulletSprite = "新视界-尖子弹";
光矛5.backColor = Color.valueOf("abdbff"),
光矛5.trailColor = Color.valueOf("#F0f8ff"),
光矛5.frontColor = Color.valueOf("F0f8ff"),
光矛5.despawnEffect = Fx.hitLancer
光矛5.hitEffect = Fx.hitLancer

const 尾迹6 = newEffect(25,e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("FFFDC5"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 2.725);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 50);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 光矛6 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
        Lightning.create(b.getTeam(),Color.valueOf("FFFDC5"), 17.5, b.x, b.y, b.rot(), 15);         
            Effects.effect(尾迹6,Color.valueOf("dd753800"), b.x, b.y, b.rot());
        }
        if(Mathf.chance(Time.delta() * 0.08)){
        	Lightning.create(b.getTeam(),Color.valueOf("FFF98C"), 80, b.x, b.y, b.rot() - 180, 30);         
        }
        }
   })
光矛6.speed = 7.5,
光矛6.damage = 0,
光矛6.knockback = 0,
光矛6.bulletWidth = 15,
光矛6.bulletHeight = 75,
光矛6.drag = 0,
光矛6.collidesTiles = false,
光矛6.pierce = false,
光矛6.collides = false,
光矛6.collidesAir = false,
光矛6.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("FFF98C"),Color.valueOf("FFFDC5"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光矛6.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("FFFDC5"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
光矛6.ammoMultiplier = 1,
光矛6.homingPower = 0,
光矛6.homingRange = 300,
光矛6.lifetime = 60,
光矛6.explodeRange = 100,
光矛6.bulletSprite = "新视界-矛子弹";
光矛6.backColor = Color.valueOf("FFF98C"),
光矛6.trailColor = Color.valueOf("FFFDC5"),
光矛6.frontColor = Color.valueOf("FFFDC5"),
光矛6.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("FFFDC5"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
光矛6.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("FFFDC5"),e.fin());
    const d = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.275, 45);
            }})
            Angles.randLenVectors(e.id, 10, 1 + e.fin() * 40,d);
        });
        

const 对空炮= extendContent(BurstTurret,"对空炮",{});
对空炮.ammo(Items.plastanium,光矛2,Items.titanium,光矛1,Items.blastCompound,光矛3,Items.phasefabric,光矛4,Items.graphite,光矛5,Items.surgealloy,光矛6);
对空炮.ammoUseEffect = Fx.shootBigSmoke