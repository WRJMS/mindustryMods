

const 大型相织布工厂 = extendContent(GenericSmelter,"大型相织布工厂",{
    draw(tile){
        Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
        const entity = tile.ent();
        Draw.color(Pal.accent);
        Draw.alpha(entity.warmup);
		Lines.lineAngleCenter(
                tile.drawx() + Mathf.sin(entity.totalProgress, 6, 3),
                tile.drawy(), 90, 10);  
        Draw.reset();
        Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),90 + tile.ent().totalProgress * 1.25)
        Draw.rect(this.region,tile.drawx(),tile.drawy())
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name + "-bottom"),
            Core.atlas.find(this.name),
        ];
    }
});
大型相织布工厂.craftEffect = Fx.smeltsmoke;