const effectColor = Color.valueOf("B4CFFF");
const effectColor2 = Color.valueOf("ffffff");
const width = 5;
const maxCooled = 0.8;
function drawTrait(picture, x, y, width, length, rotation){
	var oy = 17 / 63 * length ;
	Draw.rect(Core.atlas.find(picture), x, y - oy + length / 2, width, length, width / 2, oy, rotation - 90);
}
const ballEffect = newEffect(20, e => {
	Draw.color(effectColor, effectColor2,e.fin());
    const d = new Floatc2({get(x, y){
	    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 50 * e.fin(), e.rotation, 25,d);
    const c = new Floatc2({get(x,y){
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
	}});
	Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,c);
});
const ballEffect2 = newEffect(20, e => {
	Draw.color(effectColor, effectColor2,e.fin());
    const d = new Floatc2({get(x,y){
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
	}});
	Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
});
const energyBall = extend(BasicBulletType,{
	update(b){
		if(b.time() > 2){
			Effects.effect(newEffect(20,e => {
				Draw.color(effectColor2, effectColor, 0.4 + e.fin() * 1.35);
				//Lines.stroke(e.fout() * 3);
				//Lines.lineAngleCenter(e.x, e.y, e.rotation, e.fout() * 22 + 24);
				const si = this.bulletWidth * e.fout();
				drawTrait("bullet-back", e.x, e.y, si, this.bulletHeight, e.rotation);
			}),effectColor, b.x, b.y, b.rot());
		}
	},
	draw(b){}
})
energyBall.damage = 60;
energyBall.bulletShrink = 0;
energyBall.backColor = effectColor;
energyBall.frontColor = effectColor2;
energyBall.bulletWidth = 9;
energyBall.bulletHeight = 68;
energyBall.lifetime = 70;
energyBall.speed = 7;
energyBall.despawnEffect = ballEffect2;
energyBall.hitEffect = ballEffect;

//炮台基本内容配置▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const SelfChargeAbleTurret = extendContent(PowerTurret,"chargeCooledTurret",{
	drawLayer(tile){
        this.super$drawLayer(tile);
    },
    setBars(){
		this.super$setBars();
		this.bars.add("Chargerogress", func(entity => {
			var bar = new Bar(prov( () => "Chargerogress"), prov( () => effectColor), floatp( () => entity.chargeProgress / maxCooled ));
			return bar;
		}));
	},
	update(tile){
		this.super$update(tile);
		const entity = tile.ent();
		if(entity.target != null && entity.power.status > 0.3){
			entity.backNor = 0;
		}else{
			entity.backNor += 1;
			if (entity.backNor >= 60){
				entity.chargeProgress = Mathf.lerp(entity.chargeProgress,0, 0.0075);
			}
		}
	},
	updateShooting(tile){
		const entity = tile.ent();
		const realReload = this.reload * (1 - entity.chargeProgress)
		if(entity.reload >= realReload){
			const type = this.peekAmmo(tile);
			this.shoot(tile, type);
			entity.reload = 0;
		}else{
			entity.reload += tile.entity.delta() * this.peekAmmo(tile).reloadMultiplier * this.baseReloadSpeed(tile);
		}
		const maxUsed = 0.2
		//const maxUsed = consumes.<ConsumeLiquidBase>get(ConsumeType.liquid).amount;
		const liquid = entity.liquids.current();
		const used = Math.min(Math.min(entity.liquids.get(liquid), maxUsed * Time.delta()), Math.max(0, ((realReload - entity.reload) / this.coolantMultiplier) / liquid.heatCapacity)) * this.baseReloadSpeed(tile);
		entity.reload += used * liquid.heatCapacity * this.coolantMultiplier;
		entity.liquids.remove(liquid, used);
		if(Mathf.chance(0.06 * used)){
			Effects.effect(this.coolEffect, tile.drawx() + Mathf.range(this.size * Vars.tilesize / 2), tile.drawy() + Mathf.range(this.size * Vars.tilesize / 2));
		}
	},
	shoot(tile,type){
		const entity = tile.ent();
		entity.recoil = this.recoil;
		entity.heat = 0.8;
		const len = this.size / 2 * Vars.tilesize + type.bulletHeight / 2;
		const trx1 = Angles.trnsx(entity.rotation, len);
        const try1 = Angles.trnsy(entity.rotation, len);
		this.tr.trns(entity.rotation, this.size / 2 * Vars.tilesize, 0);
		for(var i = 0; i < this.shots; i++){
			Bullet.create(type, tile.entity, tile.getTeam(), tile.drawx() + trx1, tile.drawy() + try1, entity.rotation + Mathf.range(entity.chargeProgress * 12));
		}
		entity.chargeProgress += 0.075 * entity.power.status;
		if(entity.chargeProgress > maxCooled)entity.chargeProgress = maxCooled;
		this.effects(tile);
		this.shootSound.at(tile,Mathf.random(1, 1));
		this.useAmmo(tile);
	}
})
SelfChargeAbleTurret.shootCone = 5;
SelfChargeAbleTurret.powerUse = 5;
SelfChargeAbleTurret.health = 1250;
SelfChargeAbleTurret.recoil = 4;
SelfChargeAbleTurret.size = 3;
SelfChargeAbleTurret.shots = 2;
SelfChargeAbleTurret.shootCone = 10;
SelfChargeAbleTurret.expanded = true;
SelfChargeAbleTurret.range = 320;
SelfChargeAbleTurret.heatColor = effectColor;
SelfChargeAbleTurret.reload = 85;
SelfChargeAbleTurret.shootSound = Sounds.laser;
SelfChargeAbleTurret.shootType = energyBall;
SelfChargeAbleTurret.entityType=prov(()=>extend(Turret.TurretEntity,{
	getchargeProgress(){return this._chargeProgress},
	setchargeProgress(value){this._chargeProgress = value},
	_chargeProgress:0,
	getbackNor(){return this._backNor},
	setbackNor(value){this._backNor = value},
	_backNor:0
}));
SelfChargeAbleTurret.shootEffect = ballEffect;
SelfChargeAbleTurret.smokeEffect = newEffect(25,e => {
	Draw.color(effectColor, effectColor2,e.fin());
	Drawf.tri(e.x, e.y, 4, 28 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 4, 28 * e.fout(), e.rotation + 270);
});
 