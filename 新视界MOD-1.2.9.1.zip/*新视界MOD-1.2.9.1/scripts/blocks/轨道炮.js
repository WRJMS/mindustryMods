
const 尾迹轨道 = newEffect(25,e => {
	Draw.color(Color.valueOf("#99CFFF"),Color.valueOf("#CDE7FF"),e.fin());
                const d = new Floatc2({get(x, y){
                	Lines.stroke(e.fout() * 3.125);
        Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 8 + 45);
    }}) 
    Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
        });

const 轨道炮激光 = extend(BasicBulletType,{
        update(b){
        if(b.timer.get(1,1)){
        
            Effects.effect(尾迹轨道,Color.valueOf("dd753800"), b.x, b.y, b.rot());
        }
        if(Mathf.chance(Time.delta() * 0.04)){
        	Lightning.create(b.getTeam(),Color.valueOf("99CFFF"), 17.5, b.x, b.y, b.rot(), 10);         
        }
        }
   })
轨道炮激光.speed = 10,
轨道炮激光.damage = 50,
轨道炮激光.splashDamageRadius = 40,
轨道炮激光.splashDamage = 50,
轨道炮激光.knockback = 0,
轨道炮激光.bulletWidth = 3.425,
轨道炮激光.bulletHeight = 50,
轨道炮激光.drag = 0,
轨道炮激光.collidesTiles = true,
轨道炮激光.pierce = true,
轨道炮激光.collides = true,
轨道炮激光.collidesAir = true,
轨道炮激光.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("99CFFF"),Color.valueOf("CDE7FF"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
轨道炮激光.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("99CFFF"),Color.valueOf("CDE7FF"),e.fin());
	const d = new Floatc2({get(x,y){
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
            const c = new Floatc2({get(x, y){
         Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
    }}) 
    Lines.stroke(e.fout() * 2.725);
    Angles.randLenVectors(e.id, 10, 1+48 * e.fin(),e.rotation, 0,c);
        });
        
轨道炮激光.ammoMultiplier = 1,
轨道炮激光.homingPower = 0,
轨道炮激光.homingRange = 300,
轨道炮激光.lifetime = 40,
轨道炮激光.bulletSprite = "新视界-波束子弹";
轨道炮激光.backColor = Color.valueOf("99CFFF"),
轨道炮激光.trailColor = Color.valueOf("99CFFF"),
轨道炮激光.frontColor = Color.valueOf("CDE7FF"),
轨道炮激光.despawnEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("99CFFF"),Color.valueOf("CDE7FF"),e.fin());
	const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 30 * e.fin(), e.rotation, 360,d);
    });
轨道炮激光.hitEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("99CFFF"),Color.valueOf("CDE7FF"),e.fin());
	Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 60);
    Lines.stroke(e.fout() * 1.75);
    Lines.circle(e.x, e.y, e.fin() * 45);
    const d = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.275, 45);
            }})
            Angles.randLenVectors(e.id, 10, 1 + e.fin() * 40,d);
            Draw.color(Color.valueOf("#99CFFF"));
    Fill.circle(e.x, e.y, e.fin() * 5);
    Draw.color(Color.valueOf("#99CFFF"),Color.valueOf("#CDE7FF"),e.fin());
    Fill.circle(e.x, e.y, e.fin() * 3);
        });
        

const 轨道炮= extendContent(ChargeTurret,"轨道炮",{});
轨道炮.shootType = 轨道炮激光;
轨道炮.chargeBeginEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("#99CFFF"));
    Fill.circle(e.x, e.y, e.fin() * 5);
    Draw.color(Color.valueOf("#99CFFF"),Color.valueOf("#CDE7FF"),e.fin());
    Fill.circle(e.x, e.y, e.fin() * 3);
});

轨道炮.chargeEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("#99CFFF"),Color.valueOf("#CDE7FF"),e.fin());
    
    
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 7, 1 + 40 * e.fout(), e.rotation, 270,d);
});