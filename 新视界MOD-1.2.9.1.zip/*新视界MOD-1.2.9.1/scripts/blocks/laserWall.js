
/*const AtktmpColor = Color();
const Atkcolors = [Color.valueOf("#A6D2FF55"), Color.valueOf("#B3DBFF"), Color.valueOf("#DDF0FF"), Color.valueOf("ffffff")];
const Atktscales = [1,1,1,1];
const Atkstrokes = [1,0.5,0.3];
const Atklenscales = [1,1,1,1];
const attackBullet = extend(BasicBulletType,{
    update(b){
    	if(b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), Fx.hitLancer, b.x, b.y, b.rot(), this.lifetime);
            }
    },
    draw(b){
            const baseLen = this.lifetime;
			Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
	        for(var s = 0; s < Atkcolors.length; s++){
            Draw.color(AtktmpColor.set(Atkcolors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
            for(var i = 0; i < Atktscales.length; i++){
            Lines.stroke((12 + Mathf.absin(Time.time(), 0.8, 1.5)) * b.fout() * Atkstrokes[s] * Atktscales[i]);
            Lines.lineAngle(b.x, b.y, b.rot(), baseLen * Atklenscales[i]);
            }
        }
        Draw.reset();
    }
})
attackBullet.lifetime = 104;
attackBullet.speed = 0.00001;
attackBullet.damage = 50;
attackBullet.despawnEffect = Fx.none;*/

const laserWallHit = newEffect(25,e => {
	Draw.color(Color.valueOf("#B3DBFF"));
    Fill.circle(e.x, e.y, e.fout() * 7);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 3.75)
})


const laserWall = extendContent(ItemBridge, "laserWall", {
    linkValid(tile, other, checkDouble){
        if(other == null || tile == null || other == tile) return false;
        if(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow(this.range + 0.5, 2)) return false;
        return other.block() == this && (!checkDouble || other.ent().link != tile.pos());
    },
    drawPlace(x, y, rotation, valid) {
        Draw.color(Pal.placing);
        Lines.stroke(1.0);
        Lines.dashCircle(x * Vars.tilesize + 4, y * Vars.tilesize + 4, this.range * Vars.tilesize);

        
        link = this.findLink(x, y);
        if (link != null) {
            Lines.dashLine(x * Vars.tilesize + 4, y * Vars.tilesize + 4, link.drawx(), link.drawy(), this.range);
            const angle = Math.atan2(y - link.y, x - link.x);
            Draw.rect("bridge-arrow", 
            (link.drawx() +  Math.cos(angle)) * Vars.tilesize, 
            (link.drawy() + Math.sin(angle)) * Vars.tilesize, 
            angle * 180 / 3.1415);
        }
        
        Draw.reset();
    },
    drawConfigure(tile) {
        const entity = tile.ent();
        
        Draw.color(Pal.placing);
        Lines.stroke(1.0);
        Lines.dashCircle(tile.drawx(), tile.drawy(), this.range * Vars.tilesize);

        Draw.reset();

        Draw.color(Pal.accent);
        Lines.stroke(1.0);
        Lines.square(tile.drawx(), tile.drawy(),
        tile.block().size * Vars.tilesize / 2.0 + 1.0);
		const other = Vars.world.tile(entity.link);
        if(!this.linkValid(tile, other)) return;
        const ang = entity.angleTo(other);
        Draw.color(Color.valueOf("#2A2E35"));
        Drawf.tri(tile.drawx(), tile.drawy() - 16, 6.5, 10.5, ang);
        Draw.color(Color.valueOf("#A0CCFF75"));
        Draw.alpha(entity.power.status / 2.25 + 0.25);
        Draw.blend(Blending.additive);
        Drawf.tri(tile.drawx(), tile.drawy() - 16, 4, 8, ang);
        Draw.reset();
        Draw.blend();
        
        Draw.color(Pal.accent);
        Lines.stroke(1.0);
        Lines.square(tile.drawx(), tile.drawy(),
        tile.block().size * Vars.tilesize / 2.0 + 1.0);
		Draw.color(Pal.place);
		Lines.square(other.drawx(), other.drawy(),other.block().size * Vars.tilesize / 2.0 );
        Draw.reset();
    },
    drawLayer(tile) {
        const entity = tile.ent();
        const other = Vars.world.tile(entity.link);
        if(!this.linkValid(tile, other)) return;
        const centerx = (tile.drawx() + other.drawx()) / 2;
        const centery = (tile.drawy() + other.drawy()) / 2;
        const ang = entity.angleTo(other);
        Draw.color(Color.valueOf("#A0CCFF75"));
        Draw.alpha(entity.power.status / 2.25 + 0.25);
        if(entity.power.status > 0.5)Draw.blend(Blending.additive);
        Lines.stroke(1.125);
        Lines.lineAngleCenter(centerx,centery, ang, Mathf.dst(tile.drawx(), tile.drawy(),other.drawx(), other.drawy()))
        Draw.alpha(entity.power.status / 1.725);
		Lines.circle(tile.drawx(), tile.drawy(), 2.68 + Mathf.absin(Time.time(), 4, 1.125));
        Draw.alpha(entity.power.status / 2.25 + 0.75);
        Fill.circle(tile.drawx(), tile.drawy(), 1.75);
        Fill.circle(other.drawx(), other.drawy(), 1.25);
        Draw.reset();
        Draw.blend();
    },
    update(tile){
		const entity = tile.ent();
        const other = Vars.world.tile(entity.link);
        if(!this.linkValid(tile, other)) return;
        const ang = entity.angleTo(other);
        const dstR = Mathf.dst(tile.drawx(), tile.drawy(),other.drawx(), other.drawy()) / Vars.tilesize;
        const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(),this.range * Vars.tilesize)
        if (target != null) {
	        if(entity.timer.get(1,2) && entity.power.status > 0.5){
				Lightning.create(tile.getTeam(),Color.valueOf("A0CCFF"), 50, tile.drawx(), tile.drawy(), ang, dstR);         
				Lightning.create(tile.getTeam(),Color.valueOf("A0CCFF"), 50, other.drawx(), other.drawy(), ang - 180, dstR);         
			}
        }
	}
});
