const colorA = Color.valueOf("#BEDBFF");
const colorB = Color.valueOf("#D4EBFF");
const colorC = Color.valueOf("#A7B3FF");
const colorD = Color.valueOf("#91BDFF");
const colorE = Color.valueOf("#E0F2FF");
const wid = 1.25
const len = 2.125
const lightningGunRange = 280;

const lightningGunLaser = extend(BasicBulletType,{
		draw(b){
			
			const ang = b.rot();
			
			const trx1 = b.x + Angles.trnsx(ang - 90, len);
	        const try1 = b.y + Angles.trnsy(ang - 90, len);
			const trx2 = b.x + Angles.trnsx(ang - 90, len * 2);
	        const try2 = b.y + Angles.trnsy(ang - 90, len * 2);
	
			const trxa1 = b.x + Angles.trnsx(ang + 90, len);
			const trya1 = b.y + Angles.trnsy(ang + 90, len);
			const trxa2 = b.x + Angles.trnsx(ang + 90, len * 2);
			const trya2 = b.y + Angles.trnsy(ang + 90, len * 2);
			
			const trnx = Angles.trnsx(ang, len * 1.1);
			const trny = Angles.trnsy(ang, len * 1.1);
			
			const target = Units.closestTarget(b.getTeam(), b.x,b.y,lightningGunRange);
			if(target != null){
				if(Angles.angleDist(b.angleTo(target), b.rot()) < 30){
					Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12))), Core.atlas.find("新视界-lightningLaser-end"),trx2, try2,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trx1 - trnx, try1 - trny,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),b.x - trnx * 2, b.y - trny * 2,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa1 - trnx, trya1 - trny,target.x, target.y, wid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa2, trya2,target.x, target.y, wid * b.fout() * b.fout());
					Draw.color();
				}else{
					var trueWid = wid
					trueWid = Mathf.lerpDelta(trueWid, 0, 0.025);
					Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trx2, try2,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trx1 - trnx, try1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),b.x - trnx * 2, b.y - trny * 2,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa1 - trnx, trya1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
					Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa2, trya2,b.x,b.y, trueWid * b.fout() * b.fout());
					Draw.color();
				}
	        }else{
				var trueWid = wid
				trueWid = Mathf.lerpDelta(trueWid, 0, 0.025);
				Draw.color(bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),bulletCo(Math.floor(Math.random() * (5 - 0)) + 0),b.fout());
				Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trx2, try2,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trx1 - trnx, try1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),b.x - trnx * 2, b.y - trny * 2,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa1 - trnx, trya1 - trny,b.x,b.y, trueWid * b.fout() * b.fout());
				Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),trxa2, trya2,b.x,b.y, trueWid * b.fout() * b.fout());
				Draw.color();
			}
		},
		update(b){
			const target = Units.closestTarget(b.getTeam(), b.x,b.y,lightningGunRange);
			if(target != null){
				if(Angles.angleDist(b.angleTo(target), b.rot()) < 30){
					if(b.timer.get(1, 2)){
						Damage.damage(target.x, target.y, 6, 50);
						Lightning.create(b.getTeam(),colorA, 55, target.x,target.y,Mathf.random(360), Mathf.random(8,20)); 
					}
				}
            }
        }
   })
lightningGunLaser.speed = 0.00001;
lightningGunLaser.damage = 55;
lightningGunLaser.lifetime = 40;
lightningGunLaser.drawSize = lightningGunRange * 2.5;
lightningGunLaser.splashDamageRadius = 40;
lightningGunLaser.splashDamage = 50;
lightningGunLaser.shootEffect = Fx.none;
lightningGunLaser.smokeEffect = Fx.none;
lightningGunLaser.despawnEffect = Fx.none;
lightningGunLaser.hitEffect = Fx.none;

		
		
const lightningGun = extendContent(LaserTurret,"lightningGun",{
	turnToTarget(tile,targetRot){
        const entity = tile.ent();
        entity.rotation = Angles.moveToward(entity.rotation, entity.angleTo(entity.target), entity.power.status * 4.5);
    },
	drawLayer(tile){
        this.super$drawLayer(tile)
    },
    updateShooting(tile){
        const entity = tile.ent();
        if(entity.bulletLife > 0 && entity.bullet != null){
            return;
        }
        if(entity.reload >= this.reload && (entity.cons.valid() || tile.isEnemyCheat())){
            const type = this.peekAmmo(tile);
            this.shoot(tile, type);
            entity.reload = 0;
        }else{
            const liquid = entity.liquids.current();
            var used = Math.min(Math.min(entity.liquids.get(liquid), 0.2 * Time.delta()), Math.max(0, ((this.reload - entity.reload) / this.coolantMultiplier) / liquid.heatCapacity)) * this.baseReloadSpeed(tile);
            entity.reload += used;
            entity.liquids.remove(liquid, used);
            if(Mathf.chance(0.06 * used)){
                Effects.effect(this.coolEffect, tile.drawx() + Mathf.range(this.size * Vars.tilesize / 2), tile.drawy() + Mathf.range(this.size * Vars.tilesize / 2));
            }
        }
    }
})
lightningGun.shootCone = 30;
lightningGun.recoil = 0;
lightningGun.expanded = true;
lightningGun.range = lightningGunRange;
lightningGun.heatColor = Color.valueOf("#BDE6FF")
lightningGun.reload = 25;
lightningGun.shootDuration = 120;
lightningGun.activeSound = Sounds.beam;
lightningGun.activeSoundVolume = 3;
lightningGun.shootType = lightningGunLaser;

function bulletCo(chance){
	switch (chance){
		case 0 : return colorA;
		case 1 : return colorB;
		case 2 : return colorC;
		case 3 : return colorD;
		case 4 : return colorE;
    }
}

