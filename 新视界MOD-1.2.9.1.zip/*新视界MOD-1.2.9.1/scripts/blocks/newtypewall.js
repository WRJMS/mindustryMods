
const steelWall = extendContent(Block, "steelWall", {
    update(tile){
		const entity = tile.ent();
		const findX = tile.x;
		const findY = tile.y;
		const self = Vars.world.tile(findX, findY);
		const dst = 1
		const W = Vars.world.tile(findX - dst, findY);//左侧
		const E = Vars.world.tile(findX + dst, findY);//右侧
		const N = Vars.world.tile(findX, findY + dst);//上方
		const S = Vars.world.tile(findX, findY - dst);//下方
		
		const WN = Vars.world.tile(findX - dst, findY + dst);//左上
		const WS = Vars.world.tile(findX - dst, findY - dst);//左下
		const EN = Vars.world.tile(findX + dst, findY + dst);//右上
		const ES = Vars.world.tile(findX + dst, findY - dst);//右下
		function findTile(target){
			if(target != null){
			//return true
				if(target.block() == tile.block())return true
			}
		}
        /*case 1*/
	    
        /*case */
        
        /*case 3*/
        
        /*case 4*/
        
        /*case 5*/
        /*case 6*/
        /*case 7*/
        /*case 8*/
        /*case 9*/
        /*case 10*/
        /*case 11*/
        /*case 12*/
        /*case 13*/
        /*case 14*/
        /*case 15*/
        /*case 16*/
        /*case 17*/
        /*case 18*/
        /*case 19*/
        /*case 20*/
        /*case 21*/
        /*case 22*/
        /*case 23*/
        /*case 24*/
        /*case 25*/
        /*case 26*/
        /*case 27*/
        /*case 28*/
        /*case 29*/
        /*case 30*/
        /*case 31*/
        /*case 32*/
        /*case 33*/
        /*case 34*/
        /*case 35*/
        /*case 36*/
        /*case 37*/
        /*case 38*/
        /*case 39*/
        if(findTile(S)&&findTile(W)&&findTile(N)&&findTile(E)){
			entity.drawCase = 4;
		}else if(findTile(W)){
			entity.drawCase = 5;
		}else if(findTile(N)){
			entity.drawCase = 6;
		}else if(findTile(S)){
			entity.drawCase = 3;
		}else if(findTile(E)){
			entity.drawCase = 2;
		}else entity.drawCase = 1;
        
	},
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find("新视界-Steel-Wall-" + entity.drawCase), tile.drawx(), tile.drawy());
	}
});
steelWall.entityType=prov(()=>extend(TileEntity,{
    getdrawCase(){return this._drawCase},
    setdrawCase(value){this._drawCase = value},
    _drawCase:1
}));
steelWall.health = 1500;
steelWall.size = 1;
steelWall.update = true;
