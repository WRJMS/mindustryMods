const reactorDesLightningBullet = extend(MissileBulletType,{
	update(b){
		if(Mathf.chance(Time.delta() * 0.1)){
			Lightning.create(Team.derelict,Color.valueOf("f0ffba"), 50, b.x, b.y, b.rot(), Mathf.random(65, 90));         
			for(var i = 0; i < 7; i++){
				Lightning.create(Team.derelict,Color.valueOf("CEFFB4"), 15, b.x, b.y, Mathf.random(360), Mathf.random(15, 28));         
			}
		}
	}
})
reactorDesLightningBullet.damage = 0;
reactorDesLightningBullet.speed = 2.725;
reactorDesLightningBullet.collidesTiles = false,
reactorDesLightningBullet.collides = false,
reactorDesLightningBullet.collidesAir = false,
reactorDesLightningBullet.frontColor = Color.valueOf("CEFFB4"),
reactorDesLightningBullet.backColor = Color.valueOf("#f0ffba"),
reactorDesLightningBullet.trailColor = Color.valueOf("#f0ffba"),
reactorDesLightningBullet.pierce = false;
reactorDesLightningBullet.bulletSprite = "新视界-波束子弹";
reactorDesLightningBullet.bulletWidth = 37;
reactorDesLightningBullet.despawnEffect = Fx.none;
reactorDesLightningBullet.hitEffect = Fx.none;
reactorDesLightningBullet.bulletWidth = 16;
reactorDesLightningBullet.lifetime = 200;

const reactorWorkingEffect = newEffect(40,e => {
	Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#CEFFB4"),e.fin());
	Lines.stroke(e.fin() * 3);
	Lines.circle(e.x, e.y, e.fout() * 80);
	Lines.stroke(e.fout() * 3.25);
	Lines.circle(e.x, e.y, e.fin() * 60);
	Lines.stroke(e.fout() * 2.25);
	const c = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 7);
	}}) 
	Angles.randLenVectors(e.id, 6, 1 + 80 * e.fin(), e.rotation, 360,c);
});
        
const reactorExplosion = newEffect(120,e => {
	Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#CEFFB4"),e.fin());
	Lines.stroke(e.fout() * 5);
	Lines.circle(e.x, e.y, e.fin() * 150);
	Lines.stroke(e.fout() * 3.25);
	Lines.circle(e.x, e.y, e.fin() * 60);
	const d = new Floatc2({get(x, y){
		Fill.circle(e.x, e.y, e.fout() * 28);
	}}) 
    Angles.randLenVectors(e.id, 20, 1 + 150 * e.fout(), e.rotation, 360,d);
	const c = new Floatc2({get(x, y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 16);
	}}) 
	Angles.randLenVectors(e.id, 60, 1 + 160 * e.fin(), e.rotation, 360,c);
});
        
const reactorExplosion2 = newEffect(45,e => {
	Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#CEFFB4"),e.fin());
	const c = new Floatc2({get(x, y){
		Fill.square(e.x + x, e.y + y, e.fout() * 5, 45);
	}}) 
	Angles.randLenVectors(e.id, 8, 80 * e.fin(), e.rotation, 360,c);
});
        
const 巨型反应堆 = extendContent(ImpactReactor,"巨型反应堆",{
	update(tile){
		const entity = tile.ent();

		if(entity.cons.valid() && entity.power.status >= 0.99){
			var prevOut = this.getPowerProduction(tile) <= this.consumes.getPower().requestedPower(entity);

			entity.warmup = Mathf.lerpDelta(entity.warmup, 1, this.warmupSpeed);
			if(Mathf.equal(entity.warmup, 1, 0.001)){
				entity.warmup = 1;
			}
			if(entity.timer.get(this.timerUse, this.itemDuration / entity.timeScale)){
				entity.cons.trigger();
				Effects.effect(newEffect(25,e => {
					Draw.color(e.color, Color.valueOf("#f0ffba"), e.fin());
					const d = new Floatc2({get(x,y){
						Fill.square(e.x + x, e.y + y, 0.1 + e.fout() * 2+1, 45);
					}})
					Angles.randLenVectors(e.id, 12, 20 + e.fin() * 20,d);
				}),tile)
				Effects.effect(reactorWorkingEffect,tile);
				Effects.shake(5,5,tile)
				Sounds.laserbig.at(tile); 
				for (var i = 0; i < 2; i++) {
					Effects.effect(reactorExplosion2,tile);
				}
			}
			if(Mathf.chance(Time.delta() * 0.06)){
				Effects.shake(1,1,tile);
				Effects.effect(Fx.plasticExplosionFlak,tile);
			}
		}else{
			entity.warmup = Mathf.lerpDelta(entity.warmup, 0, 0.01);
		}
		entity.productionEfficiency = Mathf.pow(entity.warmup, 5);
	},
// --------
	draw(tile){
		const entity = tile.ent();
		const plasmas = 4;
		var plasmaRegions = new Array();
		for(var i = 0; i < plasmas; i++){
			plasmaRegions[i] = "新视界-巨型反应堆-plasma-"+i;
		}
		Draw.rect(Core.atlas.find(this.name + "-bottom"), tile.drawx(), tile.drawy());
		for(var i = 0; i < plasmas; i++){
			var r = 29 + Mathf.absin(Time.time(), 2 + i * 1, 5 - i * 0.5);
			Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#CEFFB4"), i / 4);
			Draw.alpha((0.3 + Mathf.absin(Time.time(), 2 + i * 2, 0.3 + i * 0.05)) * entity.warmup);
			Draw.rect(Core.atlas.find(plasmaRegions[i]), tile.drawx(), tile.drawy(),Time.time() * (12 + i * 6) * entity.warmup);
		}

		Draw.color();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy());
		Draw.color();
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name+"-bottom"),
			Core.atlas.find(this.name)
		];
	},
	onDestroyed(tile){
		const entity = tile.ent();
		if(entity.warmup > 0.3){
			Effects.effect(reactorExplosion,tile);
			Damage.damage(tile.drawx(), tile.drawy(), 500, 4500);
			for(var i = 0; i < 15; i++){
				Calls.createBullet(reactorDesLightningBullet, Team.derelict, tile.drawx(), tile.drawy(), Mathf.random(360), 1, 1)
			}
			for(var i = 0; i < 15; i++){
				Effects.effect(Fx.plasticExplosionFlak,tile.drawx() + Mathf.random(-80, 80),tile.drawy() + Mathf.random(-80, 80));
			}
			for(var i = 0; i < 30; i++){
				Lightning.create(Team.derelict,Color.valueOf("f0ffba"), 350, tile.drawx(), tile.drawy(), Mathf.random(360), 125);         
			}
		}
	}
});





