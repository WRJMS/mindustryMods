ownerReseter = extendContent(Block, "ownerReseter", {
	buildConfiguration(tile,table){
		const entity = tile.ent();
		const tileRange = this.range;
		table.addImageButton(Icon.hammer, Styles.clearTransi, run(() => {
			Geometry.circle(tile.x, tile.y, tileRange + 1, new Intc2(){get: (x, y) => {
				const other = Vars.world.ltile(x, y);
				if(other != null){
					if(other.block() != ownerReseter){
						
					}
				}
			}});
		})).size(50)
	},
	drawConfigure(tile){
		Drawf.circles(tile.drawx(), tile.drawy(), 14, Pal.accent);
	}
});
ownerReseter.size = 1;
ownerReseter.range = 5;
ownerReseter.configurable = true;