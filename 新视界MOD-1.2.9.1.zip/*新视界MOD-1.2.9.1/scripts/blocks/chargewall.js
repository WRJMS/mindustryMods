/*var ChargeBuild = null
const chargeCooledProjector = extendContent(Block,"chargeCooledProjector",{
	update(tile){
		const entity = tile.ent();
		//entity.heat = Mathf.lerpDelta(entity.heat, entity.power.status > 0.5 || tile.isEnemyCheat() ? entity.power.status : 0, 0.08);
		entity.chargeProgress += entity.power.status * entity.delta();
		
		if(entity.chargeProgress >= this.reload){
			entity.chargeProgress = 0;
			const tileRange = Math.floor(this.range / Vars.tilesize) + 1;
			
			for(var x = -tileRange + tile.x; x <= tileRange + tile.x; x++){
				for(var y = -tileRange + tile.y; y <= tileRange + tile.y; y++){
					//if(!Mathf.within(x * Vars.tilesize, y * Vars.tilesize, tile.drawx(), tile.drawy(), this.range)) continue;
					const other = Vars.world.ltile(x, y);
					//if(other == null) continue;
					if(/*other.getTeamID() == tile.getTeamID() && other.entity != null && other.block() == ChargeBuild){
						Effects.effect(Fx.healBlockFull, this.baseColor, other.drawx(), other.drawy(), other.block().size);
						//other.entity.overHeat = 0.001;
					}
				}
			}
		}
	},
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy());
		const f = 1 - (Time.time() / 100) % 1;
		Draw.color(this.baseColor);
		Draw.alpha(entity.power.status * Mathf.absin(Time.time(), 10, 1) * 0.5);
		Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
		Draw.alpha(1);
		Lines.stroke((2 * f + 0.2) * entity.power.status);
		Lines.square(tile.drawx(), tile.drawy(), ((1 - f) * 8) * this.size / 2);
		Draw.reset();
	},
	drawPlace(x, y, rotation, valid){
		Drawf.dashCircle(x * Vars.tilesize + this.offset(), y * Vars.tilesize + this.offset(), this.range, this.baseColor);
	},
});
chargeCooledProjector.range = 80;
chargeCooledProjector.consumes.power(8)
chargeCooledProjector.reload = 60;
chargeCooledProjector.update = true;
chargeCooledProjector.baseColor = Color.valueOf("#C8E8FF");
chargeCooledProjector.hasPower = true;
chargeCooledProjector.entityType=prov(()=>extend(TileEntity,{
    getchargeProgress(){return this._chargeProgress},
    setchargeProgress(value){this._chargeProgress = value},
    _chargeProgress:0
}));*/

const expWall = newEffect(25,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
	Lines.stroke(e.fout() * 2); 
	Lines.circle(e.x, e.y, e.fin() * 80);
	const d = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 12 + 5);
	}})
	Angles.randLenVectors(e.id, 40, 104 * e.fin(),e.rotation, 360,d);
});

const releaseBullet = extend(MissileBulletType,{
update(b){
	const target = Units.closestTarget(b.getTeam(), b.x,b.y,200)
		if (target != null) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.6));
		}
		if(b.timer.get(1,0.00001)){
			Effects.effect(newEffect(25,e => {
				Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
				const d = new Floatc2({get(x, y){
					Lines.stroke(e.fout() * 2.725);
					Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 22 + 20);
				}})
				Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
			}),Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
		}
	},
	draw(b){}
})
releaseBullet.speed = 7.125;
releaseBullet.damage = 30;
releaseBullet.shootEffect = Fx.lightningShoot;
releaseBullet.smokeEffect = newEffect(25,e => {
	const d = new Floatc2({get(x,y){
		Draw.color(Color.valueOf("abdbff"),Color.valueOf("f0f8ff"),e.fin());
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
	}})
	Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
});
releaseBullet.lifetime = 95;
releaseBullet.despawnEffect = Fx.hitLancer;
releaseBullet.hitEffect = Fx.hitLancer;
function ChargeWallCreate(name,wallHealth,wallSize,range,multp,phaseTime,totalReload,baseColor,drawEnergy,maximumEnergy){
    const ChargeWall = extendContent(Wall,name,{
		handleBulletHit(entity,bullet){
			var tDamage = 0
			if(100/entity.chargeProgress > 1){
				tDamage = bullet.damage();
			}else if(100/entity.chargeProgress <= 1 && 100/entity.chargeProgress > 0.2){
				tDamage = 100/entity.chargeProgress * bullet.damage();
			}else tDamage = 0.2 * bullet.damage();
			entity.chargeProgress += bullet.damage() * multp * wallSize;
			entity.damage(tDamage);
		},
		update(tile){
			const entity = tile.ent();
			const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(),range);
			if(entity.chargeProgress > 100){
				if(entity.chargeProgress > maximumEnergy * wallSize - 80 * wallSize){
					entity.overHeat += maximumEnergy * wallSize / 10 ;
					if(target != null){
						for(var i = 0; i < wallSize * 3; i++){
							Lightning.create(tile.getTeam(),baseColor, 125 * wallSize,tile.drawx(), tile.drawy(),entity.angleTo(target), 20 * wallSize);         
						}
					}
					entity.chargeProgress -= (maximumEnergy - 50) * wallSize;
					Effects.effect(expWall,Color.valueOf("C2FF8300"), baseColor, tile.drawx(), tile.drawy(), wallSize);
				}
				if(entity.chargeProgress > maximumEnergy / 2 * wallSize && target != null){
					entity.shoot += 1
					if(entity.shoot == 5){
						entity.shoot = 0
						const ang = entity.angleTo(target);
						const trnx = tile.drawx() + Angles.trnsx(ang, wallSize * 8)
						const trny = tile.drawy() + Angles.trnsy(ang, wallSize * 8)
						Sounds.laser.at(tile); 
						entity.chargeProgress -= Math.floor(maximumEnergy / 15 * wallSize);
						Effects.effect(Fx.lightningShoot, baseColor, tile.drawx(), tile.drawy(), wallSize);
						Effects.effect(Fx.hitLancer, baseColor, tile.drawx(), tile.drawy(), wallSize);
						Calls.createBullet(releaseBullet,tile.getTeam(),trnx, trny, ang , 1, 1);
					}
				}
				entity.chargeProgress = Mathf.lerpDelta(entity.chargeProgress,100,wallSize / 100);
				if(Mathf.chance(0.1)){
					entity.chargeProgress -= 2 * wallSize;
				}
				if(entity.health < entity.maxHealth()){
					entity.reload += 1;
					if(entity.reload >= totalReload / wallSize){
						Effects.effect(Fx.healBlockFull, baseColor, tile.drawx(), tile.drawy(), wallSize);
						entity.reload = 0;
						tile.entity.healBy(5 * wallSize / 100 * tile.entity.maxHealth());
					}
				}else if(entity.overHeat > 0.001){
					entity.overHeat = Mathf.lerpDelta(entity.overHeat,0.001,wallSize / 1000);
				}
				if(target != null){
					const angel = entity.angleTo(target);
					if(Mathf.chance(0.2)){
						Lightning.create(tile.getTeam(), baseColor, entity.chargeProgress * 0.25 * wallSize > 100 * wallSize ? 100 * wallSize : entity.chargeProgress * 0.25 * wallSize, tile.drawx(), tile.drawy(), angel, Math.floor(Mathf.dst(tile.drawx(),tile.drawy(),target.x,target.y) * 1.65 / Vars.tilesize) + 2);
						entity.chargeProgress -= Math.floor(Mathf.dst(tile.drawx(),tile.drawy(),target.x,target.y) / wallSize / 16);
					}
				}
				if(entity.health < entity.maxHealth() || target != null)entity.phase += 1;
				if(entity.phase >= phaseTime * wallSize){
					entity.chargeProgress = entity.chargeProgress - 100;
					entity.phase = 0;
				}
			}else{
				entity.chargeProgress = Mathf.lerpDelta(entity.chargeProgress,0,wallSize / 225);
			}
			if(entity.overHeat > maximumEnergy * wallSize * wallSize){
				entity.kill();
			}
			if(entity.overHeat > maximumEnergy * wallSize * wallSize / 4){
				const smoke = 1 + (entity.overHeat - maximumEnergy * wallSize * wallSize / 40); 
				if(Mathf.chance(smoke / 40 * entity.delta())){
					Effects.effect(Fx.reactorsmoke, tile.worldx() + Mathf.range(this.size * Vars.tilesize / 2),tile.worldy() + Mathf.random(this.size * Vars.tilesize / 2));
				}
			}
			if(entity.chargeProgress < maximumEnergy / 4){
				entity.overHeat = Mathf.lerpDelta(entity.overHeat,0.001,wallSize / 125);
			}
		},
		draw(tile){
			const entity = tile.ent();
			Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy());
			Draw.color(baseColor);
			Draw.alpha(entity.chargeProgress / 210 );
			Draw.blend(Blending.additive);
			if(drawEnergy)Draw.rect(Core.atlas.find(this.name + "-energy"), tile.drawx(), tile.drawy());
			Draw.color();
			if(drawEnergy && entity.overHeat > maximumEnergy * wallSize * wallSize / 4){
				Draw.color(Color.white);
				Draw.alpha(entity.overHeat / wallSize / 100 /1.3);
				Draw.rect(Core.atlas.find(this.name + "-energy"), tile.drawx(), tile.drawy())
				const flash = 1 + (entity.overHeat - maximumEnergy * wallSize * wallSize / 4);
				entity.flash += flash * Time.delta();
				Draw.color(Color.valueOf("#FF7F00"), Color.valueOf("#FF4800"), Mathf.absin(entity.flash, 9, 1));
				Draw.rect(Core.atlas.find(this.name + "-energy"), tile.drawx(), tile.drawy())
				Draw.alpha(entity.overHeat / wallSize / 100 / 2.6);
				Draw.rect(Core.atlas.find(this.name + "-light"), tile.drawx(), tile.drawy())
			}
			Draw.blend();
			Draw.color();
		},
		onDestroyed(tile){
			this.super$onDestroyed(tile);
			const entity = tile.ent();
			if(entity.chargeProgress < 500)return;
			Effects.effect(expWall,tile);
			Damage.damage(Team.derelict,tile.drawx(), tile.drawy(), 16 * wallSize, entity.chargeProgress / 1.5 * Math.pow(wallSize,2),false);
			for(var i = 0; i < wallSize; i++){
				Lightning.create(Team.derelict,baseColor,entity.chargeProgress * 0.05 * wallSize,tile.drawx(), tile.drawy(),Mathf.random(360), 15 + Math.floor(entity.chargeProgress / (wallSize * 100) * wallSize));         
			}
		},
		drawPlace(x, y, rotation, valid){
			Drawf.dashCircle(x * Vars.tilesize + this.offset(), y * Vars.tilesize + this.offset(), range, baseColor);
		},
		drawSelect(tile){
			const entity = tile.ent();
			const len = 100;
			Draw.color(Color.valueOf("#292F3C"));
			Lines.stroke(4);
	        Lines.lineAngleCenter(tile.drawx() + wallSize * 4 + 4,tile.drawy(), 90, maximumEnergy * wallSize  / len * wallSize);
	        Draw.color(baseColor);
	        Lines.stroke(3);
	        Lines.lineAngleCenter(tile.drawx() + wallSize * 4 + 4,tile.drawy() - maximumEnergy * wallSize  / len * wallSize / 2 + entity.chargeProgress / len / 2 * wallSize, 90, entity.chargeProgress / len * wallSize);
			Drawf.dashCircle(tile.drawx(), tile.drawy(), range, baseColor);
			
			Draw.color(Color.valueOf("#292F3C"));
			const uiLength = maximumEnergy * wallSize  / len * wallSize;
			const pre = entity.overHeat / (maximumEnergy * wallSize * wallSize);
			Lines.stroke(4);
	        Lines.lineAngleCenter(tile.drawx() + (wallSize * 4 + 4) * 2,tile.drawy(), 90, uiLength);
	        Draw.color(Color.valueOf("#FF986D"));
	        Lines.stroke(3);
	        Lines.lineAngleCenter(tile.drawx() + (wallSize * 4 + 4) * 2,tile.drawy() - uiLength / 2 + uiLength * pre / 4 * wallSize, 90, uiLength * pre);
		}
	});
	ChargeWall.health = wallHealth // Math.pow(wallSize,2);
	ChargeWall.update = true;
	ChargeWall.buildCostMultiplier = 2;
    ChargeWall.localizedName = Core.bundle.get("Block."+name+".name");
    ChargeWall.description = Core.bundle.get("Block."+name+".description");
    ChargeWall.entityType=prov(()=>extend(TileEntity,{
    getchargeProgress(){return this._chargeProgress},
    setchargeProgress(value){this._chargeProgress = value},
    _chargeProgress:0,
    getphase(){return this._phase},
    setphase(value){this._phase = value},
    _phase:0,
    getreload(){return this._reload},
    setreload(value){this._reload = value},
    _reload:0,
    getshoot(){return this._shoot},
    setshoot(value){this._shoot = value},
    _shoot:0,
    getoverHeat(){return this._overHeat},
    setoverHeat(value){this._overHeat = value},
    _overHeat:0.001,
    getflash(){return this._flash},
    setflash(value){this._flash = value},
    _flash:0
}));
    return ChargeWall;
};
const chargewall = ChargeWallCreate("charge-wall", 1400, 1, 240, 0.5, 120, 12, Color.valueOf("#C8E8FF"),true,1000);
const chargewallLarge = ChargeWallCreate("charge-wall-large", 5600, 2, 240, 0.5, 120, 12, Color.valueOf("C8E8FF"),true,1000);
