const 尾迹热电 = newEffect(25,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
	const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2.725);
		Lines.lineAngle(e.x, e.y, Mathf.angle(x, y), e.fslope() * 22 + 20);
	}})
	Angles.randLenVectors(e.id, 1, 1 + 0 * e.fin(),e.rotation, 0,d);
});
const 热电子弹 = extend(MissileBulletType,{
update(b){
	const target = Units.closestTarget(b.getTeam(), b.x,b.y,1000)
		if (target != null) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.6));
		}
		if(b.timer.get(1,0.00001)){
			Effects.effect(尾迹热电,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
		}
	},
	draw(b){}
})
热电子弹.speed = 7.125,
热电子弹.damage = 25,
热电子弹.shootEffect = Fx.lightningShoot
热电子弹.smokeEffect = newEffect(25,e => {
	const d = new Floatc2({get(x,y){
		Draw.color(Color.valueOf("abdbff"),Color.valueOf("f0f8ff"),e.fin());
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
	}})
	Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
});
热电子弹.lifetime = 95,
热电子弹.despawnEffect = Fx.hitLancer
热电子弹.hitEffect = Fx.hitLancer
const 热电炮= extendContent(PowerTurret,"热电炮",{});
热电炮.shootType = 热电子弹
热电炮.ammoUseEffect = Fx.shootBigSmoke