const recurrence = 6;

const zateFactory = extendContent(Cultivator, "large-zate-factory", {
	/*draw(tile){
		const entity = tile.ent();
		
		Draw.rect(Core.atlas.find(this.name + "-bottom"), tile.drawx(), tile.drawy());
		
		Draw.color(Color.valueOf("f0ffba"));
		Draw.alpha(entity.warmup);
		Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
		Draw.color(Color.valueOf("474747"), Color.valueOf("7457ce"), entity.warmup);
		
		//this..random.setSeed(tile.pos());
		for(var i = 0; i < 12; i++){
			var offset = Mathf.random(1) * 999999;
			var x = Mathf.random(4);
			var y = Mathf.random(4);
			var life = 1 - (((Time.time() + offset) / 50) % recurrence);
			if(life > 0){
				Lines.stroke(entity.warmup * (life * 1 + 0.2));
				Lines.circle(tile.drawx() + x, tile.drawy() + y,(1 - life) * 3);
			}
		}
		Draw.color();
		Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name),
			//Core.atlas.find(this.name + "-top")
		];
	}*/
})
zateFactory.plantColor = Color.valueOf("#ffb28c");
zateFactory.plantColorLight = Color.valueOf("#ffd7b7");
zateFactory.bottomColor = Color.valueOf("ff846b");
zateFactory.attribute = Attribute.water

