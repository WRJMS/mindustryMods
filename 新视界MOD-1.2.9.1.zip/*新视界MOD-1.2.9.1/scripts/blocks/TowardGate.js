

const TowardGate = extendContent(Block, "towardGate", {
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy(), 0);
		Draw.rect(Core.atlas.find(this.name + "-center"), tile.drawx(), tile.drawy(), tile.rotation() * 90);
	},
	findTile(tile,angle){
		const entity = tile.ent();
		const findAng = this.findAng(tile,angle);
		
		const nearT = tile.getNearby(findAng)
		if(nearT == null || nearT == Blocks.air)return null;
		return nearT;
	},
	findAng(tile,angle){
		const findAng = tile.rotation() + angle == 4 ? 0 : tile.rotation() + angle == -1 ? 3 : tile.rotation() + angle;
		return findAng;
	},
	handleItem(item, tile, source){
		const entity = tile.ent();
		entity.items.add(item, 1);
		entity.sortItem = item;
    },
	acceptItem(item, tile, source){
		const entity = tile.ent();
		const toF = this.findTile(tile,0);
		const toL = this.findTile(tile,-1);
		const toR = this.findTile(tile,+1);
		if(toR == source)return false;
		if(toL == source)return false;
		if(toF == source)return false;
		if(this.findTile(tile, 2) == this)return false;
		if(tile.getTeam() == source.getTeam() && entity.items.total() == 0)return true;
	},
	canDump(tile, to, item){
		return true;
	},
	dumpRotate(tile){
		const entity = tile.ent();
		const toF = this.findTile(tile,0);
		const toL = this.findTile(tile,-1);
		const toR = this.findTile(tile,+1);
		var linked = 0;
		if(toF != null)linked += 1;
		if(toL != null)linked += 1;
		if(toR != null)linked += 1;
		if(linked = 1)return true;
		if(linked = 2){
			return entity.mod % 2 == 0 ? true : false;
		}
		if(linked = 3){
			return entity.mod % 3 == 0 ? true : false;
		}
		return true;
	},
	update(tile){
		const entity = tile.ent();
		if(entity.sortItem != null){
			const toF = this.findTile(tile,0);
			const toL = this.findTile(tile,-1);
			const toR = this.findTile(tile,+1);
			if(toR != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toR.block().acceptItem(entity.sortItem,toR,Edges.getFacingEdge(tile,toR))){
					tile.entity.items.remove(entity.sortItem,1);
					toR.block().handleItem(entity.sortItem,toR,tile);
					entity.mod += 1;
				}
			}
			if(toL != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toL.block().acceptItem(entity.sortItem,toL,Edges.getFacingEdge(tile,toL))){
					tile.entity.items.remove(entity.sortItem,1);
					toL.block().handleItem(entity.sortItem,toL,tile);
					entity.mod += 1;
				}
			}
			if(toF != null){
				if(tile.entity.items.get(entity.sortItem) > 0 && toF.block().acceptItem(entity.sortItem,toF,Edges.getFacingEdge(tile,toF))){
					tile.entity.items.remove(entity.sortItem,1);
					toF.block().handleItem(entity.sortItem,toF,tile);
					entity.mod += 1;
				}
			}
		}
		if(entity.mod == 3) entity.mod 
	},
	drawConfigure(tile){
		const entity = tile.ent();
		Draw.color(Pal.accent);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile, -1) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile, -1) * 90, Vars.tilesize), this.findAng(tile, -1) * 90);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile,  1) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile,  1) * 90, Vars.tilesize), this.findAng(tile,  1) * 90);
		Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile,  0) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile,  0) * 90, Vars.tilesize), this.findAng(tile,  0) * 90);
		Lines.square(tile.drawx(), tile.drawy(),this.size * Vars.tilesize / 2.0 );
		const toF = this.findTile(tile,0);
		const toL = this.findTile(tile,-1);
		const toR = this.findTile(tile,+1);
		/*
		for(var i = -1; i < 1; i++){
			Draw.rect("bridge-arrow", tile.drawx() + Angles.trnsx(this.findAng(tile, i) * 90, Vars.tilesize), tile.drawy() + Angles.trnsy(this.findAng(tile, i) * 90, Vars.tilesize), this.findAng(tile, i) * 90);
		}
		*/
		//if(toR != null)	Lines.square(toR.drawx(), toR.drawy(), toR.block().size * Vars.tilesize / 2 );
		//if(toL != null)	Lines.square(toL.drawx(), toL.drawy(), toL.block().size * Vars.tilesize / 2 );
		//if(toF != null)	Lines.square(toF.drawx(), toF.drawy(), toF.block().size * Vars.tilesize / 2 );
		Draw.reset();
	},
	generateIcons(){
		return [Core.atlas.find(this.name),Core.atlas.find(this.name + "-center")];
	}
});
TowardGate.size = 3;
TowardGate.update = true;
TowardGate.configurable = true;
TowardGate.rotate = true;
TowardGate.entityType=prov(()=>extend(Unloader.UnloaderEntity,{
	getmod(){return this._mod},
	setmod(value){this._mod = value},
	_mod:0
}));