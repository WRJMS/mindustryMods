

const 相位液体工厂 = extendContent(GenericSmelter,"相位液体工厂",{
	
    draw(tile){
        Draw.rect(Core.atlas.find(this.name),tile.drawx(),tile.drawy())
        Draw.color(tile.entity.liquids.current().color)
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
        Draw.color();
        Draw.rect(Core.atlas.find(this.name + "-top"),tile.drawx(),tile.drawy())

    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
            Core.atlas.find(this.name + "-top")
        ];
    }
    
});
相位液体工厂.craftEffect = Fx.smeltsmoke;

