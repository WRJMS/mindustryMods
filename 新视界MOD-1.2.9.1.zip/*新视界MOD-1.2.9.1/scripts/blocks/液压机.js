const 液压机 = extendContent(GenericSmelter,"液压机",{         
    draw(tile){ 
        var frameRegions = new Array();
        for(var i = 0; i < 5; i++){
            frameRegions[i] = "新视界-液压机-"+i;
        }
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        Draw.color(Color.valueOf("E8CEE5"));
        Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
        Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
        Draw.color()
        Draw.rect(Core.atlas.find(frameRegions[Math.floor(Mathf.absin(tile.ent().totalProgress, 5.2, 4.999))]), tile.drawx(), tile.drawy());
    },
    generateIcons(){
        return [
            Core.atlas.find(this.name),
        ];
    }
});
