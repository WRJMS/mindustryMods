

const 粒子对撞机 = extendContent(GenericSmelter,"粒子对撞机",{
	draw(tile){
		Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
		Draw.color(tile.entity.liquids.current().color);
		Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
		Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
		Draw.color();
		const sinLen = Mathf.absin(Time.time(), 5, tile.ent().warmup * 3.3);
		Draw.rect(Core.atlas.find(this.name + "-press"),tile.drawx() + sinLen,tile.drawy() - sinLen, 90 );
		Draw.rect(Core.atlas.find(this.name + "-press"),tile.drawx() - sinLen,tile.drawy() - sinLen, 0  );
		Draw.rect(Core.atlas.find(this.name + "-press"),tile.drawx() - sinLen,tile.drawy() + sinLen, 270);
		Draw.rect(Core.atlas.find(this.name + "-press"),tile.drawx() + sinLen,tile.drawy() + sinLen, 180);
		Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),90 + tile.ent().totalProgress * 1.25)
		Draw.rect(this.region,tile.drawx(),tile.drawy())
		Draw.color();
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name + "-bottom"),
			Core.atlas.find(this.name),
		];
	}
});
粒子对撞机.craftEffect = Fx.smeltsmoke;