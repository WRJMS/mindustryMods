var ActiveSuperWeapon = new Array();

const WarningTable = extendContent(Block, "warningbuild", {
	dialog: null,
	load(){
		this.super$load();
		this.dialog = new FloatingDialog(Core.bundle.get("warningText.title"))
		this.dialog.addCloseButton();

		Events.on(EventType.WorldLoadEvent, run(event => {
			ActiveSuperWeapon = new Array();
		}));
		
	},
	buildConfiguration(tile, table){
		Vars.control.input.frag.config.hideConfig();
		this.makelist(tile);
		this.dialog.show();
	},
	makelist(tile){
		const entity = tile.ent();
		const height = 4 ;
		const colorA = Color.valueOf("FF5800") ;
		
		this.dialog.cont.clear();
		this.dialog.cont.pane(cons(table => {
			table.margin(10).top();
			var haveBuild = 0
			for(var i = 0; i < ActiveSuperWeapon.length; i++){
				if(ActiveSuperWeapon[i] == null)continue;
				if(ActiveSuperWeapon[i] == undefined)continue;
				haveBuild += 1;
			}
			table.add("SuperWeaponBuiltNum: "+haveBuild).growX().left().color(colorA);
			table.row();
			table.addImage().growX().height(3).pad(10).color(colorA);
			table.row();
			table.add("").growX().left().color(Color.lightGray);
			table.row();
			
			
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			table.add(Core.bundle.get("Block."+"AirRaid") +  ":").growX().left().color(Pal.accent);
			table.row();
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			for(var i = 0; i < ActiveSuperWeapon.length; i++){
				if(ActiveSuperWeapon[i] == null)continue;
				if(ActiveSuperWeapon[i] == undefined)continue;
				if(ActiveSuperWeapon[i].name != "AirRaid")continue;
				
				table.add("Tile Belongs To: ").growX().left().color(Color.lightGray);
				table.row();
				table.add("" + ActiveSuperWeapon[i].team).growX().left().color(ActiveSuperWeapon[i].team.color);
				table.row();
				table.add("X: " + ActiveSuperWeapon[i].x +  "; Y: " + ActiveSuperWeapon[i].y).growX().left().color(Color.lightGray);
				table.row();
				table.add("").growX().left().color(Color.lightGray);
				table.row();
			}
			table.add("").growX().left().color(Color.lightGray);
			table.row();
			table.add("").growX().left().color(Color.lightGray);
			table.row();
			
			
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			table.add(Core.bundle.get("Block."+"LightningStormGenerator") +  ":").growX().left().color(Pal.accent);
			table.row();
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			for(var i = 0; i < ActiveSuperWeapon.length; i++){
				if(ActiveSuperWeapon[i] == null)continue;
				if(ActiveSuperWeapon[i] == undefined)continue;
				if(ActiveSuperWeapon[i].name != "LightningStormGenerator")continue;
				table.add("Tile Belongs To: ").growX().left().color(Color.lightGray);
				table.row();
				table.add("" + ActiveSuperWeapon[i].team).growX().left().color(ActiveSuperWeapon[i].team.color);
				table.row();
				table.add("X: " + ActiveSuperWeapon[i].x +  "; Y: " + ActiveSuperWeapon[i].y).growX().left().color(Color.lightGray);
				table.row();
				table.add("").growX().left().color(Color.lightGray);
				table.row();
			}
			table.add("").growX().left().color(Color.lightGray);
			table.row();
			table.add("").growX().left().color(Color.lightGray);
			table.row();
			
			
			
			var haveDestroyed = 0
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			for(var i = 0; i < ActiveSuperWeapon.length; i++){
				if(ActiveSuperWeapon[i] != null)continue;
				haveDestroyed ++;
				table.add("Removed / Destroyed Num: " + haveDestroyed).growX().left().color(Pal.accent);
				table.row();
			}
			table.addImage().growX().height(height).pad(10).color(Pal.accent);
			table.row();
			table.add("TimeAll: " + Math.floor(Time.time() / 60) ).growX().left().color(Pal.accent);
			table.row();
			table.add("GlobalTime: " + Math.floor(Time.globalTime() / 60) ).growX().left().color(Pal.accent);
			table.row();
		})).width(Vars.mobile ? 460 : 530);
	}
});
WarningTable.size = 2;
WarningTable.configurable = true;
WarningTable.update = true;
/*LightningStormGenerator.entityType=prov(()=>extend(TileEntity,{
    getchargeProgress(){return this._chargeProgress},
    setchargeProgress(value){this._chargeProgress = value},
    _chargeProgress:0,
    getshoot(){return this._shoot},
    setshoot(value){this._shoot = value},
    _shoot:0,
    gettileInfo(){return this._tileInfo},
    settileInfo(value){this._tileInfo = value},
    _tileInfo:[],
    write(stream){
		this.super$write(stream);
		stream.writeFloat(this._tileInfo);
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._tileInfo = stream.readFloat();
	}
}));*/

//A0CCFF 55A1FF
const effectColor = Color.valueOf("A0CCFF");
const effectColor2 = Color.valueOf("C8D9FF");
const effectColor3 = Color.valueOf("#3F526E");

//---------------------------------------------------------------------------------------------

const airRaidAttack = newEffect(20, e => {
	Draw.color(effectColor,effectColor2,e.fin());
	Lines.stroke(e.fslope() * 3); 
	const d = new Floatc2({get(x, y){
		Lines.poly(e.x + x, e.y + y, 6, 8 * e.fslope() + 4);
	}})
	const f = new Floatc2({get(x, y){
		Fill.poly(e.x + x, e.y + y, 6, 10 * e.fout());
	}})
	Angles.randLenVectors(e.id, 3, 120 * e.fout(), 0, 360,d);
	Angles.randLenVectors(e.id, 7, 160 * e.fin(), 0, 360,f);
});

const airRaidAttackShoot = newEffect(20, e => {
	Draw.color(effectColor,effectColor2,e.fin());
	Drawf.tri(e.x, e.y, 6, 82 * e.fout(), e.rotation - 90);
    Drawf.tri(e.x, e.y, 6, 82 * e.fout(), e.rotation + 90);
});

const zinaexplode = newEffect(20, e => {
	Draw.color(effectColor2);
	for(var i = 0; i < 4; i++){
		Drawf.tri(e.x, e.y, 7, 85 * e.fout(), e.rotation + 90 * i - 45 + Time.time() * 6);
	}
	Lines.stroke(e.fout() * 3); 
	Lines.circle(e.x, e.y, e.fin() * 40); 
	Draw.color(effectColor2);
	Fill.circle(e.x, e.y, e.fout() * 14);
	Draw.color(Color.valueOf("#ffffff"),Color.valueOf("#CDE7FF"),e.fin());
	Fill.circle(e.x, e.y, e.fout() * 7);
});

//---------------------------------------------------------------------------------------------
const linkLen = 24;
//---------------------------------------------------------------------------------------------

const airRaidAttackMissile = extend(BasicBulletType,{
	draw(b){
		this.super$draw(b);
		Draw.color(effectColor);
		Drawf.tri(b.x, b.y, 3, 50 * b.fout(), b.rot() - 150);
		Drawf.tri(b.x, b.y, 3, 50 * b.fout(), b.rot() - 210);
		Units.nearbyEnemies(b.getTeam(), b.x - linkLen / 2, b.y - linkLen / 2, linkLen, linkLen, cons(unit => {
			Draw.color(bulletCo(Math.floor(Math.random() * 2)));
			Drawf.laser(Core.atlas.find("新视界-lightningLaser-" + Math.floor(Math.random() * (12 - 0))), Core.atlas.find("新视界-lightningLaser-end"),b.x, b.y,unit.x,unit.y, 1.2);
		}))
	},
	update(b){
		if(b.timer.get(2,3)){
			Units.nearbyEnemies(b.getTeam(), b.x - linkLen / 2, b.y - linkLen / 2, linkLen, linkLen, cons(unit => {
				Lightning.create(b.getTeam(),bulletCo(Math.floor(Math.random() * 2)), 55, unit.x,unit.y,Mathf.random(360), Mathf.random(4,8)); 
			}))
			Lightning.create(b.getTeam(),effectColor, 75, b.x,b.y,b.rot() - 180, Mathf.random(15,27)); 
		}
		if(b.timer.get(1,1)){
			Effects.effect(newEffect(25,e => {
				Draw.color(effectColor,effectColor2,e.fin());
				Lines.stroke(e.fout() * 5);
				Lines.lineAngleCenter(e.x, e.y, e.rotation - 180, e.fout() * 44 + 56);
				
				const d = new Floatc2({get(x, y){
					Fill.poly(e.x + x, e.y + y, 6, 5.5 * e.fslope() * e.fout());
				}})
				Angles.randLenVectors(e.id, 4, 120 * e.fin(),e.rotation - 180, 20,d);
				//Angles.randLenVectors(e.id, 6, 40 * e.fin(),e.rotation - 260, 20,d);
			}),Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
		}
		if(b.timer.get(0,15)){
			//Bullet.create(airRaidAttackMissileFrag,b,b.x,b.y,b.rot() - 180 + Mathf.random(-30,30));
		}
		const target = Units.closestTarget(b.getTeam(), b.x, b.y, 750)
		if(target != null){
			//b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.006));
		}
	},
	hit(b){
		if(b == null)return;
		Lightning.create(b.getTeam(), effectColor3, 150, b.x, b.y, b.rot() - 180, 7); 
		Lightning.create(b.getTeam(), effectColor, 380, b.x, b.y, b.rot() - 180, 15); 
		Effects.effect(airRaidAttack, Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
	},
	init(b){
		if(b == null)return;
		Effects.effect(airRaidAttackShoot, Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
	}
})
airRaidAttackMissile.speed = 16 ,
airRaidAttackMissile.bulletShrink = 0 ,
airRaidAttackMissile.damage = 2500,
airRaidAttackMissile.splashDamageRadius = 64,
airRaidAttackMissile.splashDamage = 250,
airRaidAttackMissile.knockback = 70,
airRaidAttackMissile.bulletWidth = 17.125,
airRaidAttackMissile.bulletHeight = 60,
airRaidAttackMissile.drag = -10,
airRaidAttackMissile.collidesTiles = true,
airRaidAttackMissile.pierce = true,
airRaidAttackMissile.collides = true,
airRaidAttackMissile.collidesAir = true,
airRaidAttackMissile.homingPower = 1,
airRaidAttackMissile.backColor = effectColor,
airRaidAttackMissile.frontColor = effectColor2,
airRaidAttackMissile.homingRange = 1000,
airRaidAttackMissile.lifetime = 100,
airRaidAttackMissile.despawnEffect = newEffect(20,e => {
	Draw.color(effectColor,effectColor2,e.fin());
	Lines.stroke(e.fout() * 3);
	Lines.circle(e.x, e.y, e.fin() * 60);
	Lines.stroke(e.fout() * 1.75);
	Lines.circle(e.x, e.y, e.fin() * 45);
	const d = new Floatc2({get(x, y){
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.275, 45);
	}})
	Angles.randLenVectors(e.id, 10, 1 + e.fin() * 40,d);
	Draw.color(effectColor);
	Fill.circle(e.x, e.y, e.fin() * 5);
	Draw.color(effectColor,effectColor2,e.fin());
	Fill.circle(e.x, e.y, e.fin() * 3);
});
airRaidAttackMissile.bulletSprite = "新视界-冲击子弹";

//---------------------------------------------------------------------------------------------
const range = 1080;
const rnd = 80;
//---------------------------------------------------------------------------------------------

const AirRaid = extendContent(Block, "空袭呼叫器", {
	command:false,
	load(){
		this.super$load();
		Events.on(EventType.WorldLoadEvent, run(event => {
			WorldCommand = true;
			this.command = true;
		}));
	},
	init(){
		this.super$init();
		Events.on(EventType.WorldLoadEvent, run(event => {
			WorldCommand = true;
			this.command = true;
		}));
	},
	placed(tile){
		const entity = tile.ent();
		this.super$placed(tile);
		entity.initLength = ActiveSuperWeapon.length;
		entity.tileInfo.name = "AirRaid";
		entity.tileInfo.x = tile.x;
		entity.tileInfo.y = tile.y;
		entity.tileInfo.team = tile.getTeam();
		ActiveSuperWeapon[ActiveSuperWeapon.length] = entity.tileInfo;
	},
	onDestroyed(tile){
		const entity = tile.ent();
		this.super$onDestroyed(tile);
		ActiveSuperWeapon[entity.initLength] = null;
	},
	removed(tile){
		const entity = tile.ent();
		this.super$removed(tile);
		ActiveSuperWeapon[entity.initLength] = null;
	},
	update(tile){
		const entity = tile.ent();
		if(entity.initLength == -1){
			entity.tileInfo = {};
			entity.tileInfo.name = "AirRaid";
			entity.tileInfo.x = tile.x;
			entity.tileInfo.y = tile.y;
			entity.tileInfo.team = tile.getTeam();
			ActiveSuperWeapon[ActiveSuperWeapon.length] = entity.tileInfo;
			entity.initLength = ActiveSuperWeapon.length;
		}
		if(entity.reload <= 60){
			entity.reload += 1;
		}
	},
	drawSelect(tile){
		const entity = tile.ent();
		Draw.blend(Blending.additive);
		Draw.color(Color.valueOf("#FF4E2C37"));
		Fill.circle(tile.drawx(), tile.drawy(), range - 15);
		Draw.color(Color.valueOf("#ffffff30")); 
		Fill.circle(tile.drawx(), tile.drawy(), rnd * 2);
		Draw.color(Color.valueOf("#ffffff"));
		Lines.stroke(30);
		Lines.circle(tile.drawx(), tile.drawy(), range - 15 );
		Fill.circle(tile.drawx(), tile.drawy(), 5);
		Draw.color(Color.valueOf("#ffffff75"));
		Lines.stroke(3.125);
		for(var i = 0; i < 4; i++){
			Lines.circle(tile.drawx(), tile.drawy(), (range - 80) / Math.pow(i,2));
		}
		Drawf.tri(tile.drawx(), tile.drawy(), 4.725, range, Time.time() * 2.325);
		Draw.color(Color.valueOf("#FF4E2C"));
		Lines.stroke(5);
		Lines.circle(tile.drawx(), tile.drawy(), rnd * 2);
		const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(), range)
		if(target != null){
			const ang = entity.angleTo(target);
			Draw.color(Color.valueOf("#ffffff85"));
			Drawf.tri(tile.drawx(), tile.drawy(), 4.725, Mathf.dst(tile.drawx(), tile.drawy(), target.x, target.y) * 1.5, ang);
			Lines.stroke(1.725);
			Lines.square(target.x, target.y,  11, Time.time() * 2.5);
			Lines.square(target.x, target.y, 6.725, -Time.time() * 2.5);
		}
		Draw.blend();
	},
    drawPlace(x, y, rotation, valid){
    	const tX = x * Vars.tilesize + this.offset();
		const tY = y * Vars.tilesize + this.offset();
        Draw.blend(Blending.additive);
		Draw.color(Color.valueOf("#FF4E2C37"));
		Fill.circle(tX, tY, range - 15);
		Draw.color(Color.valueOf("#ffffff30")); 
		Fill.circle(tX, tY, rnd * 2);
		Draw.color(Color.valueOf("#ffffff"));
		Lines.stroke(30);
		Lines.circle(tX, tY, range - 15 );
		Fill.circle(tX, tY, 5);
		Draw.color(Color.valueOf("#ffffff75"));
		Lines.stroke(3.125);
		for(var i = 0; i < 4; i++){
			Lines.circle(tX, tY, (range - 80) / Math.pow(i,2));
		}
		Draw.color(Color.valueOf("#FF4E2C"));
		Lines.stroke(5);
		Lines.circle(tX, tY, rnd * 2);
		Draw.blend();
    },
	draw(tile){
		const entity = tile.ent;
		Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
		Draw.rect(this.region,tile.drawx(),tile.drawy())
		Draw.alpha(/*(entity.reload / 60) * */tile.entity.items.total() / this.itemCapacity);
		Draw.blend(Blending.additive);
		Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
		Draw.blend();
        Draw.color();
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name + "-bottom"),
			Core.atlas.find(this.name)
		];
	},
	buildConfiguration(tile, table){
		const entity = tile.ent;
		table.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
			tile.configure(0)
		})).size(50).disabled(boolf(b => tile.entity != null && !tile.entity.cons.valid()))
	},
	configured(tile, value){
		const entity = tile.ent;
		const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(),1070);
		if(tile.entity.cons.valid() && target != null){
			Effects.effect(zinaexplode, tile)
			Sounds.explosionbig.at(tile);
			//entity.reload = 0;
			for(var i = 0; i < 4; i++){
				Time.run(5 * i, run(() => {
					const randx = tile.drawx() + Mathf.random(-rnd, rnd);
					const randy = tile.drawy() + Mathf.random(-rnd, rnd);
					const ang = Math.atan2(target.y - randy, target.x- randx) * 180 / 3.1415;
					Effects.effect(airRaidAttack, Color.valueOf("#ffffff75"), randx, randy,0);
					Calls.createBullet(airRaidAttackMissile, tile.getTeam(), randx, randy, ang, 1, 1);
				}))
			}
		tile.entity.cons.trigger()
		}
	}
});
AirRaid.timer = 2;
AirRaid.entityType=prov(()=>extend(TileEntity,{
    gettileInfo(){return this._tileInfo},
    settileInfo(value){this._tileInfo = value},
    _tileInfo:{},
	getinitLength(){return this._initLength},
    setinitLength(value){this._initLength = value},
    _initLength: -1,
    
    getreload(){return this._reload},
    setreload(value){this._reload = value},
    _reload: 0
}));

function bulletCo(chance){
	switch (chance){
		case 0 : return effectColor;
		case 1 : return effectColor2;
		case 2 : return effectColor3;
    }
}

function remove(array, index){
	if(index <= (array.length - 1)){
		for(var i = index; index < array.length; i++){
			array[i] = array[i + 1];
		}
	}
}

const LightningStormFrag = extend(MissileBulletType,{
	update(b){
		if(Mathf.chance(Time.delta() * 0.02)){
			Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 75, b.x , b.y , b.rot(), Mathf.random(65, 90));
			for(var i = 0; i < 2; i++){
				Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 50, b.x , b.y , Mathf.random(360), Mathf.random(15, 28));
			}
		}
		if(b.timer.get(1,4)){
			Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 25, b.x , b.y , Mathf.random(360), Mathf.random(7, 15));
		}
	},
	draw(b){
		Draw.color(Color.valueOf("A0CCFF"));
		Fill.circle(b.x, b.y, 3.125);
		Draw.color(Color.valueOf("A0CCFF"));
		Fill.circle(b.x, b.y, 1.65);
	}
});
LightningStormFrag.damage = 0;
LightningStormFrag.speed = 2.725;
LightningStormFrag.collidesTiles = false,
LightningStormFrag.collides = false,
LightningStormFrag.collidesAir = false,
LightningStormFrag.frontColor = Color.valueOf("CEFFB4"),
LightningStormFrag.backColor = Color.valueOf("#f0ffba"),
LightningStormFrag.trailColor = Color.valueOf("#f0ffba"),
LightningStormFrag.pierce = false;
LightningStormFrag.bulletSprite = "新视界-波束子弹";
LightningStormFrag.bulletWidth = 37;
LightningStormFrag.despawnEffect = Fx.hitLancer;
LightningStormFrag.hitEffect = Fx.hitLancer;
LightningStormFrag.bulletWidth = 16;
LightningStormFrag.lifetime = 200;

const LightningStorm = extend(BasicBulletType,{
	update(b){
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,500)
		if(target != null) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.425));
		}
		if(b.timer.get(1,4)){
			for(var i = 0; i < 3; i++){
				Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 220, b.x + Mathf.random(-60,60), b.y + Mathf.random(-60,60), Mathf.random(360), Mathf.random(38,50));
			}
			for(var i = 0; i < 5; i++){
				Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 110, b.x + Mathf.random(-60,60), b.y + Mathf.random(-60,60), Mathf.random(360), Mathf.random(12,24));
			}
			for(var i = 0; i < 7; i++){
				Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 60, b.x + Mathf.random(-60,60), b.y + Mathf.random(-60,60), Mathf.random(360), Mathf.random(6,14));
			}
			if(Mathf.chance(Time.delta() * 0.075)){
				Bullet.create(LightningStormFrag,b,b.x,b.y,Mathf.random(360));
			}
		}
	},
	draw(b){
		const plasmas = 6;
		var plasmaRegions = new Array();
		for(var i = 0; i < 6; i++){
			plasmaRegions[i] = "新视界-闪电风暴-plasma-"+i;
		}
		for(var i = 0; i < plasmas; i++){
			var r = 29 + Mathf.absin(Time.time(), 2 + i * 1, 5 - i * 0.5);
			Draw.color(Color.valueOf("#55A1FF"),Color.valueOf("#A0CCFF"), i / 6);
			Draw.alpha((0.37128 + Mathf.absin(Time.time(), 2 + i * 2, 0.3 + i * 0.05)) * 1);
			Draw.rect(Core.atlas.find(plasmaRegions[i]), b.x, b.y,Time.time() * (12 + i * 6) * 1);
		}
	},
	despawned(b){
		Effects.effect(this.despawnEffect, b.x, b.y, b.rot());
		for(var i = 0; i < 12; i++){
			Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 320, b.x , b.y , Mathf.random(360), Mathf.random(60,90));  
			Bullet.create(LightningStormFrag,b,b.x,b.y,Mathf.random(360));
		}
	}
})
LightningStorm.speed = 1,
LightningStorm.damage = 0,
LightningStorm.knockback = 0.2,
LightningStorm.splashDamageRadius = 40,
LightningStorm.splashDamage = 750,
LightningStorm.bulletWidth = 18,
LightningStorm.bulletHeight = 18,
LightningStorm.drag = 0,
LightningStorm.collidesTiles = false,
LightningStorm.hitTiles = false;
LightningStorm.pierce = true,
LightningStorm.hitSize = 0,
LightningStorm.collides = false,
LightningStorm.collidesAir = false,
LightningStorm.lifetime = 720;
LightningStorm.despawnEffect = newEffect(60, e => {
	Draw.color(Color.valueOf("#A0CCFF"));
	Fill.circle(e.x, e.y, e.fout() * 52);
	Lines.stroke(e.fout() * 4.5);
	Lines.circle(e.x, e.y, e.fin() * 80);
	Lines.stroke(e.fout() * 2.75);
	Lines.circle(e.x, e.y, e.fin() * 45);
	const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2);
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
	}})
	Angles.randLenVectors(e.id, 45, 1 + 65 * e.fin(), e.rotation, 360,d);
	const c = new Floatc2({get(x, y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 10);
	}})
	Angles.randLenVectors(e.id, 85, 1 + 160 * e.fin(),  Time.time() * 4, 360,c);
});

//--------------------------------------------------------------------------------------------------------------------------------
//充能时间;充能速度;攻击距离;生成距离
const chargetime = 6000; 
const chargespeed = 1;
const attackrange = 800; 
const spawnrange = 104; 
//--------------------------------------------------------------------------------------------------------------------------------

const zinaexplode2 = newEffect(20, e => {
	Draw.color(Color.valueOf("A0CCFF"),Color.valueOf("A0CCFF"),e.fin());
	for(var i = 0; i < 4; i++){
		Drawf.tri(e.x, e.y, 7, 85 * e.fout(), e.rotation + i * 45);
	}
	Lines.stroke(e.fout() * 3); 
	Lines.circle(e.x, e.y, e.fin() * 40); 
	Draw.color(Color.valueOf("#A0CCFF"));
	Fill.circle(e.x, e.y, e.fout() * 14);
	Draw.color(Color.valueOf("#ffffff"),Color.valueOf("#CDE7FF"),e.fin());
	Fill.circle(e.x, e.y, e.fout() * 7);
});

const LightningStormGenerator = extendContent(Block, "闪电风暴发生器", {
	command:false,
	load(){
		this.super$load();
		Events.on(EventType.WorldLoadEvent, run(event => {
			WorldCommand = true;
			this.command = true;
		}));
	},
	init(){
		this.super$init();
		Events.on(EventType.WorldLoadEvent, run(event => {
			WorldCommand = true;
			this.command = true;
		}));
	},
	placed(tile) {
		const entity = tile.ent();
		this.super$placed(tile);
		entity.initLength = ActiveSuperWeapon.length;
		entity.tileInfo.name = "LightningStormGenerator"
		entity.tileInfo.x = tile.x;
		entity.tileInfo.y = tile.y;
		entity.tileInfo.team = tile.getTeam();
		ActiveSuperWeapon[ActiveSuperWeapon.length] = entity.tileInfo;
	},
	removed(tile){
		const entity = tile.ent();
		this.super$removed(tile);
		ActiveSuperWeapon[entity.initLength] = null;
	},
	update(tile){
		const entity = tile.ent();
		
		
		if(entity.initLength == -1){
			entity.tileInfo = {};
			entity.tileInfo.name = "LightningStormGenerator"
			entity.tileInfo.x = tile.x;
			entity.tileInfo.y = tile.y;
			entity.tileInfo.team = tile.getTeam();
			ActiveSuperWeapon[ActiveSuperWeapon.length] = entity.tileInfo;
			entity.initLength = ActiveSuperWeapon.length;
		}
		if(tile.entity.cons.valid() && entity.shoot == 0){
			entity.chargeProgress += entity.delta() * entity.power.status;
		}
		if(entity.chargeProgress >= chargetime){
			entity.shoot = 1;
			entity.chargeProgress = chargetime;
		}
	},
	onDestroyed(tile){
		const entity = tile.ent();
		this.super$onDestroyed(tile);
		ActiveSuperWeapon[entity.initLength] = null;
		const pre = entity.chargeProgress / chargetime;
		if(pre > 0.3){
			Damage.damage(tile.drawx(), tile.drawy(), 500, 4500);
			for(var i = 0; i < 3; i++){
				Calls.createBullet(LightningStorm, Team.derelict, tile.drawx(), tile.drawy(), Mathf.random(360), 1.125, 0.5)
			}
			for(var i = 0; i < 20; i++){
				Lightning.create(Team.derelict,Color.valueOf("A0CCFF"), 500, tile.drawx(), tile.drawy(), Mathf.random(360), 125);
			}
		}
	},
	drawConfigure(tile){
		const entity = tile.ent();
		const pre = entity.chargeProgress / chargetime;
		const dstl = 18;
		const dsts = 14;
		const str = 6;
		const dstt = 34;
		
		
		Draw.color(Color.valueOf("#A0CCFF28"));
		Draw.blend(Blending.additive);
		Fill.circle(tile.drawx(), tile.drawy(), attackrange);
		Draw.color(Color.valueOf("#ffffff"));
		Lines.stroke(45);
		Lines.circle(tile.drawx(), tile.drawy(),attackrange);
		Fill.circle(tile.drawx(), tile.drawy(), 5);
		Draw.color(Color.valueOf("#ffffff75"));
		Lines.stroke(3.125);
		for(var i = 0; i < 4; i++){
			Lines.circle(tile.drawx(), tile.drawy(), attackrange / Math.pow(i,2));
		}
		Drawf.tri(tile.drawx(), tile.drawy(), 4.725, attackrange,Time.time() * 2.325);
		const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(),attackrange)
		if (target != null && entity.shoot > 0) {
			const ang = Mathf.slerpDelta(0, entity.angleTo(target), 1);
			Draw.color(Color.valueOf("#ffffff85"));
			Drawf.tri(tile.drawx(), tile.drawy(), 4.725, Mathf.dst(tile.drawx(), tile.drawy(),target.x,target.y) + Mathf.dst(tile.drawx(), tile.drawy(),target.x,target.y) * 0.45,ang);
			Lines.stroke(1.725);
			Lines.square(target.x,target.y,  11, Time.time() * 2.5);
			Lines.square(target.x,target.y, 6.725, 45 - Time.time() * 2.5);
			Draw.color(Color.valueOf("#A0CCFF45"));
			Fill.circle(target.x,target.y, spawnrange);
			Draw.color(Color.valueOf("#ffffff90"));
			Lines.stroke(5);
			Lines.circle(target.x,target.y,spawnrange);
		}
		Draw.blend();
		Draw.color(Color.valueOf("#292F3C"));
		Fill.square(tile.drawx() + dstt,tile.drawy() + 40, str * 0.7, 45);
		Lines.stroke(str);
		Lines.lineAngleCenter(tile.drawx(),tile.drawy() + 40, 0, 30);
		Drawf.tri(tile.drawx() + dstl, tile.drawy() + 40, str + 1.075, str + 3 , 0);
		Drawf.tri(tile.drawx() - dstl, tile.drawy() + 40, str + 1.075, str + 3 , 180);
		Draw.color(Color.valueOf("#55A1FF"));
		Draw.blend(Blending.additive);
		Draw.alpha(pre * 2);
		Lines.stroke(str - 2);
		Lines.lineAngleCenter(tile.drawx(),tile.drawy() + 40, 0, 30 * pre);
		Drawf.tri(tile.drawx() + dstl - 1, tile.drawy() + 40, str - 1, str + 0.6 , 0);
		Drawf.tri(tile.drawx() - dstl + 1, tile.drawy() + 40, str - 1, str + 0.6 , 180);
		if(entity.shoot > 0){
			Draw.color(Color.valueOf("#55A1FF"));
			Fill.square(tile.drawx() + dstt,tile.drawy() + 40, str * 0.7 - 2, 45);
		}
		Draw.blend();
	},
	drawPlace(x, y, rotation, valid){
		Draw.color(Color.valueOf("#A0CCFF45"));
		Draw.blend(Blending.additive);
		const realX = x * Vars.tilesize + this.offset();
		const realY = y * Vars.tilesize + this.offset();
		Fill.circle(realX, realY, attackrange);
		Draw.color(Color.valueOf("#ffffff70"));
		Lines.stroke(3.125);
		for(var i = 0; i < 4; i++){
			Lines.circle(realX, realY, attackrange / Math.pow(i,2));
		}
		Draw.color(Color.valueOf("#ffffff"));
		Lines.stroke(45);
		Lines.circle(x * Vars.tilesize + 4, y * Vars.tilesize + 4 ,attackrange );
		Draw.blend();
	},
	draw(tile){
		const entity = tile.ent();
		const pre = entity.chargeProgress / chargetime;
		const plasmas = 4;
		var plasmaRegions = new Array();
		for(var i = 0; i < plasmas; i++){
			plasmaRegions[i] = "新视界-闪电风暴发生器-plasma-"+i;
		}
		Draw.rect(Core.atlas.find(this.name + "-bottom"), tile.drawx(), tile.drawy());
		for(var i = 0; i < plasmas; i++){
			var r = 29 + Mathf.absin(Time.time(), 2 + i * 1, 5 - i * 0.5);
			Draw.color(Color.valueOf("#C6DDFF"),Color.valueOf("#98CCFF"), i / 4);
			Draw.alpha((pre / 8 + Mathf.absin(Time.time(), 2 + i * 2, 0.3 + i * 0.05)) * pre);
			Draw.blend(Blending.additive);
			Draw.rect(Core.atlas.find(plasmaRegions[i]), tile.drawx(), tile.drawy(),Time.time() * (12 + i * 6) * 1);
			if(entity.shoot == 1){
				Draw.color(Color.valueOf("#A0CCFF"));
				Fill.circle(tile.drawx(), tile.drawy(), 3.95 + Mathf.absin(Time.time(), 4, 1.35) + Mathf.random(0.075));
			}
			Draw.blend();
		}
		Draw.color();
		Draw.rect(Core.atlas.find(this.name), tile.drawx(), tile.drawy());
		Draw.color();
	},
	buildConfiguration(tile, table){
		const entity = tile.ent();
		const target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(),attackrange);
		table.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
			if(tile.entity.cons.valid() && entity.shoot == 1 && target != null){
				for(var i = 0; i < 2; i++){
					Calls.createBullet(LightningStorm, tile.getTeam(), target.x + Mathf.random(-spawnrange,spawnrange), target.y + Mathf.random(-spawnrange,spawnrange), Mathf.random(360), 0.425, 1)
				}
			tile.entity.cons.trigger();
			entity.shoot = 0;
			entity.chargeProgress = 0;
			}
		})).size(50).disabled(boolf(b => tile.entity != null && !tile.entity.cons.valid()) || target == null || entity.shoot != 1 || entity.power.status < 0.5);
	},
	generateIcons(){
		return [Core.atlas.find(this.name + "-bottom"),Core.atlas.find(this.name)];
	}
})
LightningStormGenerator.entityType=prov(()=>extend(TileEntity,{
    getchargeProgress(){return this._chargeProgress},
    setchargeProgress(value){this._chargeProgress = value},
    _chargeProgress:0,
    getshoot(){return this._shoot},
    setshoot(value){this._shoot = value},
    _shoot:0,
    gettileInfo(){return this._tileInfo},
    settileInfo(value){this._tileInfo = value},
    _tileInfo:{},
	getinitLength(){return this._initLength},
    setinitLength(value){this._initLength = value},
    _initLength: -1,
    write(stream){
		this.super$write(stream);
		stream.writeFloat(this._shoot);
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._shoot = stream.readFloat();
	}
}));