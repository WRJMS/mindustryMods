const colors反 = [Color.valueOf("7b68ee55"), Color.valueOf("7b68ee"), Color.valueOf("e4ebff")];
const tscales反 = [2, 1.5, 1, 0.825];
const lenscales反 = [1, 1.25, 1.4, 1.45];
const length反 = 350;
const 反物质激光 = extend(ArtilleryBulletType,{
    range(){
        return length反;
    },
	init(b){
		if (b == null) return;
		Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), length反);
	},
    draw(b){
        const f = Mathf.curve(b.fin(), 0, 0.2);
        const baseLen = length反 * f;
        for(var s = 0; s < 3; s++){
            Draw.color(colors反[s]);
            for(var i = 0; i < tscales反.length; i++){
                Lines.stroke(7 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscales反[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales反[i]);
            }
        }
        Draw.reset();
    }
})
反物质激光.damage = 825;
反物质激光.speed = 0.0001;
反物质激光.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 5);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 30 * e.fout(), e.rotation, 360,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 6);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
});
反物质激光.despawnEffect = Fx.none;
反物质激光.collidesTiles = false;
反物质激光.pierce = true;
反物质激光.hitSize = 250;
反物质激光.drawSize = 250;
反物质激光.bulletWidth = 60;
反物质激光.lifetime = 60;
反物质激光.drawSize = length反 * 2.5;
反物质激光.shootEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("#7b68ee"));
    Fill.circle(e.x, e.y, e.fout() * 11.25);
    Draw.color(Color.valueOf("#e4ebff"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 6.725);
});
反物质激光.smokeEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 100);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 28, 1 + 120 * e.fin(), e.rotation, 30,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 4.25);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 40 * e.fin(), e.rotation, 360,c);
});



const 反物质激光器 = extendContent(ChargeTurret,"反物质激光器",{})
反物质激光器.shootType = 反物质激光
反物质激光器.chargeBeginEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("#7b68ee"));
    Fill.circle(e.x, e.y, e.fin() * 7);
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    Fill.circle(e.x, e.y, e.fin() * 4.25);
});

反物质激光器.chargeEffect = newEffect(80, e => {
    Draw.color(Color.valueOf("#7b68ee"),Color.valueOf("#e4ebff"),e.fin());
    
    Lines.stroke(e.fin() * 3);
    Lines.circle(e.x, e.y, e.fout() * 60);
    Lines.stroke(e.fin() * 1.75);
    Lines.circle(e.x, e.y, e.fout() * 45);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 25, 1 + 120 * e.fout(), e.rotation, 100,d);
});