const effectColor = Color.valueOf("#BE91FF");
const effectColor2 = Color.valueOf("ffffff");
const findRange = 12;
const shieldRange = 180;

const FinalResercher = extendContent(Block, "EOE-researcher", {
	dialog: null,
	load(){
		this.super$load();
		this.dialog = new FloatingDialog(Core.bundle.get("FinalTurret.Reserch.tit"))
		this.dialog.addCloseButton();
	},
	onConfigureTileTapped(tile, other){
		const entity = tile.ent();

		if(this.linkValid(tile, other)){
			this.otherReset(tile);
			other.entity.linked = true;
			entity.link = other;
			entity.linkedX = other.x;
			entity.linkedY = other.y;
			return false;
		}
		return true;
	},
	linkValid(tile, other){
		const entity = tile.ent();
		if(other == null || tile == null || other.block() == null) return false;
		if(other.block() == FinalTurret){
			if(!other.entity.linked && entity.link == null){
				return true;
			};
		}else return false;
	},
	upgradeMult(){
		return Vars.state.rules.infiniteResources ? 0 : 1200;
	},
	setBars(){
		this.super$setBars();
		this.bars.add("UpgradeProgress", func(entity => {
			var bar = new Bar(prov( () => "UpgradeProgress"), prov( () => Color.valueOf("#FF8E00")), floatp( () => entity.upgradeProgress / (this.upgradeMult() * entity.commandLevel) ));
			return bar;
		}));
		this.bars.add("Level", func(entity => {
			var bar = new Bar(prov( () => "Level"), prov( () => effectColor), floatp( () => (entity.mainLevel + 1) / 6));
			return bar;
		}));
	},
	buildConfiguration(tile, table){
		const entity = tile.ent();
		
		table.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
			this.makelist(tile);
			this.dialog.show();
		})).size(50).disabled(boolf(b => entity.link == null ));
		table.addImageButton(Icon.cancel, Styles.clearTransi, run(() => {
			this.otherReset(tile);
			entity.link = null;
		})).size(50).disabled(boolf(b => entity.link == null ));
	},
	removed(tile){
		this.super$removed(tile);
		this.otherReset(tile);
	},
	onDestroyed(tile){
		this.super$onDestroyed(tile);
		this.otherReset(tile);
	},
	otherReset(tile){
		const entity = tile.ent();
		const other = entity.link;
		entity.linkedX = -1;
		entity.linkedY = -1;
		if(other != null){
			if(other.block() == FinalTurret){
				other.entity.level = 0;
				other.entity.shootMod = 0;
				other.entity.attackMethod = 0;
				other.entity.linked = false;
				other = null;
			}
		}
	},
	//Tile Modes Describe UI.Show Method▼
	
	makesingle(tile, skill){
		const entity = tile.ent();
		const infod = new FloatingDialog(Core.bundle.get("FinalTurret.Reserch.tit"));
		infod.cont.pane(cons(table => {
			if(skill == 7){
				table.table(cons(title => {
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
					title.addImage(Core.atlas.find("新视界-Skill-1")).size(144);
					title.add(Core.bundle.get("FinalTurret.Reserch.skill1")).padLeft(5).color(Pal.accent);
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
				}));
			}else if(skill != 100){
				table.table(cons(title => {
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
					title.addImage(Core.atlas.find("新视界-Skill-" + skill)).size(144);
					title.add(Core.bundle.get("FinalTurret.Reserch.skill-" + skill)).padLeft(5).color(Pal.accent);
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
				}));
			}else{
				table.table(cons(title => {
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
					title.addImage(Core.atlas.find("新视界-end-of-era")).size(256);
					title.add(Core.bundle.get("FinalTurret.Reserch.turret")).padLeft(5).color(Pal.accent);
					title.row();
					title.addImage().height(3).color(Color.lightGray).pad(15).padLeft(0).padRight(0).fillX();
					title.row();
				}));
			}
		}));
		infod.addCloseButton();
		infod.show();
	},
	largeRow(table){
		table.row();
		table.add("").growX().left();
		table.row();
	},
	
	//Tile UI.Show Main Method▼
	
	makelist(tile){
		const entity = tile.ent();
		const height = 4 ;
		const colorA = Color.valueOf("FF5800");
		const colorGreen = Color.valueOf("#39FF77");
		
		this.dialog.cont.clear();
		this.dialog.cont.pane(cons(table => {
			//Tile UseAble Mode UI.Show Method▼
			
			//					</DEBUG>
			//this.largeRow(table);
			//table.add("Instanceof this.dialog => \n" + (this.dialog) ).growX().color(colorGreen);
			//this.largeRow(table);
			//					<DEBUG/>
			
			//Top "Status" UI.Show Method▼
			this.largeRow(table);
			table.addImage().growX().height(5).pad(10).color(colorGreen);
			table.row();
			//table.setAlignment(Align.center);
			table.row();
			table.add("<Status>").growX().color(colorGreen);
			table.row();
			table.addImage().growX().height(5).pad(10).color(colorGreen);
			this.largeRow(table);
			//t.UI
			table.table(Styles.black6, cons(t => {
				if(entity.mainLevel != 5){
					t.table(cons(upgradeTable => {
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
						upgradeTable.add(Core.bundle.get("FinalTurret.Reserch.upgrade") +  ": Lv." + (entity.mainLevel + 2)).growX().left().color(Color.valueOf("ffffff"));
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
						//title.UI
						upgradeTable.table(cons(title => {
							title.left();
							title.addImage(Core.atlas.find("新视界-2upgrade")).size(60);
							title.right();
							title.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
								if(entity.mainLevel < 5 && entity.commandLevel < 5 && entity.commandLevel == entity.mainLevel)entity.commandLevel ++
							})).size(60);
							title.addImageButton(Icon.infoCircle, Styles.clearTransi, run(() => {
								this.makesingle(tile, 100);
							})).size(60).padRight(10);
						})).growX().left().padTop(0).padRight(0);
						//title.UI END
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
					})).growX().left().padTop(0).padRight(10);
					this.largeRow(t);
				}else{
					t.table(cons(upgradeTable => {
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(colorGreen);
						upgradeTable.row();
						upgradeTable.add(Core.bundle.get("FinalTurret.Reserch.upgrade.tip")).growX().left().color(colorGreen);
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(colorGreen);
						upgradeTable.row();
					})).growX().left().padTop(0).padRight(10);
					this.largeRow(t);
				}
				
				if(entity.mainLevel == 5 && entity.secLevel != 7){
					t.table(cons(upgradeTable => {
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
						upgradeTable.add(Core.bundle.get("FinalTurret.Reserch.skill") +  ": ").growX().left().color(Color.valueOf("ffffff"));
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
						//title.UI
						upgradeTable.table(cons(title => {
							title.left();
							title.addImage(Core.atlas.find("新视界-Skill-1")).size(60);
							title.right();
							title.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
								if(entity.secLevel == 0)entity.secLevel = 7;
							})).size(60);
							title.addImageButton(Icon.infoCircle, Styles.clearTransi, run(() => {
								this.makesingle(tile, 7);
							})).size(60);
						})).growX().left().padTop(0).padRight(10);
						//title.UI END'
						upgradeTable.row();
						upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
						upgradeTable.row();
					})).growX().left().padTop(0).padRight(10);
					this.largeRow(t);
				}
				
				//Tile Upgrade Mode Select UI.Show Method▼
				t.table(cons(upgradeTable => {
					this.largeRow(upgradeTable);
					this.largeRow(upgradeTable);
					upgradeTable.row();
					upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
					upgradeTable.row();
				
					upgradeTable.add(Core.bundle.get("FinalTurret.Reserch.attackMode")).growX().color(Color.valueOf("ffffff"));
					upgradeTable.row();
				
					upgradeTable.row();
					upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
					upgradeTable.row();
					
					this.modChange(tile, upgradeTable, 0);
					this.modChange(tile, upgradeTable, 2);
					this.modChange(tile, upgradeTable, 5);
					this.modChange(tile, upgradeTable, 8);
				
					upgradeTable.row();
					upgradeTable.addImage().growX().height(5).pad(10).color(Pal.accent);
					upgradeTable.row();
				})).growX().left().padTop(0).padRight(10);
			
			})).width(Vars.mobile ? 460 : 530);
			
			this.largeRow(table);
			table.addImage().growX().height(5).pad(10).color(colorGreen);
			table.row();
			table.add("<TILE CONDITION>").growX().color(colorGreen);
			table.row();
			table.addImage().growX().height(5).pad(10).color(colorGreen);
			this.largeRow(table);
			
			table.add("Level: " + (entity.mainLevel + 1)).growX().left().color(Color.valueOf("ffffff"));
			this.largeRow(table);
			
			
			table.table(Styles.black6, cons(t => {
				t.row();
				t.addImage().growX().height(5).pad(10).color(Pal.accent);
				t.add("<AttackMethod>").growX().color(Pal.accent);
				t.row();
				//title.UI
				t.table(cons(title => {
					title.right();
					title.addImage(Core.atlas.find("新视界-Skill-" + entity.attackMethod)).size(60);
					title.right();
					if(entity.secLevel == 7)title.addImage(Core.atlas.find("新视界-Skill-1")).size(60);
					title.right();
				})).growX().left().padTop(0).padRight(10);
			})).width(Vars.mobile ? 460 : 530);
		})).width(Vars.mobile ? 460 : 530);
	},
	
	//Tile Upgrade Mode Select UI.Show Method▼
	
	modChange(tile, table, mod){
		const entity = tile.ent();
		var core = Vars.state.teams.get(Vars.player.getTeam()).cores.first();
		if(entity.attackMethod != mod){
			table.row();
			table.table(cons(title => {
				title.addImage(Core.atlas.find("新视界-Skill-" + mod)).size(60);
				title.right();
				title.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
					entity.attackMethod = mod;
				})).size(60);
				title.addImageButton(Icon.infoCircle, Styles.clearTransi, run(() => {
					this.makesingle(tile, mod);
				})).size(60);
			})).growX().left().padTop(0).padRight(10);
		}
	},
	
	//Function : update
	
	update(tile){
		const entity = tile.ent();
		
		//Tile Load Method▼
		
		if(entity.check){
			//if(this.dialog != null && typeof this.dialog == "object")this.dialog.addCloseButton();
			if(entity.linkedX >= 0 && entity.linkedY >= 0){
				entity.link = Vars.world.tile(entity.linkedX, entity.linkedY);
				entity.link.entity.linked = true;
			}else entity.link = null;
			entity.check = false;
		};
		const other = entity.link;
		
		//Mod Change Method▼
		
		if(other != null){
			if(other.block() != null){
				if(other.block() == FinalTurret){
					if(other.entity.level < entity.mainLevel)other.entity.level = entity.mainLevel;
					if(other.entity.shootMod != entity.secLevel)other.entity.shootMod = entity.secLevel;
					if(other.entity.attackMethod != entity.attackMethod)other.entity.attackMethod = entity.attackMethod;
				}
			}
		}
		
		//Upgrade Effect Method▼
		
		if(entity.commandLevel > entity.mainLevel){
			entity.upgradeProgress += entity.power.status;
			if(Mathf.chance(0.075 * entity.power.status)){
				Effects.effect(Fx.smeltsmoke, tile.drawx() + Mathf.range(this.size * Vars.tilesize / 2), tile.drawy() + Mathf.range(this.size * Vars.tilesize / 2));
			}
		}
		
		if(other != null && entity.commandLevel > entity.mainLevel && entity.upgradeProgress > this.upgradeMult() * entity.commandLevel){
			entity.upgradeProgress = 0;
			entity.mainLevel ++;
			if(other.block() == FinalTurret)other.entity.level = entity.mainLevel;
			Effects.effect(newEffect(35,e => {
				Draw.color(e.color);
				Draw.alpha(e.fout());
				Lines.stroke(2.45 - e.fin() * 2);
				Lines.square(e.x, e.y, e.rotation * Vars.tilesize / 2 + e.fin() * 3);
			}),effectColor, tile.drawx(), tile.drawy(), tile.block().size);
			Effects.effect(newEffect(35,e => {
				Draw.color(e.color);
				Draw.alpha(e.fout());
				Lines.stroke(3 - e.fin() * 2);
				Lines.square(e.x, e.y, e.rotation * Vars.tilesize / 2 + e.fin() * 3);
			}),effectColor, other.drawx(), other.drawy(), other.block().size);
			Effects.effect(newEffect(180,e => {
				Draw.color(e.color);
				const si = 55 * e.fout()
				Draw.rect(Core.atlas.find("新视界-upgrade"), e.x, e.y, si, si, si, si, 0);
			}),effectColor, other.drawx(), other.drawy(), 0);
			Effects.effect(Fx.healBlockFull, effectColor, tile.drawx(), tile.drawy(), this.size);
		}
	},
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name + "-" + entity.mainLevel), tile.drawx(), tile.drawy());
	},
	drawConfigure(tile){
		const entity = tile.ent();
		Draw.color(effectColor);
		Lines.square(tile.drawx(), tile.drawy(),this.size * Vars.tilesize / 2.0 );
		const other = entity.link;
		if(other != null){
			if(other.block() == FinalTurret){
				Draw.color(effectColor);
				Lines.square(other.drawx(), other.drawy(), other.block().size * Vars.tilesize / 2.0 );
				const sin = Mathf.absin(Time.time(), 6, 1);
				Tmp.v1.set(tile.drawx(), tile.drawy() ).sub(other.drawx(), other.drawy() ).limit((this.size / 2 + 1) * Vars.tilesize + sin + 0.5);
				const x2 = tile.drawx() - Tmp.v1.x;
				const y2 = tile.drawy() - Tmp.v1.y;
				const x1 = other.drawx() + Tmp.v1.x;
				const y1 = other.drawy() + Tmp.v1.y;
				const segs = Math.floor(other.dst(tile.drawx(), tile.drawy()) / Vars.tilesize);
			
				Lines.stroke(4, Pal.gray);
				Lines.dashLine(x1, y1, x2, y2, segs);
				Lines.stroke(2, effectColor);
				Lines.dashLine(x1, y1, x2, y2, segs);
				Drawf.circles(tile.drawx(), tile.drawy(), (this.size / 3 + 1) * Vars.tilesize + sin - 2, effectColor);
				Drawf.arrow(tile.drawx(), tile.drawy(), other.drawx(), other.drawy(), 2 * Vars.tilesize + sin, 4 + sin, effectColor);
				Drawf.square(other.drawx(), other.drawy(), (this.size / 3 + 1) * Vars.tilesize + 3, effectColor);
				Drawf.square(other.drawx(), other.drawy(), other.block().size * Vars.tilesize / 2 + 9, effectColor);
				Draw.reset();
			};
		};
		Draw.reset();
	}
});
FinalResercher.size = 3;
FinalResercher.consumes.power(30);

FinalResercher.configurable = true;
FinalResercher.update = true;
FinalResercher.localizedName = Core.bundle.get("Block."+ "FinalResercher" +".name");
FinalResercher.description = Core.bundle.get("Block."+ "FinalResercher" +".description");
FinalResercher.entityType=prov(()=>extend(TileEntity,{
	//gettext(){return this._text},
	//settext(value){this._text = value},
	//_text: new FloatingDialog(Core.bundle.get("FinalTurret.Reserch.tit")),
	getlink(){return this._link},
	setlink(value){this._link = value},
	_link: null,
	getmainLevel(){return this._mainLevel},
	setmainLevel(value){this._mainLevel = value},
	_mainLevel: 0,
	getcommandLevel(){return this._commandLevel},
	setcommandLevel(value){this._commandLevel = value},
	_commandLevel: 0,
	getupgradeProgress(){return this._upgradeProgress},
	setupgradeProgress(value){this._upgradeProgress = value},
	_upgradeProgress: 0,
	getsecLevel(){return this._secLevel},
	setsecLevel(value){this._secLevel = value},
	_secLevel: 0,
	getattackMethod(){return this._attackMethod},
	setattackMethod(value){this._attackMethod = value},
	_attackMethod: 0,
	getcheck(){return this._check},
	setcheck(value){this._check = value},
	_check: true,
	
	getlinkedX(){return this._linkedX},
	setlinkedX(value){this._linkedX = value},
	_linkedX: -1,
	getlinkedY(){return this._linkedY},
	setlinkedY(value){this._linkedY = value},
	_linkedY: -1,
	
	write(stream){
		this.super$write(stream);
		stream.writeFloat(this._mainLevel);
		stream.writeFloat(this._upgradeProgress);
		stream.writeFloat(this._commandLevel);
		stream.writeFloat(this._secLevel);
		stream.writeFloat(this._attackMethod);
		stream.writeFloat(this._linkedX);
		stream.writeFloat(this._linkedY);
		
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._mainLevel = stream.readFloat();
		this._upgradeProgress = stream.readFloat();
		this._commandLevel = stream.readFloat();
		this._secLevel = stream.readFloat();
		this._attackMethod = stream.readFloat();
		this._linkedX = stream.readFloat();
		this._linkedY = stream.readFloat();
	}
}));
//------------------------------------------------------------------------------------------------------------
//Upgrade Tile JavaScript ▲

//◆Effects Scr.Begin
const plaInit = newEffect(45,e => {
	Draw.color(effectColor, effectColor2,e.fin() * 0.75);
	Fill.circle(e.x, e.y, e.fout() * 10 + 2);
	Lines.stroke(e.fout() * 1.4);
	Lines.circle(e.x, e.y, e.fin() * 60);
})

const plaShoot = newEffect(22,e => {
	Draw.color(effectColor, effectColor2, e.fin() * 0.5);
	const d = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 10 + 4);
	}}) 
	Angles.randLenVectors(e.id, 7, 56 * e.fin(), e.rotation, 30,d);
})

const missileShootSmoke = newEffect(25,e => {
	Draw.color(effectColor, effectColor2, e.fin() * 0.5);
	Drawf.tri(e.x, e.y, 4 * e.fout(), 28 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 4 * e.fout(), 28 * e.fout(), e.rotation + 270);
});

const missileShoot = newEffect(25,e => {
	Draw.color(effectColor, effectColor2,e.fin() * 0.5);
    const d = new Floatc2({get(x,y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 4);
	}}) 
	Angles.randLenVectors(e.id, 5, 60 * e.fin(), e.rotation, 15,d);
});

const shieldDefense = newEffect(20, e => {
	Draw.color(effectColor);
	Lines.stroke(e.fslope() * 2.5);
	Lines.poly(e.x, e.y, 6, 4 * e.fout() + 16);
	const d = new Floatc2({get(x, y){
		Lines.poly(e.x + x, e.y + y, 6, 4 * e.fout() + 4);
	}})
	Angles.randLenVectors(e.id, 2, 32 * e.fin(), 0, 360,d);
});
//◆Effects Scr.End

//Bullets JavaScript ▼
//------------------------------------------------------------------------------------------------------------

const energyPloy = extend(MissileBulletType,{
	update(b){
		Effects.effect(newEffect(40,e => {
			Draw.color(e.color, Color.valueOf("#564262"), e.fin());
			const trnsB = new Vec2();
			trnsB.trns(e.rotation, e.fin() * (12));
			Fill.poly(e.x + trnsB.x, e.y + trnsB.y, 6, e.fout() * 9, e.rotation);
		}), b.x, b.y, b.rot());
		if(b.timer.get(0,2)){
			Effects.effect(newEffect(40,e => {
				Draw.color(e.color, Color.valueOf("#564262"), e.fin());
				const hl = new Floatc2({get: function(x, y){
					Fill.poly(e.x + x, e.y + y, 6, e.fout() * 9, e.rotation);
				}});
				Angles.randLenVectors(e.id, 3, e.finpow() * 42, e.rotation, 190, hl);
			}),effectColor, b.x, b.y, b.rot());
		}
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,720)
		if(target != null && b.time() > 20) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.225));
		}
		if(target != null){
			if(Mathf.dst(b.x, b.y, target.x, target.y) < 40){
				if(b.timer.get(2,3)){
					Lightning.create(b.getTeam(),effectColor, 90, b.x , b.y , Mathf.random(360), Mathf.random(8, 12));
				}
			}
		}
	},
	draw(b){}
});
energyPloy.splashDamage = 25;
energyPloy.damage = 120;
energyPloy.splashDamageRadius = 40;
energyPloy.speed = 4;
energyPloy.lifetime = 600;
energyPloy.collidesTiles = false;
energyPloy.pierce = true;
energyPloy.frontColor = effectColor2;
energyPloy.backColor = effectColor;
energyPloy.hitEffect = newEffect(40,e => {
	Draw.color(effectColor);
	const f = new Floatc2({get(x, y){
		Fill.poly(e.x + x, e.y + y, 6, 10 * e.fout());
	}})
	Angles.randLenVectors(e.id, 1, 80 * e.fin(), 0, 360,f);
});

//------------------------------------------------------------------------------------------------------------

const energyTro = extend(MissileBulletType,{
	update(b){
		if(b.timer.get(1,3) && b.time() > 5){
			Effects.effect(newEffect(35,e => {
				Draw.color(e.color);
				const hl = new Floatc2({get: function(x, y){
					Fill.poly(e.x + x, e.y + y, 6, e.fout() * 4, e.rotation - 180);
				}});
				Angles.randLenVectors(e.id, 2, e.finpow() * 30, e.rotation - 180, 50, hl);
			}),effectColor, b.x, b.y, b.rot());
		}
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,720)
		if (target != null && b.time() > 20) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.1075));
		}
	}
});
energyTro.splashDamage = 35;
energyTro.bulletSprite = "新视界-冲击子弹";
energyTro.damage = 600;
energyTro.splashDamageRadius = 60;
energyTro.bulletWidth = 9;
energyTro.bulletHeight = 35;
energyTro.speed = 7;
energyTro.backColor = effectColor;
energyTro.frontColor = effectColor2;
energyTro.hitEffect = newEffect(16,e => {
	Draw.color(effectColor,effectColor2,e.fin() * 0.7);
	const d = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 4);
	}})
	Angles.randLenVectors(e.id, 3, 1 + 20 * e.fin(),e.rotation, 360,d);
});
energyTro.hitSize = 4;
energyTro.lifetime = 140;
energyTro.pierce = false;

//------------------------------------------------------------------------------------------------------------

const energyMissile = extend(FlakBulletType,{
	update(b){
		this.super$update(b);
		if(b.time() > 6){
			Effects.effect(newEffect(25,e => {
				Draw.color(effectColor,effectColor2,e.fin() * 0.4);
				Lines.stroke(e.fout() * 2.45);
				Lines.lineAngle(e.x, e.y, e.rotation - 180, e.fout() * 22 + 28);
			}),effectColor, b.x, b.y, b.rot());
		}
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,720)
		if (target != null && b.time() > 3) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.02));
		}
	}
});
energyMissile.splashDamage = 1300;
energyMissile.explodeRange = 50;
energyMissile.bulletSprite = "新视界-冲击子弹";
energyMissile.damage = 1000;
energyMissile.splashDamageRadius = 80;
energyMissile.bulletWidth = 11;
energyMissile.bulletHeight = 50;
energyMissile.speed = 9;
energyMissile.lifetime = 120;
energyMissile.frontColor = effectColor2;
energyMissile.backColor = effectColor;
energyMissile.hitEffect = newEffect(20,e => {
	Draw.color(effectColor,effectColor2,e.fin() * 0.7);
	const d = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 4);
	}})
	Angles.randLenVectors(e.id, 7, 1 + 60 * e.fin(),e.rotation, 360,d);
	Lines.stroke(e.fout() * 1.4);
	Lines.circle(e.x, e.y, e.fin() * 60);
});

//------------------------------------------------------------------------------------------------------------
const finalTirretShield = extend(BasicBulletType,{
	update(b){
		const realRange = shieldRange * b.fout();
		Vars.bulletGroup.intersect(b.x - realRange, b.y - realRange, realRange * 2, realRange * 2, cons(trait =>{
			if(trait.canBeAbsorbed() && trait.getTeam() != b.getTeam() && Intersector.isInsideHexagon(trait.getX(), trait.getY(), realRange, b.x, b.y) ){
				trait.absorb();
				Effects.effect(shieldDefense, trait);
			}
        }));
	},
	init(b){
		if(b == null)return;
		Effects.effect(newEffect(35,e => {
			Draw.color(effectColor);
			Lines.stroke(e.fout() * 4); 
			Lines.poly(e.x, e.y, 6, shieldRange * 0.525 + 75 * e.fin());
		}), effectColor, b.x, b.y, b.rot());
	},
	draw(b){
		Draw.color(effectColor);
		Lines.stroke(b.fout() * 3); 
		Lines.poly(b.x, b.y, 6, (shieldRange * 0.525) * b.fout() * b.fout());
		Draw.alpha(b.fout() * b.fout() * 0.3);
		Fill.poly(b.x, b.y, 6, (shieldRange * 0.525) * b.fout() * b.fout());
	}
});
finalTirretShield.damage = 0;
finalTirretShield.speed = 0;
finalTirretShield.lifetime = 80;
finalTirretShield.despawnEffect = Fx.none;
//------------------------------------------------------------------------------------------------------------

//子弹配置▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const continueLaser = extend(BasicBulletType,{
	laserColors: [Color.valueOf("B887FF55"), effectColor, effectColor2],
	laserStrokes: [1,0.5,0.3],
	laserTscales: [2, 1.5, 1, 0.825],
	laserLenscales: [1, 1.125, 1.2, 1.25],
	laserLength: 720,
	laserWidth: 17,
	strl: 5,
    range(){
        return this.laserLength;
    },
    lineLaser(b, baseLen, laserColors, laserStrokes, laserTscales, laserLenscales, ang, x, y){
		for(var s = 0; s < laserColors.length; s++){
			Draw.color(Color().set(laserColors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
			for(var i = 0; i < laserTscales.length; i++){
				Lines.stroke((this.strl + Mathf.absin(Time.time(), 0.8, 1)) * b.fout() * laserStrokes[s] * laserTscales[i]);
				Lines.lineAngle(x, y, ang, baseLen * laserLenscales[i]);
			};
		};
		const trnsLen = new Vec2();
		trnsLen.trns(ang, baseLen * laserLenscales[laserLenscales.length - 1]);
		Vars.renderer.lights.line(x, y, x + trnsLen.x, y + trnsLen.y);
		Draw.reset();
	},
//更新函数配置▼[特效/伤害] 运用向量--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    update(b){   	
    	const ang = b.rot();
        const len = this.range();
	    if(b.timer.get(1, 5)){
	        Effects.shake(1, 1, b.x, b.y);
			if(Mathf.chance(Time.delta() * 0.7)){
		        Effects.effect(plaShoot,Color.valueOf("ffffff00"), b.x, b.y, b.rot());
				Effects.effect(plaShoot,Color.valueOf("ffffff00"), b.x + Angles.trnsx(ang - 90, this.laserWidth), b.y + Angles.trnsy(ang - 90, this.laserWidth), b.rot());
				Effects.effect(plaShoot,Color.valueOf("ffffff00"), b.x + Angles.trnsx(ang + 90, this.laserWidth), b.y + Angles.trnsy(ang + 90, this.laserWidth), b.rot());
			}
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), len);
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x + Angles.trnsx(ang - 90, this.laserWidth), b.y + Angles.trnsy(ang - 90, this.laserWidth), b.rot(), len);
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x + Angles.trnsx(ang + 90, this.laserWidth), b.y + Angles.trnsy(ang + 90, this.laserWidth), b.rot(), len);
        }
    },
//子弹绘制▼运用向量--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    draw(b){
    	const ang = b.rot();
        const strl = 3;
        //向量配置▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        const trx1 = b.x + Angles.trnsx(ang - 90, this.laserWidth);
        const try1 = b.y + Angles.trnsy(ang - 90, this.laserWidth);
        const trx2 = b.x + Angles.trnsx(ang + 90, this.laserWidth);
        const try2 = b.y + Angles.trnsy(ang + 90, this.laserWidth);
        //绘制▼激光--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        const baseLen = this.range()
		this.lineLaser(b, baseLen, this.laserColors, this.laserStrokes, this.laserTscales, this.laserLenscales, ang, b.x, b.y);
		this.lineLaser(b, baseLen, this.laserColors, this.laserStrokes, this.laserTscales, this.laserLenscales, ang, trx1, try1);
        this.lineLaser(b, baseLen, this.laserColors, this.laserStrokes, this.laserTscales, this.laserLenscales, ang, trx2, try2);
        
        //绘制▼源--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        Draw.color(effectColor);
        const circleMult = 1.1;
	    Fill.circle(b.x, b.y, b.fout() * this.strl * circleMult);
		Fill.circle(trx1, try1, b.fout() * this.strl * circleMult);
		Fill.circle(trx2, try2, b.fout() * this.strl * circleMult);
		const stork = 3.125 * b.fout();
		Drawf.tri(b.x, b.y, stork, 72 * b.fout(), 180);
		Drawf.tri(b.x, b.y, stork, 72 * b.fout(), 0);
		Drawf.tri(trx1, try1, stork, 72 * b.fout(), 180);
		Drawf.tri(trx1, try1, stork, 72 * b.fout(), 0);
		Drawf.tri(trx2, try2, stork, 72 * b.fout(), 180);
		Drawf.tri(trx2, try2, stork, 72 * b.fout(), 0);
		
	    Draw.color(effectColor2);
	    Fill.circle(b.x, b.y, b.fout() * this.strl * 0.8 * circleMult);
		Fill.circle(trx1, try1, b.fout() * this.strl * 0.8 * circleMult);
		Fill.circle(trx2, try2, b.fout() * this.strl * 0.8 * circleMult);
    }
})
//子弹基本内容配置▼---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
continueLaser.damage = 450;
continueLaser.speed = 0.0001;
continueLaser.hitEffect = newEffect(25,e => {
	Draw.color(effectColor, effectColor2, e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 3, 1 + 40 * e.fin(), e.rotation, 30,d);
});
continueLaser.despawnEffect = Fx.none;
continueLaser.drawSize = 720 * 2.5;
continueLaser.lifetime = 60;
continueLaser.pierce = true;
continueLaser.shootEffect = Fx.none;
continueLaser.smokeEffect = Fx.none;
//------------------------------------------------------------------------------------------------------------
//Laser Info Seg. ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const colorFinal = [Color.valueOf("B887FF55"), effectColor, effectColor2];
const tscalesFinal = [2, 1.5, 1, 0.825];
const lenscalesFinal = [1, 1.125, 1.2, 1.25];
const lengthFinal = 720;
const strokesFinal = [1,0.5,0.3];
const lenFinal = 120;
//Bullet Seg. ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const FinalLaser = extend(BasicBulletType,{
	angVel1: 160,
	angVel2: 140,
    range(){
        return lengthFinal;
    },
	init(b){
		if (b == null) return;
		const ang = b.rot()
		const trx1 = b.x + Angles.trnsx(ang - this.angVel1, lenFinal);
        const try1 = b.y + Angles.trnsy(ang - this.angVel1, lenFinal);
        const trx2 = b.x + Angles.trnsx(ang + this.angVel1, lenFinal);
        const try2 = b.y + Angles.trnsy(ang + this.angVel1, lenFinal);
        
        const trx3 = b.x + Angles.trnsx(ang - this.angVel2, lenFinal);
        const try3 = b.y + Angles.trnsy(ang - this.angVel2, lenFinal);
        const trx4 = b.x + Angles.trnsx(ang + this.angVel2, lenFinal);
        const try4 = b.y + Angles.trnsy(ang + this.angVel2, lenFinal);
        Effects.effect(plaInit,Color.valueOf("ffffff00"), trx1, try1, 0);
		Effects.effect(plaInit,Color.valueOf("ffffff00"), trx2, try2, 0);
		Effects.effect(plaInit,Color.valueOf("ffffff00"), trx3, try3, 0);
		Effects.effect(plaInit,Color.valueOf("ffffff00"), trx4, try4, 0);
	},
//Update Seg. ▼ [Effects/Damage] Vector Uses--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	update(b){
		const ang = b.rot()
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,lengthFinal - Vars.tilesize);
		
    	
        const trx1 = b.x + Angles.trnsx(ang - this.angVel1, lenFinal);
        const try1 = b.y + Angles.trnsy(ang - this.angVel1, lenFinal);
        const trx2 = b.x + Angles.trnsx(ang + this.angVel1, lenFinal);
        const try2 = b.y + Angles.trnsy(ang + this.angVel1, lenFinal);
        
        const trx3 = b.x + Angles.trnsx(ang - this.angVel2, lenFinal);
        const try3 = b.y + Angles.trnsy(ang - this.angVel2, lenFinal);
        const trx4 = b.x + Angles.trnsx(ang + this.angVel2, lenFinal);
        const try4 = b.y + Angles.trnsy(ang + this.angVel2, lenFinal);
        //Damage Laser Seg ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		if (target != null) {
			if(Angles.angleDist(b.angleTo(target), b.rot()) < 60){
				var mathRog = 180 / 3.142
				
				//Angle to
				const angleB1 = Angles.angle(trx1, try1, target.x, target.y);
				const angleB2 = Angles.angle(trx2, try2, target.x, target.y);
				const angleB3 = Angles.angle(trx3, try3, target.x, target.y);
				const angleB4 = Angles.angle(trx4, try4, target.x, target.y);
				
				if(b.timer.get(1, 6)){
					Effects.shake(1, 1, b.x, b.y);
					if(Mathf.chance(Time.delta() * 0.6)){
						Effects.effect(plaShoot,Color.valueOf("ffffff00"), trx1, try1, angleB1);
						Effects.effect(plaShoot,Color.valueOf("ffffff00"), trx2, try2, angleB2);
						Effects.effect(plaShoot,Color.valueOf("ffffff00"), trx3, try3, angleB3);
						Effects.effect(plaShoot,Color.valueOf("ffffff00"), trx4, try4, angleB4);
					}
					Damage.collideLine(b, b.getTeam(), this.hitEffect, trx1, try1, angleB1, lengthFinal);
					Damage.collideLine(b, b.getTeam(), this.hitEffect, trx2, try2, angleB2, lengthFinal);
					Damage.collideLine(b, b.getTeam(), this.hitEffect, trx3, try3, angleB3, lengthFinal);
					Damage.collideLine(b, b.getTeam(), this.hitEffect, trx4, try4, angleB4, lengthFinal);
				}
			}
		}
	},
	lineLaser(b, baseLen, laserColors, laserStrokes, laserTscales, laserLenscales, ang, x, y){
		const strl = 4.5;
		for(var s = 0; s < laserColors.length; s++){
			Draw.color(Color().set(laserColors[s]).mul(1 + Mathf.absin(Time.time(), 1, 0.1)));
			for(var i = 0; i < laserTscales.length; i++){
				Lines.stroke((strl + Mathf.absin(Time.time(), 0.8, 1)) * b.fout() * laserStrokes[s] * laserTscales[i]);
				Lines.lineAngle(x, y, ang, baseLen * laserLenscales[i]);
			}
		}
		const trnsLen = new Vec2();
		trnsLen.trns(ang, baseLen * laserLenscales[laserLenscales.length - 1]);
		Vars.renderer.lights.line(x, y, x + trnsLen.x, y + trnsLen.y);
		Draw.reset();
	},
	//Draw Lasers Lasers' Begin ▼ [Draw] Tons Vector Uses --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    draw(b){
		const baseLen = lengthFinal /* * b.fout();*/
    	const ang = b.rot();
        const strl = 3;
        
        //Vectors Seg. ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        const trx1 = b.x + Angles.trnsx(ang - this.angVel1, lenFinal);
        const try1 = b.y + Angles.trnsy(ang - this.angVel1, lenFinal);
        const trx2 = b.x + Angles.trnsx(ang + this.angVel1, lenFinal);
        const try2 = b.y + Angles.trnsy(ang + this.angVel1, lenFinal);
        
        const trx3 = b.x + Angles.trnsx(ang - this.angVel2, lenFinal);
        const try3 = b.y + Angles.trnsy(ang - this.angVel2, lenFinal);
        const trx4 = b.x + Angles.trnsx(ang + this.angVel2, lenFinal);
        const try4 = b.y + Angles.trnsy(ang + this.angVel2, lenFinal);
        //Draw Lasers ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,lengthFinal - Vars.tilesize);
		if (target != null) {
			if(Angles.angleDist(b.angleTo(target), b.rot()) < 60){
				//Method: Angles.angle(x, y, x2, y2);
				const angleB1 = Angles.angle(trx1, try1, target.x, target.y);
				const angleB2 = Angles.angle(trx2, try2, target.x, target.y);
				const angleB3 = Angles.angle(trx3, try3, target.x, target.y);
				const angleB4 = Angles.angle(trx4, try4, target.x, target.y);
			
				this.lineLaser(b, baseLen, colorFinal, strokesFinal, tscalesFinal, lenscalesFinal, angleB1, trx1, try1);
				this.lineLaser(b, baseLen, colorFinal, strokesFinal, tscalesFinal, lenscalesFinal, angleB2, trx2, try2);
				this.lineLaser(b, baseLen, colorFinal, strokesFinal, tscalesFinal, lenscalesFinal, angleB3, trx3, try3);
				this.lineLaser(b, baseLen, colorFinal, strokesFinal, tscalesFinal, lenscalesFinal, angleB4, trx4, try4);
			}
		}
        Draw.reset();
        //Draw Lasers' Begin ▼--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		const sin = Mathf.absin(Time.time(), 0.8, 1.3);
		Draw.color(effectColor);
		const triA = (72 + sin) * b.fout();
		Drawf.tri(trx1, try1, 3.125, triA, 180);
		Drawf.tri(trx1, try1, 3.125, triA, 0);
		Drawf.tri(trx2, try2, 3.125, triA, 180);
		Drawf.tri(trx2, try2, 3.125, triA, 0);
		Drawf.tri(trx3, try3, 3.125, triA, 180);
		Drawf.tri(trx3, try3, 3.125, triA, 0);
		Drawf.tri(trx4, try4, 3.125, triA, 180);
		Drawf.tri(trx4, try4, 3.125, triA, 0);
		const triL = (32 + sin) * b.fout();
		const tM = Time.time() * 1.5
	    Drawf.tri(trx1, try1, 3.125, triL, 180 - tM);
		Drawf.tri(trx1, try1, 3.125, triL, 0 - tM);
		Drawf.tri(trx2, try2, 3.125, triL, 180 - tM);
		Drawf.tri(trx2, try2, 3.125, triL, 0 - tM);
		Drawf.tri(trx3, try3, 3.125, triL, 180 - tM);
		Drawf.tri(trx3, try3, 3.125, triL, 0 - tM);
		Drawf.tri(trx4, try4, 3.125, triL, 180 - tM);
		Drawf.tri(trx4, try4, 3.125, triL, 0 - tM);
		
		Drawf.tri(trx1, try1, 3.125, triL, 90 + tM);
		Drawf.tri(trx1, try1, 3.125, triL, 270 + tM);
		Drawf.tri(trx2, try2, 3.125, triL, 90 + tM);
		Drawf.tri(trx2, try2, 3.125, triL, 270 + tM);
		Drawf.tri(trx3, try3, 3.125, triL, 90 + tM);
		Drawf.tri(trx3, try3, 3.125, triL, 270 + tM);
		Drawf.tri(trx4, try4, 3.125, triL, 90 + tM);
		Drawf.tri(trx4, try4, 3.125, triL, 270 + tM);
		
		Draw.color(effectColor);
		Fill.circle(trx1, try1, b.fout() * strl * 2);
		Fill.circle(trx2, try2, b.fout() * strl * 2);
		Fill.circle(trx3, try3, b.fout() * strl * 2);
		Fill.circle(trx4, try4, b.fout() * strl * 2);
    	Draw.color(effectColor2);
		Fill.circle(trx1, try1, b.fout() * strl * 1.4);
		Fill.circle(trx2, try2, b.fout() * strl * 1.4);
		Fill.circle(trx3, try3, b.fout() * strl * 1.4);
		Fill.circle(trx4, try4, b.fout() * strl * 1.4);
    }
})
//Basic Seg. ▼---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
FinalLaser.damage = 500;
FinalLaser.speed = 0.0001;
FinalLaser.hitEffect = newEffect(20,e => {
	Draw.color(effectColor, effectColor2,e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 2, 1 + 40 * e.fin(), e.rotation, 25,d);
});
FinalLaser.despawnEffect = Fx.none;
FinalLaser.drawSize = lengthFinal * 2.5;
FinalLaser.lifetime = 60;
FinalLaser.pierce = true;
FinalLaser.expanded = true;

//------------------------------------------------------------------------------------------------------------
//Bullets JavaScript ▲

//Turret JavaScript ▼
//------------------------------------------------------------------------------------------------------------

const FinalTurret = extendContent(PowerTurret,"end-of-era",{
	shieldCharge: 1500,
	setBars(){
		this.super$setBars();
		this.bars.add("ShieldCharge", func(entity => {
			var bar = new Bar(prov( () => "ShieldCharge"), prov( () => Color.valueOf("#CD95FF")), floatp( () => entity.shieldBulletCharge / this.shieldCharge ));
			return bar;
		}));
	},
	handleBulletHit(entity,bullet){
		this.super$handleBulletHit(entity,bullet);
		entity.shieldBulletCharge += bullet.damage() * 0.025 * entity.power.status;
	},
	shoot(tile,type){
		this.super$shoot(tile,type);
		const entity = tile.ent();
	},
	turnToTarget(tile, targetRot){
		const entity = tile.ent();
		entity.rotation = Angles.moveToward(entity.rotation, targetRot, (entity.level * 0.35 + 1.25) * entity.delta() * entity.power.status * (entity.bulletLife > 0 ? this.firingMoveFract : 1));
	},
	update(tile){
		const entity = tile.ent();
		
		this.super$update(tile);
		if(entity.shootMod == 7 && entity.bulletLife > 0 && entity.bullet != null){
			this.tr.trns(entity.rotation, this.size * Vars.tilesize / 2, Mathf.range(5));
			entity.bullet.rot(entity.rotation);
			entity.bullet.set(tile.drawx() + Angles.trnsx(entity.rotation, this.size * Vars.tilesize / 2), tile.drawy() + Angles.trnsy(entity.rotation, this.size * Vars.tilesize / 2));
			entity.bullet.time(0);
			entity.heat = 1;
			entity.recoil = this.recoil;
			entity.bulletLife -= Time.delta();
			if(entity.bulletLife <= 0){
				entity.bullet = null;
			}
		}
		
		if(entity.laserBulletLife > 0 && entity.laserBullet != null && entity.attackMethod == 2){
			this.tr.trns(entity.rotation, this.size * Vars.tilesize / 2, Mathf.range(5));
			entity.laserBullet.rot(entity.rotation);
			entity.laserBullet.set(tile.drawx() + Angles.trnsx(entity.rotation, this.size * Vars.tilesize / 2), tile.drawy() + Angles.trnsy(entity.rotation, this.size * Vars.tilesize / 2));
			entity.laserBullet.time(0);
			entity.heat = 1;
			entity.recoil = this.recoil;
			entity.laserBulletLife -= Time.delta();
			if(entity.laserBulletLife <= 0){
				entity.laserBullet = null;
			}
		}
		
		if(entity.shieldBulletCharge >= this.shieldCharge){
			entity.shieldBulletCharge = 0;
			entity.shieldBullet = Bullet.create(finalTirretShield, tile.entity, tile.getTeam(), tile.drawx(), tile.drawy(), 0);
			entity.shieldBulletLife = 300;
		}
		
		if(entity.shieldBulletLife > 0 && entity.shieldBullet != null){
			entity.shieldBullet.set(tile.drawx(), tile.drawy());
			entity.shieldBullet.time(0);
			entity.shieldBulletLife -= Time.delta();
			if(entity.shieldBulletLife <= 0){
				entity.shieldBullet = null;
			}
		}
	},
	
	shoot(tile, type){
		const entity = tile.ent();
		const selectBullet = this.selectBullet(tile, entity.attackMethod);
		const shootSpac = 10 - 0.35 * entity.level - this.selectNum(tile, entity.attackMethod);
		if(entity.shootMod >= 7 || entity.attackMethod == 2)this.super$shoot(tile, type);
		if(entity.attackMethod != 8 && entity.attackMethod != 2){
			this.shootSelectMod(tile, selectBullet, 12 + 2 * entity.level + entity.shootMod * 2 + this.selectNum(tile, entity.attackMethod) * 2, shootSpac < 2 ? 2 : shootSpac);
		}else if(entity.attackMethod != 2){
			this.shootSelectMod(tile, selectBullet, 3, 20);
		}
	},
	updateShooting(tile){
		const entity = tile.ent();
		if(entity.bulletLife > 0 && entity.bullet != null){
			return;
		}
		if(entity.reload >= (entity.shootMod == 0 ? this.reload * 1.5 : this.reload) && (entity.cons.valid() || tile.isEnemyCheat())){
			type = this.peekAmmo(tile);
			this.shoot(tile, type);
			entity.items.remove(darkenergy,20);
			entity.reload = 0;
		}else{
			const liquid = entity.liquids.current();
			var used = this.baseReloadSpeed(tile) * (tile.isEnemyCheat() ? 0.01 : Math.min(entity.liquids.get(liquid), 0.01 * Time.delta())) * liquid.heatCapacity * this.coolantMultiplier;
			entity.reload += (entity.level * 0.075 + 1) * used;
			entity.liquids.remove(liquid, used);
			if(Mathf.chance(0.06 * used)){
				Effects.effect(this.coolEffect, tile.drawx() + Mathf.range(this.size * Vars.tilesize / 2), tile.drawy() + Mathf.range(this.size * Vars.tilesize / 2));
			}
		}
	},
	shootSelectMod(tile, selectBullet, shots, spacing){
		const entity = tile.ent();

		for(var i = 0; i < shots; i++){
			Time.run(spacing * i , run(() => {
				
				entity.heat = 1;
				entity.shootRaid += 1;
				
				const ang = entity.rotation;
				const lenX = 18;
		
				const randSx1 = Angles.trnsx(ang + 90, lenX);
				const randSy1 = Angles.trnsy(ang + 90, lenX);
				const randSx2 = Angles.trnsx(ang - 90, lenX);
				const randSy2 = Angles.trnsy(ang - 90, lenX);
				
				const trnx = Angles.trnsx(ang, 15);
				const trny = Angles.trnsy(ang, 15);
				if(entity.recoil < this.recoil)entity.recoil += 0.3 * this.recoil;
				
				Sounds.explosionbig.at(tile,Mathf.random(0.9, 1.1));
					
				this.tr.trns(entity.rotation, this.size * Vars.tilesize / 2, Mathf.range(7));
				const shootX = this.tr.x + tile.drawx();
				const shootY = this.tr.y + tile.drawy();
				
				if(entity.shootRaid % 3 == 0)Effects.effect(missileShootSmoke,Color.valueOf("ffffff00"), shootX,						shootY, 					ang);
				if(entity.shootRaid % 3 == 1)Effects.effect(missileShootSmoke,Color.valueOf("ffffff00"), shootX + randSx1, 	shootY + randSy1, ang);
				if(entity.shootRaid % 3 == 2)Effects.effect(missileShootSmoke,Color.valueOf("ffffff00"), shootX + randSx2, 	shootY + randSy2, ang);
				
				if(entity.shootRaid % 3 == 0)Effects.effect(missileShoot,Color.valueOf("ffffff00"), shootX,									shootY, 					ang);
				if(entity.shootRaid % 3 == 1)Effects.effect(missileShoot,Color.valueOf("ffffff00"), shootX + randSx1, 				shootY + randSy1, ang);
				if(entity.shootRaid % 3 == 2)Effects.effect(missileShoot,Color.valueOf("ffffff00"), shootX + randSx2, 				shootY + randSy2, ang);
				
				if(entity.shootRaid % 3 == 0)Calls.createBullet(selectBullet, tile.getTeam(), shootX + trnx, 					shootY + trny, 					ang, 1, 1);
				if(entity.shootRaid % 3 == 1)Calls.createBullet(selectBullet, tile.getTeam(), shootX + trnx + randSx1, shootY + trny + randSy1, ang, 1, 1);
				if(entity.shootRaid % 3 == 2)Calls.createBullet(selectBullet, tile.getTeam(), shootX + trnx + randSx2, shootY + trny + randSy2, ang, 1, 1);
			}));
			if(i == 45)entity.shootRaid = 0;
		}
	},
	bullet(tile, type, angle){
		const entity = tile.ent();
		if(entity.shootMod == 7){
			entity.bullet = Bullet.create(type, tile.entity, tile.getTeam(), tile.drawx() + this.tr.x, tile.drawy() + this.tr.y, angle);
			entity.bulletLife = this.shootDuration;
		};
		if(entity.attackMethod == 2){
			entity.laserBullet = Bullet.create(continueLaser, tile.entity, tile.getTeam(), tile.drawx() + this.tr.x, tile.drawy() + this.tr.y, angle);
			entity.laserBulletLife = this.shootDuration;
		};
	},
	shouldActiveSound(tile){
		const entity = tile.ent();
		return entity.bulletLife > 0 && entity.bullet != null;
	},
	drawConfigure(tile){
		const entity = tile.ent();
		const trnsB = new Vec2();
		trnsB.trns(entity.rotation, this.size * Vars.tilesize / 2 - this.recoil);
		const sin = Mathf.absin(Time.time(), 6, 1);
		//Drawf.arrow(tile.drawx(), tile.drawy(), tile.drawx() + trnsB.x, tile.drawy() + trnsB.y, this.size * Vars.tilesize + sin, 4 + sin, effectColor);
		if(entity.shootMod == 7){
			Drawf.circles(tile.drawx() + trnsB.x, tile.drawy() + trnsB.y, lenFinal, effectColor);
		};
		for(var i = 1; i < 4; i++){
			Drawf.circles(tile.drawx(), tile.drawy(), this.range / i, effectColor);
		};
		Draw.color(Pal.gray);
		Lines.stroke(6);
		Lines.circle(tile.drawx(), tile.drawy(), this.range);
		Draw.color(effectColor);
		Lines.stroke(4);
		Lines.circle(tile.drawx(), tile.drawy(), this.range);
		Draw.reset();
		for(var i = 1; i < 4; i++){
			Draw.color(Pal.gray);
			Draw.rect(Core.atlas.find("新视界-upgrade"), tile.drawx(), tile.drawy() + this.range / i);
			Draw.color(effectColor);
			Draw.rect(Core.atlas.find("新视界-upgrade-front"), tile.drawx(), tile.drawy() + this.range / i);
		};
		Draw.color(Pal.gray);
		for(var i = 1; i < 14; i++){
			Draw.rect(Core.atlas.find("新视界-Level-2"), tile.drawx() + this.size * 4 + 4, tile.drawy() + this.size * 4 - 2 * i);
		};
		Draw.color(effectColor);
		for(var i = 1; i < entity.level + 2; i++){
			Draw.rect(Core.atlas.find("新视界-Level"), tile.drawx() + this.size * 4 + 4, tile.drawy() + this.size * 4 - 4 * i);
		};
		if(entity.linked){
			for(var i = 0; i < 4; i++){
				var length = Vars.tilesize * this.size / 2 + 3 + sin;
				Draw.color(Pal.gray);
				Draw.rect("新视界-linked-arrow-back", tile.drawx() + Angles.trnsx(i * 90, length), tile.drawy() + Angles.trnsy(i * 90, length), i == 0 ? 180 : i == 2 ? 0 : -i * 90);
				Draw.color(effectColor);
				Draw.rect("新视界-linked-arrow", tile.drawx() + Angles.trnsx(i * 90, length), tile.drawy() + Angles.trnsy(i * 90, length), i == 0 ? 180 : i == 2 ? 0 : -i * 90);
			}
		}
        Draw.color();
	},
	drawSelect(tile){},
	
	selectBullet(tile, mod){
		const entity = tile.ent();
		switch(mod){
			case 0 : return energyMissile;
			case 5 : return energyTro;
			case 8 : return energyPloy;
		}
	},
	
	selectNum(tile, mod){
		const entity = tile.ent();
		switch(mod){
			case 0 : return 0;
			case 2 : return 0;
			case 5 : return 16;
			case 8 : return -13;
		}
	}
})
FinalTurret.shootCone = 5;
FinalTurret.powerUse = 150;
FinalTurret.health = 25000;
FinalTurret.configurable = true;
FinalTurret.recoil = 4;
FinalTurret.size = 8;
FinalTurret.firingMoveFract = 0.25;
FinalTurret.shootCone = 60;
FinalTurret.expanded = true;
FinalTurret.canOverdrive = true;
FinalTurret.hasItem = true;
FinalTurret.range = lengthFinal - 40;
FinalTurret.heatColor = Color.valueOf("#DCC7FF");
FinalTurret.reload = 17;
FinalTurret.shootDuration = 300;
FinalTurret.activeSound = Sounds.beam;
FinalTurret.shootType = FinalLaser;
FinalTurret.shootEffect = Fx.none;
FinalTurret.localizedName = Core.bundle.get("Block."+ "end-of-era" +".name");
FinalTurret.description = Core.bundle.get("Block."+ "end-of-era" +".description");
FinalTurret.smokeEffect = newEffect(25,e => {
	Draw.color(effectColor, effectColor2,e.fin());
	Drawf.tri(e.x, e.y, 4, 28 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 4, 28 * e.fout(), e.rotation + 270);
});
 FinalTurret.entityType=prov(()=>extend(Turret.TurretEntity,{
    _bullet: null,
    getbullet(){return this._bullet},
    setbullet(value){this._bullet = value},
    _bulletLife:0,
    getbulletLife(){return this._bulletLife},
    setbulletLife(value){this._bulletLife = value},
    
    _shieldBullet: null,
    getshieldBullet(){return this._shieldBullet},
    setshieldBullet(value){this._shieldBullet = value},
    _shieldBulletLife:0,
    getshieldBulletLife(){return this._shieldBulletLife},
    setshieldBulletLife(value){this._shieldBulletLife = value},
    _shieldBulletCharge:0,
    getshieldBulletCharge(){return this._shieldBulletCharge},
    setshieldBulletCharge(value){this._shieldBulletCharge = value},
    //if this.attackMethod == 2;useLaser.
    _laserBullet: null,
    getlaserBullet(){return this._laserBullet},
    setlaserBullet(value){this._laserBullet = value},
    _laserBulletLife: 0,
    getlaserBulletLife(){return this._laserBulletLife},
    setlaserBulletLife(value){this._laserBulletLife = value},
    
    getshootRaid(){return this._shootRaid},
	setshootRaid(value){this._shootRaid = value},
	_shootRaid: 0,
	
	getlinked(){return this._linked},
	setlinked(value){this._linked = value},
	_linked: false,
	
	getlevel(){return this._level},
	setlevel(value){this._level = value},
	_level: 0,
	getshootMod(){return this._shootMod},
	setshootMod(value){this._shootMod = value},
	_shootMod: 0,
	getattackMethod(){return this._attackMethod},
	setattackMethod(value){this._attackMethod = value},
	_attackMethod: 0,
	
	write(stream){
		this.super$write(stream);
		stream.writeFloat(this._level);
		stream.writeFloat(this._shootMod);
		stream.writeFloat(this._attackMethod);
		
		stream.writeFloat(this._shieldBulletCharge);
		stream.writeFloat(this._laserBulletLife);
	},
	read(stream,revision){
		this.super$read(stream,revision);
		this._level = stream.readFloat();
		this._shootMod = stream.readFloat();
		this._attackMethod = stream.readFloat();
		
		this._shieldBulletCharge = stream.readFloat();
		this._laserBulletLife = stream.readFloat();
	}
}));

