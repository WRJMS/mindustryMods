const followBullet = extend(BasicBulletType,{
	draw(b){
		Draw.color(Color.valueOf("ffd280"));
		Fill.circle(b.x, b.y, 4);
		Draw.color(Color.valueOf("ffffff"));
		Fill.circle(b.x, b.y, 2.25);
	},
	update(b){
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,500)
		if (target != null) {
			b.velocity().setAngle(Mathf.slerpDelta(b.velocity().angle(), b.angleTo(target), 0.425));
		}
		if(b.timer.get(1,5)){
			Effects.effect(newEffect(25,e => {
				Draw.color(Color.valueOf("#ffd280"));
				Fill.circle(e.x, e.y, e.fout() * 4);
				Draw.color(Color.valueOf("#ffffff"));
				Fill.circle(e.x, e.y, e.fout() * 2.25);
			}),
			Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
		}
	}
})
followBullet.speed = 3;
followBullet.pierce = true;
followBullet.damage = 3.7;
followBullet.knockback =0;
followBullet.bulletWidth = 8;
followBullet.bulletHeight = 8;
followBullet.smokeEffect = newEffect(25,e => {
	const d = new Floatc2({get(x,y){
		Draw.color(Color.valueOf("ffd280"));
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
	}})
	Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
});
followBullet.lifetime = 120;
followBullet.despawnEffect = Fx.flakExplosion;



const 附着炮= extendContent(BurstTurret,"附着炮",{});
附着炮.ammo(Items.silicon,followBullet);
附着炮.ammoUseEffect = Fx.shootBigSmoke
附着炮.heatColor = Color.valueOf("#ffd280");






