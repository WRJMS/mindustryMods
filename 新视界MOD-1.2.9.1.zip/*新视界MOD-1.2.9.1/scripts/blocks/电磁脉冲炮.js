

const 震慑 = extendContent(StatusEffect,"震慑",{});
震慑.damageMultiplier = 0.25;
震慑.damage = 0.01;
震慑.armorMultiplier = 0.75;
震慑.speedMultiplier = 0.275;
震慑.color = Color.valueOf("#FF9B48");
震慑.effect = newEffect(20,e => {
	Draw.color(Color.valueOf("#FF9B48"),Color.valueOf("#FFF7CC"),e.fin());
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 0.425);
    }}) 
    Angles.randLenVectors(e.id, 5, 64 * e.fin(), e.rotation, 360,d);
    Draw.color(Color.valueOf("#404040"),Color.valueOf("#787878"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 3);
    }}) 
    Angles.randLenVectors(e.id, 3, 1 + 40 * e.fin(), e.rotation, 360,c);
             });
震慑.color = Color.valueOf("#B4E6FF");

const emp2 = extend(MissileBulletType,{
        update(b){
        if(Mathf.chance(Time.delta() * 0.1)){
        	Lightning.create(b.getTeam(),Color.valueOf("B4E6FF"), 5, b.x, b.y, b.rot(), 15);         
        }
	}
})
emp2.damage = 0;
emp2.speed = 3;
emp2.collidesTiles = false,
emp2.frontColor = Color.valueOf("cde6ff"),
emp2.backColor = Color.valueOf("#B4E6FF"),
emp2.trailColor = Color.valueOf("#B4E6FF"),
emp2.pierce = true;
//emp2.fragBullets = 2;
//emp2.fragBullet = Bullets.lightning;
emp2.bulletSprite = "新视界-波束子弹";
emp2.bulletWidth = 10;
emp2.despawnEffect = Fx.hitLancer;
emp2.hitEffect = Fx.hitLancer;
emp2.bulletWidth = 12;
const linkLen = 160;
//const emp1 = extend(ArtilleryBulletType,{})
const emp1 = extend(MissileBulletType,{
	despawned(b){
		for(var i = 0; i < 4; i++){
			Lightning.create(b.getTeam(),Color.valueOf("B4E6FF"), 15, b.x , b.y , Mathf.random(360), Mathf.random(15, 25));         
		}  
		Effects.effect(this.hitEffect, b);
		Units.nearbyEnemies(b.getTeam(), b.x - linkLen / 2, b.y - linkLen / 2, linkLen, linkLen, cons(e => {
			e.applyEffect(震慑, 150);
		}));
	},
	hit(b){
		this.despawned(b);
	}
})
emp1.damage = 0;
emp1.hitSound = Sounds.spark;
emp1.speed = 6.5;
//emp1.splashDamageRadius = 120;
//emp1.splashDamage = 10;
//.emp1.status = StatusEffects.tarred;
emp1.statusDuration = 240;
emp1.bulletShrink = 0;
emp1.hitShake = 3;
emp1.hitEffect = newEffect(45, e => {
    Draw.color(Color.valueOf("#B4E6FF"),Color.valueOf("#cde6ff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * e.fout() * 18);
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 140);
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 1);
    }}) 
    Angles.randLenVectors(e.id, 30, 160 * e.fin(), e.rotation, 360,d);
});
emp1.bulletWidth = 18;
emp1.bulletSprite = "新视界-波束子弹";
emp1.bulletHeight = 20.25;
emp1.frontColor = Color.valueOf("cde6ff"),
emp1.backColor = Color.valueOf("#B4E6FF"),
emp1.trailColor = Color.valueOf("#B4E6FF"),
emp1.pierce = false;
emp1.shootEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("#B4E6FF"));
    Fill.circle(e.x, e.y, e.fout() * 11.25);
    Draw.color(Color.valueOf("#B4E6FF"),Color.valueOf("#cde6ff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 6.725);
});
emp1.smokeEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("#B4E6FF"),Color.valueOf("#cde6ff"),e.fin());
    
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 19);
});



const EMP远程轰击炮 = extendContent(ArtilleryTurret,"EMP远程轰击炮",{});
EMP远程轰击炮.ammo(Items.phasefabric,emp1);
EMP远程轰击炮.ammoUseEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("#cde6ff"),Color.valueOf("#B4E6FF"),e.fin());
	Lines.stroke(e.fin() * 2.25);
    Lines.circle(e.x, e.y, e.fout() * 56);
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 0.425);
    }}) 
    Angles.randLenVectors(e.id, 20, 60 * e.fin(), e.rotation, 360,d);
             });
             
             
             
             
//units
/*const 红色阳离子 = extend(MissileBulletType,{});
红色阳离子.splashDamage = 35;
红色阳离子.bulletSprite = "新视界-波束子弹";
红色阳离子.damage = 75;
红色阳离子.splashDamageRadius = 60;
红色阳离子.bulletWidth = 6.5
红色阳离子.bulletHeight = 20
红色阳离子.speed = 6;
红色阳离子.homingPower = 0;
红色阳离子.shootEffect = newEffect(12,e => {
	Draw.color(Color.valueOf("#55A1FF"),Color.valueOf("#A0CCFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7.5 + 0.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+38 * e.fin(),e.rotation, 30,d);
             });
红色阳离子.backColor = Color.valueOf("#55A1FF");
红色阳离子.smokeEffect = newEffect(18,e => {
	Draw.color(Color.valueOf("#55A1FF"),Color.valueOf("#A0CCFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7.5 + 0.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+38 * e.fin(),e.rotation, 30,d);
             });
红色阳离子.frontColor = Color.valueOf("#A0CCFF");
红色阳离子.trailColor = Color.valueOf("#6EB2FF");
红色阳离子.hitEffect = newEffect(16,e => {
	Draw.color(Color.valueOf("#55A1FF"),Color.valueOf("#A0CCFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 4);
	Lines.stroke(e.fout() * 1.25);
    Lines.circle(e.x, e.y, e.fin() * 24);
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 57.5);
             }})
             Angles.randLenVectors(e.id, 7, 1 + 23 * e.fin(),e.rotation, 360,d);
             });
红色阳离子.despawnEffect = Fx.hitMeltdown;
红色阳离子.hitSize = 4;
红色阳离子.lifetime = 60;
红色阳离子.pierce = true;
const 红色阳离子炮 = extendContent(Weapon,"红色阳离子炮",{})
红色阳离子炮.bullet = 红色阳离子;
红色阳离子炮.name = 堙灭炮;
红色阳离子炮.length = 18.75;
红色阳离子炮.shots = 4;
红色阳离子炮.velocityRnd = 0.15;
红色阳离子炮.shotDelay = 4.5;
红色阳离子炮.spacing = 0.05;
红色阳离子炮.recoil = 3.75;
红色阳离子炮.width = 18.75;
红色阳离子炮.reload = 70;
红色阳离子炮.inaccuracy = 1.75;
红色阳离子炮.alternate = true;
红色阳离子炮.range = 320;
红色阳离子炮.ejectEffect = newEffect(16,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#55A1FF"),e.fin());
	Lines.stroke(e.fin() * 1.25);
    Lines.circle(e.x, e.y, e.fout() * 22);
             });
红色阳离子炮.shootSound = Sounds.artillery;
const 堙灭者 = extendContent(GroundUnit,"掠夺者",{})
堙灭者.weapon = 红色阳离子炮;
堙灭者.rotatespeed = 0.03;
堙灭者.baseRotateSpeed = 0.02;
堙灭者.health = 18000,
堙灭者.mass = 35,
堙灭者.speed = 0.18,
堙灭者.range = 280,
堙灭者.drag = 0.15,
堙灭者.rotateWeapon = false,
堙灭者.flying = false,
堙灭者.weaponOffsetY = 0*/