const colors点 = [Color.valueOf("f0ffba55"), Color.valueOf("f0ffba"), Color.valueOf("F0FFC5")];
const tscales点 = [2, 1.5, 1, 0.825];
const lenscales点 = [1, 1.04, 1.06, 1.075];
const length点 = 300;
const 点防御激光 = extend(BasicBulletType,{
    range(){
        return length点;
    },
    update(b){
        const target = Units.closestTarget(b.getTeam(), b.x,b.y,300)
        if (target != null) {
            if(b.timer.get(1, 1)){
            	
            Effects.effect(newEffect(25,e => {
	Draw.color(Color.valueOf("#f0ffba"));
    Fill.circle(e.x, e.y, e.fout() * 8);
    Draw.color(Color.valueOf("#F0FFC5"));
    Fill.circle(e.x, e.y, e.fout() * 4.5);
	}),Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
                Damage.collideLine(b, b.getTeam(), Fx.formsmoke, b.x, b.y, b.rot(), Mathf.dst(b.x,b.y,target.x,target.y), true);
               /* for (var i = 0; i < Mathf.random(3); i++) {
                Lightning.create(b.getTeam(),Color.valueOf("B3DBFF"), 30, target.x,target.y,Mathf.random(360), Mathf.random(30)); 
                }*/
            }

        }
    },
    draw(b){
        //const f = Mathf.curve(b.fout(), 0, 0.25);
        const target = Units.closestTarget(b.getTeam(), b.x,b.y,300)
        var baseLen = 0 * b.fout();
        if (target != null) {
            baseLen = (Mathf.dst(b.x,b.y,target.x,target.y)) * b.fout();
        }
        Lines.lineAngle(b.x, b.y, b.rot(), baseLen);
        for(var s = 0; s < 3; s++){
            Draw.color(colors点[s]);
            for(var i = 0; i < tscales点.length; i++){
                Lines.stroke(3 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscales点[i]);
                Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales点[i]);
            }
        }
        Draw.reset();
    }
})
点防御激光.damage = 50;
点防御激光.speed = 0.0001;
点防御激光.hitEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("#f0ffba"));
    Fill.circle(e.x, e.y, e.fout() * 7);
    Draw.color(Color.valueOf("#F0FFC5"));
    Fill.circle(e.x, e.y, e.fout() * 4);
	})
/*newEffect(55, e => {
    Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#e4ebff"),e.fin());
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 5);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 30 * e.fout(), e.rotation, 360,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 6);
    }}) 
    Angles.randLenVectors(e.id, 5, 1 + 40 * e.fin(), e.rotation, 360,c);
});*/
点防御激光.despawnEffect = Fx.none;
点防御激光.hitSize = 250;
点防御激光.drawSize = 250;
点防御激光.bulletWidth = 60;
点防御激光.lifetime = 45;
点防御激光.pierce = true;
点防御激光.shootEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("#f0ffba"));
    Fill.circle(e.x, e.y, e.fout() * 3.25);
    Draw.color(Color.valueOf("#F0FFC5"),Color.valueOf("#ffffff"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 1.725);
});
点防御激光.smokeEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("#f0ffba"),Color.valueOf("#F0FFC5"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 7, 1 + 40 * e.fin(), e.rotation, 30,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 2);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 360,c);
});



const 点防御激光器 = extendContent(LaserTurret,"点防御激光器",{
turnToTarget(tile,targetRot){
        const entity = tile.ent();
 
        entity.rotation = Mathf.slerpDelta(entity.rotation, entity.angleTo(entity.target), 0.725);
    }
})
点防御激光器.shootCone = 8;
点防御激光器.recoil = 4;
点防御激光器.size = 4;
点防御激光器.shootShake = 3
点防御激光器.range = 300
点防御激光器.firingMoveFract = 4
点防御激光器.shootDuration = 60
点防御激光器.activeSound = Sounds.beam;
点防御激光器.activeSoundVolume = 3
点防御激光器.shootType = 点防御激光