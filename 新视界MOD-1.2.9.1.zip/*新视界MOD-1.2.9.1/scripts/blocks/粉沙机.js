const 粉沙机 = extendContent(GenericCrafter,"粉沙机",{
	
	
	update:function(tile){
		const entity = tile.ent();
        copper = Vars.content.getByName(ContentType.item,"copper")
        lead = Vars.content.getByName(ContentType.item,"lead")
        titanium = Vars.content.getByName(ContentType.item,"titanium")
        sand = Vars.content.getByName(ContentType.item,"sand")
		if(tile.entity.items.get(sand) >= 10)entity.totalProgress = 0;
		if(entity.power.status > 0.3){
	        if(tile.entity.items.get(titanium) >= 1 || tile.entity.items.get(copper) >= 1 || tile.entity.items.get(lead) >= 1 && tile.entity.items.get(sand) < 10){
				entity.totalProgress += entity.delta() * entity.power.status / entity.timeScale;
				if(entity.totalProgress > this.craftTime){
					if(tile.entity.items.get(lead) >= 1){
						tile.entity.items.add(sand,1)
						tile.entity.items.remove(lead,1)
					}
		            if(tile.entity.items.get(titanium) >= 1){
						tile.entity.items.add(sand,2)
						tile.entity.items.remove(titanium,1)
					}
					if(tile.entity.items.get(copper) >= 1){
						tile.entity.items.add(sand,1)
						tile.entity.items.remove(copper,1)
					}
					entity.totalProgress = 0
					Effects.effect(Fx.smeltsmoke,tile);
				}
			}
	    }
	this.tryDump(tile,sand);
    }
})
粉沙机.craftTime = 15;
