const colors巨 = [Color.valueOf("FFD70025"), Color.valueOf("#FFF98C"), Color.valueOf("#ffffff")];
const tscales巨 = [2, 1.625, 1.2725, 1];
const lenscales巨 = [1, 1.125, 1.215, 1.2625];
const length巨 = 270;
const 巨浪激光 = extend(BasicBulletType,{
	range(){
		return length巨;
	},
	init(b){
		if (b == null) return;
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,300);
		if (target != null) {
			const ang = b.angleTo(target);
			Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, ang, this.range());
		}
	},
	draw(b){
		const f = Mathf.curve(b.fin(), 0, 0.2);
		const baseLen = length巨 * f;
		const target = Units.closestTarget(b.getTeam(), b.x,b.y,300);
		if (target != null) {
			const ang = b.angleTo(target);
			Lines.lineAngle(b.x, b.y, ang, baseLen);
			for(var s = 0; s < 3; s++){
				Draw.color(colors巨[s]);
				for(var i = 0; i < tscales巨.length; i++){
					Lines.stroke(2.25 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscales巨[i]);
					Lines.lineAngle(b.x, b.y, ang, baseLen * lenscales巨[i]);
				}
			}
		}
		Draw.reset();
	}
})
巨浪激光.damage = 225;
巨浪激光.speed = 0.00001;
巨浪激光.hitEffect = newEffect(55, e => {
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.425, 45);
    }}) 
    Angles.randLenVectors(e.id, 2, 1 + 40 * e.fin(), e.rotation, 360,c);
});
巨浪激光.despawnEffect = Fx.none;
巨浪激光.hitSize = 250;
巨浪激光.drawSize = 250;
巨浪激光.bulletWidth = 60;
巨浪激光.lifetime = 25;
巨浪激光.pierce = true;
巨浪激光.ammoMultiplier = 6;
巨浪激光.shootEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("#FFF98C"));
    Drawf.tri(e.x, e.y, 3 * e.fout(), 14 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 3 * e.fout(), 14 * e.fout(), e.rotation + 270);
});
巨浪激光.smokeEffect = newEffect(30, e => {
    Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
    const c = new Floatc2({get(x, y){
        Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 3.25, 45);
    }}) 
    Angles.randLenVectors(e.id, 4, 1 + 30 * e.fin(), e.rotation, 360,c);
});

const 巨浪激光器 = extendContent(DoubleTurret,"巨浪激光器",{})
巨浪激光器.ammo(Items.surgealloy,巨浪激光)



 