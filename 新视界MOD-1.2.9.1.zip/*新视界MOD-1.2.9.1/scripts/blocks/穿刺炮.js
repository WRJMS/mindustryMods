
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
var selectaSpotsRadius = 32;
var autoFindTarget = 0;
var selectTarget = 0;
var radiusMulp = 0.05;
var inaccuracyChange = 0;
var realSpeed = 0;
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
const 火控塔 = extendContent(GenericCrafter, "火控塔", {
	update(tile){
		const entity = tile.ent();
		if(tile.entity.items.total() / this.itemCapacity - 0.3 > 0 && entity.power.status > 0.5){
			realSpeed = 1.35 * tile.entity.items.total() / this.itemCapacity * entity.power.status;
			inaccuracyChange = 1.75 * tile.entity.items.total() / this.itemCapacity * entity.power.status;
			radiusMulp = tile.entity.items.total() / this.itemCapacity * entity.power.status - 0.3;
		}else{
			radiusMulp = 0.05;
			realSpeed = 0;
			inaccuracyChange = 0;
		}
	},
	buildConfiguration(tile,table){
        const entity = tile.ent();
        table.addImageButton(Icon.zoom, Styles.clearTransi, run(() => {
        	if(autoFindTarget == 0 && entity.power.status > 0.5){
        	autoFindTarget = autoFindTarget + 1;
        }else if(autoFindTarget == 1){
        	autoFindTarget = autoFindTarget - 1;
        }
    })).size(50)
    },
    draw(tile){
		const entity = tile.ent();
		var drawheat = entity.power.status;
        const f = 1 - (Time.time() / 100) % 1;
        Draw.rect(this.region,tile.drawx(),tile.drawy())
        if(autoFindTarget == 1){
		drawheat = Mathf.lerpDelta(drawheat, entity.cons.valid() ? 1 : 0, 0.08);
        Draw.color(Color.valueOf("feb380")/*, Color.valueOf("ffd59e"), entity.phaseHeat*/);
        Draw.alpha(drawheat * Mathf.absin(Time.time(), 10, 1) * 0.5);
        Draw.rect(Core.atlas.find(this.name + "-top"), tile.drawx(), tile.drawy());
        Draw.alpha(1);
        Lines.stroke((2 * f + 0.2) * drawheat);
        Lines.square(tile.drawx(), tile.drawy(), (1 - f) * 12);
		}
        Draw.reset();
	},
	onDestroyed(tile){
		autoFindTarget = 0;
		radiusMulp = 0.05;
		realSpeed = 0;
		inaccuracyChange = 0;
	},
	removed(tile){
		autoFindTarget = 0;
		radiusMulp = 0.05;
		realSpeed = 0;
		inaccuracyChange = 0;
	}
});
火控塔.timerUse = 120;
火控塔.itemDuration = 300;
火控塔.sync = true;
火控塔.update = true;
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

const 尾迹腐化 = newEffect(55,e => {
	Draw.color(Color.valueOf("#FFAB90"));
    Fill.circle(e.x, e.y, e.fout() * 4);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 2.125);
});

const 腐化 = extend(ArtilleryBulletType,{
      update(b){
	      if(Mathf.chance(Time.delta() * 0.075)){
	      Lightning.create(b.getTeam(),Color.valueOf("FFAB90"), 25, b.x , b.y , b.rot(), Mathf.random(25, 35));         
	      for(var i = 0; i < 2; i++){
	      Lightning.create(b.getTeam(),Color.valueOf("FFAB90"), 15, b.x , b.y , Mathf.random(360), Mathf.random(15, 25));         
        }
        }
        if(b.timer.get(1,1)){
        	Effects.effect(尾迹腐化,Color.valueOf("dd753800"), b.x, b.y, b.rot());
        }
        },
        velocity(speed,angle){
			velocity.set(0, b.fin() * b.fin() * speed).setAngle(angle);
	    },
        draw(b){
       Draw.color(Color.valueOf("FFAB90"));
       Fill.circle(b.x, b.y, 7);
       Draw.color(Color.valueOf("ffffff"));
       Fill.circle(b.x, b.y, 3.75);
        },
        despawned(b){
        Sounds.explosionbig.at(b);
        Damage.damage(b.getTeam(),b.x, b.y, this.splashDamageRadius * 3, this.splashDamage);
        Effects.effect(this.despawnEffect, b.x, b.y, b.rot());
        for(var i = 0; i < 7 + Mathf.random(7); i++){
        	Lightning.create(b.getTeam(),Color.valueOf("FFAB90"), 250, b.x , b.y , Mathf.random(360), Mathf.random(40,60));  
	        }
        }
   })
腐化.damage = 0;
腐化.lifetime = 45;
腐化.splashDamage = 225;
腐化.hitSound = Sounds.boom;
腐化.splashDamageRadius = 48;
腐化.speed = 3;
腐化.collidesTiles = false ;
腐化.collides = false ;
腐化.collidesAir = false ; 
腐化.keepVelocity = false ;
腐化.despawnEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("FFAB90"),Color.valueOf("#FFAB90"),e.fin());
    Fill.circle(e.x, e.y, e.fout() * 24);
    Lines.stroke(e.fout() * 4.5);
    Lines.circle(e.x, e.y, e.fin() * 52);
    Lines.stroke(e.fout() * 2.75);
    Lines.circle(e.x, e.y, e.fin() * 32);
    const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 45, 65 * e.fin(), e.rotation, 360,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 10);
    }}) 
    Angles.randLenVectors(e.id, 45, 160 * e.fin(),  e.rotation, 360,c);
});
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------



    
const 腐朽 = extendContent(ArtilleryTurret, "腐朽", {
	
	buildConfiguration(tile,table){
        const entity = tile.ent();
        table.addImageButton(Icon.upOpen, Styles.clearTransi, run(() => {
    if(selectaSpotsRadius < 160){
		selectaSpotsRadius = selectaSpotsRadius + 8
		inaccuracyChange = inaccuracyChange + 0.225
	}
    })).size(50)//.disabled(selectaSpotsRadius == 120)
    
   table.addImageButton(Icon.downOpen, Styles.clearTransi, run(() => {
   if(selectaSpotsRadius > 32){
		selectaSpotsRadius = selectaSpotsRadius - 8
		inaccuracyChange = inaccuracyChange - 0.225
	}
    })).size(50)//.disabled(selectaSpotsRadius == 40)
    
    table.addImageButton(Icon.cancel, Styles.clearTransi, run(() => {
	    selectTarget = 0;
		radiusMulp = 0.05;
		realSpeed = 0;
		inaccuracyChange = 0;
    })).size(50)
    
    table.addImageButton(Icon.zoom, Styles.clearTransi, run(() => {
	    selectTarget = 1
		radiusMulp = 0.05;
		realSpeed = 0;
		inaccuracyChange = 0;
    })).size(50)
    },
    playerPlaced(tile) {
        this.selectaSpots[tile.x + "," + tile.y] = tile.pos();
    },
    configured(tile, player, value) {
        this.selectaSpots[tile.x + "," + tile.y] = value;
    },
    drawConfigure(tile){
    	if(selectTarget == 1){
	        Draw.color(Color.valueOf("#FF4E2C25"));
	        Draw.blend(Blending.additive);
	        Fill.circle(tile.drawx(), tile.drawy(), this.range - selectaSpotsRadius);
	        Draw.blend();
	        Draw.color(Color.valueOf("#ffffff"));
	        Lines.stroke((this.range - selectaSpotsRadius) / 30);
	        Lines.circle(tile.drawx(), tile.drawy(),this.range - selectaSpotsRadius);
	        Lines.stroke(8);
			Lines.circle(tile.drawx(), tile.drawy(),this.range);
			Lines.circle(tile.drawx(), tile.drawy(),this.range * radiusMulp);
			Draw.reset();
	        Draw.color(Color.valueOf("#FF4E2C"));
	        Lines.stroke(3);
	        Lines.circle(tile.drawx(), tile.drawy(),this.range * radiusMulp);
	        Lines.stroke(5);
	        Lines.circle(tile.drawx(), tile.drawy(),this.range - selectaSpotsRadius);
	        Draw.color(Color.valueOf("#ffffff75"));
	        Draw.blend(Blending.additive);
	        Lines.stroke(3);
	        Lines.circle(tile.drawx(), tile.drawy(),(this.range - selectaSpotsRadius) / 8 );
	        Lines.circle(tile.drawx(), tile.drawy(),(this.range - selectaSpotsRadius) / 4 );
	        Lines.circle(tile.drawx(), tile.drawy(),(this.range - selectaSpotsRadius) / 2 );
	    	Draw.color(Color.valueOf("#ffffff90"));
	        Lines.stroke(1.75);
	        if(this.selectaSpots[tile.x + "," + tile.y] === undefined) {
	            this.selectaSpots[tile.x + "," + tile.y] = tile.pos();
	        }
	        var spotTile = Vars.world.tile(this.selectaSpots[tile.x + "," + tile.y]);
	        if(autoFindTarget == 0){
		        Lines.circle(spotTile.drawx(), spotTile.drawy(), selectaSpotsRadius);
			    Lines.square(spotTile.drawx(),spotTile.drawy(),  12, 45 + Time.time() * 3);
		        Lines.square(spotTile.drawx(),spotTile.drawy(), 7, 45 - Time.time() * 3);
	        }
        }
        Draw.blend();
        Draw.reset();
    },
    onConfigureTileTapped(tile, other) {
        if(Math.pow(other.x - tile.x, 2) + Math.pow(other.y - tile.y, 2) > Math.pow((this.range - selectaSpotsRadius) / Vars.tilesize, 2)) return true;
        if(this.selectaSpots[tile.x + "," + tile.y] === other.pos()) return true;
        if(selectTarget != 1)return true;
        tile.configure(other.pos());
        return false;
    },
    findTarget(tile) {
        const entity = tile.ent();
        if(entity.totalAmmo > this.ammoPerShot - 1){
	        if(autoFindTarget == 1 && entity.power.status > 0.5){
		        entity.target = Units.closestTarget(tile.getTeam(), tile.drawx(), tile.drawy(), this.range * radiusMulp,boolf((e) => {return !e.isDead() && !e.isFlying()}));
		    }else if(autoFindTarget == 0){
				if(this.selectaSpots[tile.x + "," + tile.y] === undefined) {
		            this.selectaSpots[tile.x + "," + tile.y] = tile.pos();
				}
		        var spotTile = Vars.world.tile(this.selectaSpots[tile.x + "," + tile.y]);
				if (spotTile.block() != Blocks.air && spotTile.getTeam() != tile.getTeam()) entity.target = spotTile 
				else entity.target = Units.closestTarget(tile.getTeam(), spotTile.drawx(), spotTile.drawy(), selectaSpotsRadius, boolf((e) => {return !e.isDead() && !e.isFlying()}));
			}
	    }
    },
	shoot(tile, ammo){
		/*const entity = tile.ent();

		entity.recoil = recoil;
		entity.heat = 1;
		
        const type = this.peekAmmo(tile);

		this.tr.trns(entity.rotation, this.size * Vars.tilesize / 2);
		const predict = Predict.intercept(tile, entity.target, type.speed);

		var dst = entity.dst(predict.x, predict.y);
		var maxTraveled = type.lifetime * type.speed;

		for(var i = 0; i < this.shots; i++){
			Bullet.create(ammo, tile.entity, tile.getTeam(), tile.drawx() + tr.x, tile.drawy() + tr.y,
			entity.rotation + Mathf.range(this.inaccuracy + type.inaccuracy), 1 + Mathf.range(this.velocityInaccuracy), (dst / maxTraveled));
		}

		this.effects(tile);
		this.useAmmo(tile);
		
		*/
        const entity = tile.ent();
        const len = this.size / 2 * Vars.tilesize;
        const trx1 = tile.drawx() + Angles.trnsx(entity.rotation, len)
        const try1 = tile.drawy() + Angles.trnsy(entity.rotation, len)
        radiusMulp = 0.05;
        const predict = Predict.intercept(tile, entity.target, 3 * (1 + realSpeed));
        const dst = Mathf.dst(tile.drawx(), tile.drawy(),predict.x, predict.y);
        const maxTraveled = 45 * 3 * (1 + realSpeed);
        for(var i = 0; i < this.shots; i++){
            Bullet.create(腐化, tile.entity, tile.getTeam(), trx1, try1,entity.rotation + Mathf.range(this.inaccuracy - inaccuracyChange),1 + realSpeed + Mathf.range(this.velocityInaccuracy), (dst / maxTraveled));
        }
        Effects.effect(this.shootEffect, trx1, try1, entity.rotation);
        Effects.effect(this.smokeEffect, trx1, try1, entity.rotation);
		Sounds.explosionbig.at(tile,Mathf.random(0.9, 1.1));
        Effects.shake(this.shootShake, this.shootShake, tile.entity);
        entity.recoil = this.recoil;
        entity.heat = 1;
        entity.totalAmmo = entity.totalAmmo - this.ammoPerShot;
    },
    drawLayer(tile){
    	const entity = tile.ent();
        const trx1 = tile.drawx() + Angles.trnsx(entity.rotation,  -entity.recoil * 3)
        const try1 = tile.drawy() + Angles.trnsy(entity.rotation, -entity.recoil * 3)
        Draw.rect(Core.atlas.find(this.name + "-eject-2"), trx1, try1, entity.rotation - 90);
        this.super$drawLayer(tile)
        Draw.rect(Core.atlas.find(this.name + "-eject"), trx1, try1, entity.rotation - 90);
    }
});
腐朽.spread = 40;
腐朽.ammoPerShot = 3;
腐朽.inaccuracy = 4;
腐朽.selectaSpots = {};
腐朽.ammo(darkenergy,腐化);
腐朽.shots = 3;
腐朽.shootEffect = newEffect(40, e => {
	Draw.color(Color.valueOf("FFAB90"));
    Drawf.tri(e.x, e.y, 10, 120 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 10, 120 * e.fout(), e.rotation + 270);
});
腐朽.smokeEffect = newEffect(40, e => {
	Draw.color(Color.valueOf("FFAB90"));
    Drawf.tri(e.x, e.y, 7, 100 * e.fout(), e.rotation + 45 + Time.time() * 5.5);
    Drawf.tri(e.x, e.y, 7, 100 * e.fout(), e.rotation + 135 + Time.time() * 5.5);
    Drawf.tri(e.x, e.y, 7, 100 * e.fout(), e.rotation + 225 + Time.time() * 5.5);
    Drawf.tri(e.x, e.y, 7, 100 * e.fout(), e.rotation + 315 + Time.time() * 5.5);
    const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2.5);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() *  18);
    }}) 
    Angles.randLenVectors(e.id, 30, 100 * e.fin(), e.rotation, 12.5 ,d);
    Lines.stroke(e.fout() * 3); 
    Lines.circle(e.x, e.y, e.fin() * 40); 
    Fill.circle(e.x, e.y, e.fout() * 14);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 7);
    
});