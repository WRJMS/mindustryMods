

const 脉冲钛 = extend(BasicBulletType,{})
脉冲钛.speed = 6,
脉冲钛.damage = 35,
脉冲钛.knockback =0.2,
脉冲钛.bulletWidth = 8,
脉冲钛.bulletHeight = 16,
脉冲钛.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("#696AFF"),Color.valueOf("#a5b8fa"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
脉冲钛.smokeEffect = newEffect(25,e => {
	
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
       
        });
        
脉冲钛.ammoMultiplier = 3,
脉冲钛.lifetime =48,
脉冲钛.backColor = Color.valueOf("#696AFF"),
脉冲钛.frontColor = Color.valueOf("a5b8fa"),
脉冲钛.despawnEffect = newEffect(10,e => {
    
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            
            Angles.randLenVectors(e.id, 6, 1 + e.fin() * 20,d);
       
        });
        
脉冲钛.hitEffect = newEffect(10,e => {
    
	Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("696AFF"),Color.valueOf("a5b8fa"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            
            Angles.randLenVectors(e.id, 6, 1 + e.fin() * 20,d);
       
        });
        
const 脉冲塑钢分裂 = extend(BasicBulletType,{})
脉冲塑钢分裂.speed = 2,
脉冲塑钢分裂.splashDamageRadius = 10,
脉冲塑钢分裂.splashDamage = 5,
脉冲塑钢分裂.bulletWidth = 10,
脉冲塑钢分裂.bulletHeight = 10,
脉冲塑钢分裂.bulletShrink = 1,
脉冲塑钢分裂.lifetime =15,
脉冲塑钢分裂.backColor = Color.valueOf("d7d77f"),
脉冲塑钢分裂.frontColor = Color.valueOf("fef8c4"),
脉冲塑钢分裂.despawnEffect = Fx.none,
脉冲塑钢分裂.hitEffect = Fx.none

const 脉冲塑钢 = extend(BasicBulletType,{})
脉冲塑钢.speed = 5,
脉冲塑钢.damage = 15,
脉冲塑钢.splashDamageRadius = 25,
脉冲塑钢.splashDamage = 30,
脉冲塑钢.knockback =0.4,
脉冲塑钢.bulletWidth = 8,
脉冲塑钢.bulletHeight = 16,
脉冲塑钢.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("#d7d77f"),Color.valueOf("#fef8c4"),e.fin());
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 6, 1 + 40 * e.fin(), e.rotation, 30,d);
});
脉冲塑钢.ammoMultiplier = 3,
脉冲塑钢.lifetime =48,
脉冲塑钢.backColor = Color.valueOf("d7d77f"),
脉冲塑钢.frontColor = Color.valueOf("fef8c4"),
脉冲塑钢.fragBullets = 5,
脉冲塑钢.fragBullet = 脉冲塑钢分裂,

脉冲塑钢.smokeEffect = newEffect(25,e => {
	
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("d7d77f"),Color.valueOf("fef8c4"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 3, 1 + e.fin() * 20,d);
        });

脉冲塑钢.hitEffect = newEffect(13,e => {
    
	const d = new Floatc2({get(x,y){
                Draw.color(Color.valueOf("d7d77f"),Color.valueOf("fef8c4"),e.fin());
                Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 2, 45);
            }})
            Angles.randLenVectors(e.id, 6, 1 + e.fin() * 25,d);
        });
        
        

const 脉冲近防炮= extendContent(BurstTurret,"脉冲近防炮",{});
脉冲近防炮.ammo(Items.titanium,脉冲钛,Items.plastanium,脉冲塑钢);
脉冲近防炮.ammoUseEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("#cde6ff"),Color.valueOf("#B4E6FF"),e.fin());
	Lines.stroke(e.fin() * 2.25);
    Lines.circle(e.x, e.y, e.fout() * 56);
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 0.425);
    }}) 
    Angles.randLenVectors(e.id, 20, 60 * e.fin(), e.rotation, 360,d);
             });
             
             
         