PlayerJumpDebug = extendContent(Block, "se-coremover", {
	buildConfiguration(tile,table){
		const entity = tile.ent();
		const tileRange = 2
		table.addImageButton(Icon.hammer, Styles.clearTransi, run(() => {
			Geometry.circle(tile.x, tile.y, tileRange + 1, new Intc2(){get: (x, y) => {
				const other = Vars.world.ltile(x, y);
				if(other != null){
					if(other.block() == ItemsLoader){
						Damage.damage(Team.derelict,other.drawx(), other.drawy(), 8, 100000);
						other.entity.kill();
						//entity.kill();
					}
				}
			}});
		})).size(50)
	},
	drawConfigure(tile){
		Drawf.circles(tile.drawx(), tile.drawy(), 14, Pal.accent);
	}
});
PlayerJumpDebug.size = 1;
PlayerJumpDebug.configurable = true;

const airRaidAttack = newEffect(20, e => {
	Draw.color(Color.valueOf("f0ffba"), Color.valueOf("F0FFC5"),e.fin());
	Lines.stroke(e.fslope() * 3); 
	const d = new Floatc2({get(x, y){
		Lines.poly(e.x + x, e.y + y, 6, 4 * e.fout() + 4);
	}})
	Angles.randLenVectors(e.id, 2, 32 * e.fout(), 0, 360,d);
});

const ItemsLoader = extendContent(CoreBlock, "outCore-itemsLoader", {
	blockpos: {},
	acceptItem(item, tile, source){
		return true;
	},
	handleBulletHit(entity, bullet){
		
		const tile = entity.getTile();
		if(entity.power.status > 0.8){
			bullet.scaleTime(150);
			const ang = bullet.rot() + 180;
			const trx1 = Angles.trnsx(ang, 20);
			const try1 = Angles.trnsy(ang, 20);
			Effects.effect(airRaidAttack,Color.valueOf("#ffffff75"), tile.drawx() + trx1, tile.drawy() + try1,0);
			entity.damage(bullet.damage() * 0.45);
		}else entity.damage(bullet.damage());
		//bullet.resetOwner(entity, entity.getTeam());
        
     //   bullet.deflect();
        
        
        
        
        
        //this.consumes.power(bullet.damage() * 25);
	},
	load(){
		this.super$load();
		Events.on(EventType.WorldLoadEvent, run(event => {
			this.blockpos = {};
		}));
	},
	canBreak(tile){
		return false;
	},
	update(tile){
		const entity = tile.ent();
		this.blockpos[tile.getTeamID()] = tile.pos();
		this.super$update(tile);
		
	},
	removed(tile){
		if(this.blockpos[tile.getTeamID()] == tile.pos()){
			delete this.blockpos[tile.getTeamID()];
		}
		//this.super$removed(tile);
	},
	onDestroyed(tile){
		if(this.blockpos[tile.getTeamID()] == tile.pos()){
			delete this.blockpos[tile.getTeamID()];
		}
		//this.super$onDestroyed(tile);
	},
	canPlaceOn(tile){
		if(Vars.headless){
			return true;
		}else{
			return !(Vars.player.getTeam().id in this.blockpos);
		}
	},
	drawLayer(tile){
		this.super$drawLayer(tile);
		const entity = tile.ent();
		Draw.alpha(entity.power.status);
		Draw.rect(Core.atlas.find(this.name + "-shield-" + 1), tile.drawx(), tile.drawy(), Time.time() * 2 * entity.power.status);
		Draw.rect(Core.atlas.find(this.name + "-shield-" + 2), tile.drawx(), tile.drawy(), -Time.time() * 2 * entity.power.status);
	}
});
ItemsLoader.size = 3;
ItemsLoader.layer = Layer.power;
ItemsLoader.update = true;
ItemsLoader.consumes.power(100);