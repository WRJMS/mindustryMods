

const largeSiliconFactory = extendContent(GenericSmelter,"大型硅厂",{
	draw(tile){
		const entity = tile.ent();
		Draw.rect(Core.atlas.find(this.name + "-bottom"),tile.drawx(),tile.drawy());
		Draw.color(tile.entity.liquids.current().color);
		Draw.alpha(tile.entity.liquids.total() / this.liquidCapacity);
		Draw.rect(Core.atlas.find(this.name + "-liquid"), tile.drawx(), tile.drawy());
		Draw.color();
		Draw.rect(Core.atlas.find(this.name + "-rotator"),tile.drawx(),tile.drawy(),45 + tile.ent().totalProgress * 1.25);
		Draw.rect(this.region,tile.drawx(),tile.drawy());
		Draw.color();
		if(entity.warmup > 0 && this.flameColor.a > 0.001){
			var g = 0.3;
			var r = 0.06;
			var cr = Mathf.random(0.1); 

			Draw.alpha(((1 - g) + Mathf.absin(Time.time(), 8, g) + Mathf.random(r) - r) * entity.warmup);

			Draw.tint(this.flameColor);
			Fill.circle(tile.drawx(), tile.drawy(), 5 + Mathf.absin(Time.time(), 5, 2) + cr);
			Draw.color(1, 1, 1, entity.warmup);
			Fill.circle(tile.drawx(), tile.drawy(), 3.9 + Mathf.absin(Time.time(), 5, 1) + cr);

			Draw.color();
		}
	},
	generateIcons(){
		return [
			Core.atlas.find(this.name + "-bottom"),
			Core.atlas.find(this.name),
		];
	}
});
largeSiliconFactory.craftEffect = Fx.smeltsmoke;
largeSiliconFactory.flameColor = Color.valueOf("ffef99");