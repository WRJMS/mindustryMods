const shield = newEffect(2, e => {
	Draw.color(Color.valueOf("#88C0FF"),Color.valueOf("#D3F0FF"),e.fin());
    Lines.stroke(1.125 + Mathf.absin(Time.time(), 4, 0.75) + Mathf.random(0.075));
    Lines.circle(e.x, e.y, 14 + Mathf.absin(Time.time(), 4, 8) + Mathf.random(0.075));
});

const 尾迹镭射 = newEffect(45,e => {
	Draw.color(Color.valueOf("#A0CCFF"));
    Fill.circle(e.x, e.y, e.fout() * 4);
    Draw.color(Color.valueOf("#DBEDFF"));
    Fill.circle(e.x, e.y, e.fout() * 2);
    
        });


const 镭射 = extend(BasicBulletType,{
	update(b){
        if(b.timer.get(1,1)){
        Effects.effect(尾迹镭射,Color.valueOf("dd753800"), b.x, b.y, b.rot());
        }
        },
	draw(b){
       Draw.color(Color.valueOf("A0CCFF"));
       Fill.circle(b.x, b.y, 4.1);
       Draw.color(Color.valueOf("DBEDFF"));
       Fill.circle(b.x, b.y, 2.0725);
       
        },
hit(b){
for(var i = 0; i < 2; i++){
            Lightning.create(b.getTeam(),Color.valueOf("A0CCFF"), 22, b.x, b.y, b.rot() + Mathf.random(-25, 25) - 180 , 45);         
        }
        }
});
镭射.splashDamage = 40;
镭射.bulletSprite = "新视界-波束子弹";
镭射.damage = 45;
镭射.splashDamageRadius = 48;
镭射.bulletWidth = 8
镭射.bulletHeight = 45
镭射.speed = 6;
镭射.homingPower = 1;
镭射.shootEffect = newEffect(12,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#DBEDFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7.5 + 0.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+38 * e.fin(),e.rotation, 30,d);
             });
镭射.backColor = Color.valueOf("#A0CCFF");
镭射.smokeEffect = newEffect(18,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#DBEDFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7.5 + 0.5);
	}})
             Angles.randLenVectors(e.id, 8, 1+38 * e.fin(),e.rotation, 30,d);
             });
镭射.frontColor = Color.valueOf("#A0CCFF");
镭射.trailColor = Color.valueOf("#A0CCFF");
镭射.hitEffect = newEffect(16,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#DBEDFF"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 7 + 4);
	Lines.stroke(e.fout() * 1.25);
    Lines.circle(e.x, e.y, e.fin() * 24);
    Lines.stroke(e.fout() * 3);
    Lines.circle(e.x, e.y, e.fin() * 57.5);
             }})
             Angles.randLenVectors(e.id, 7, 1 + 23 * e.fin(),e.rotation, 360,d);
             });
镭射.despawnEffect = Fx.hitLancer;
镭射.hitSize = 0;
镭射.lifetime = 60;
镭射.pierce = false;

const 镭射炮 = extendContent(Weapon,"镭射炮",{

})
镭射炮.bullet = 镭射;
镭射炮.name = 镭射炮;
镭射炮.length = 4;
镭射炮.shots = 4;
镭射炮.velocityRnd = 0;
镭射炮.shotDelay = 5;
镭射炮.spacing = 0.25;
镭射炮.recoil = 1.5;
镭射炮.width = 7.25;
镭射炮.reload = 85;
镭射炮.inaccuracy = 1.75;
镭射炮.alternate = true;
//镭射炮.range = 340;
镭射炮.ejectEffect = newEffect(16,e => {
	Draw.color(Color.valueOf("#A0CCFF"),Color.valueOf("#DBEDFF"),e.fin());
	Lines.stroke(e.fin() * 1.25);
    Lines.circle(e.x, e.y, e.fout() * 22);
             });
镭射炮.shootSound = Sounds.laser;

const 掠夺者 = extendContent(Mech,"掠夺者",{
	updateAlt(player){
		if(player.boostHeat >= 0.1) return;
		this.hitsize = 120
		
},
	load(){
		//this.super$load();
		this.weapon.load();
        if(!this.flying){
            this.legRegion = Core.atlas.find(this.name + "-leg");
            this.baseRegion = Core.atlas.find(this.name + "-base");
        }
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("新视界-镭射炮");
	},
	draw(player){
		this.super$draw(player);
		if(player.boostHeat >= 0.1) return;
		Shaders.build.progress = 1 - player.boostHeat;
		Shaders.build.region = Core.atlas.find(this.name + "-shield");
		Shaders.build.time = Time.time() / 20;
		Shaders.build.color.set(Color.valueOf("#A0CCFF")).a = 1 - player.boostHeat;
		Draw.shader(Shaders.build);
        Draw.rect(Core.atlas.find(this.name + "-shield"), player.x, player.y, Time.time() * 3);
        Draw.shader();
            
        Shaders.build.progress = 1 - player.boostHeat;
		Shaders.build.region = Core.atlas.find(this.name + "-shield2");
		Shaders.build.time = Time.time() / 20;
		Shaders.build.color.set(Color.valueOf("#A0CCFF")).a = 1 - player.boostHeat;
		Draw.shader(Shaders.build);
        Draw.rect(Core.atlas.find(this.name + "-shield2"), player.x, player.y, 0 - Time.time() * 3);
		Draw.shader();
	},
	getExtraArmor(player){
                return ( 1 - player.boostHeat) * 45;
            },
            updateAlt(player){
                player.healBy(Time.delta() * 0.3);
            },
	spreadX(player){
		return player.boostHeat * -2;
	}
})
掠夺者.weapon = 镭射炮;
掠夺者.weaponOffsetX = 5.75;
掠夺者.health = 420,
掠夺者.mass = 15,
掠夺者.speed = 0.18,
掠夺者.boostSpeed = 0.35,
掠夺者.drag = 0.15,
掠夺者.buildPower = 2,
掠夺者.itemCapacity = 100,
掠夺者.engineOffset = 5.5,
掠夺者.engineSize = 2.75,
掠夺者.engineColor = Color.valueOf("#74A9FF"),
掠夺者.flying = false,
掠夺者.drawCell = true,
掠夺者.drillPower = 4,
掠夺者.mineSpeed = 4,
掠夺者.weaponOffsetY = -0.75