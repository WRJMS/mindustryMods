
const 修复炮 = extendContent(Weapon,"修复炮",{})
修复炮.bullet = Bullets.healBullet;
修复炮.name = 修复炮;
修复炮.length = 9;
修复炮.shootEffect = Fx.shootHeal;
修复炮.smokeEffect = Fx.hitLaser;
修复炮.shots = 5;
修复炮.velocityRnd = 0;
修复炮.shotDelay = 4;
修复炮.roundrobin = false
修复炮.spacing = 0.25;
修复炮.recoil = 1.25;
修复炮.width = 3.45;
修复炮.reload = 32;
修复炮.inaccuracy = 1;
修复炮.alternate = false;
//修复炮.range = 340;
修复炮.ejectEffect = Fx.none
const liv = extendContent(Mech,"liv",{
	updateAlt(player){
		this.super$updateAlt(player);
		if(player.timer.get(Player.timerAbility, 90)){
			Units.nearby(player.getTeam(), player.getX(),player.getY(), 100, cons(unit => {
				if(unit.health < unit.maxHealth()){
					Effects.effect(Fx.heal, unit);
					Effects.effect(Fx.healWave, player);
					unit.healBy(50);
				}
			}))
		}
	},
	load(){
		//this.super$load();
		this.weapon.load();
		this.region = Core.atlas.find(this.name);
		this.weapon.region = Core.atlas.find("新视界-修复炮");
	}
})
liv.weapon = 修复炮;
liv.weaponOffsetX = 4.5;
liv.health = 300,
liv.mass = 5,
liv.speed = 0.275,

liv.boostSpeed = 0.5,
liv.drag = 0.05,
liv.buildPower = 5,
liv.itemCapacity = 80,
liv.engineOffset = 6.325,
liv.engineSize = 3.2625,
liv.engineColor = Pal.heal,
liv.flying = true,
liv.canHeal = true,
liv.drillPower = 5,
liv.mineSpeed = 4,
liv.weaponOffsetY = 7.5