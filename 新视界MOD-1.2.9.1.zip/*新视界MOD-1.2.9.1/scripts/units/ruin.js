const effectColor = Color.valueOf("FFAB90");
const effectColor2 = Color.valueOf("ffffff");
const colorsRuin = [Color.valueOf("FFAB9055"), effectColor, effectColor2];
const tscalesRuin = [2, 1.5, 1, 0.825];
const lenscalesRuin = [1, 1.25, 1.4, 1.45];
const lengthRuin = 480;
const ruinLaser = extend(BasicBulletType,{
	range(){
		return lengthRuin;
	},
	init(b){
		if (b == null) return;
		Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), this.range());
	},
	draw(b){
		const f = Mathf.curve(b.fin(), 0, 0.2);
		const baseLen = lengthRuin * f;
		for(var s = 0; s < 3; s++){
			Draw.color(colorsRuin[s]);
			for(var i = 0; i < tscalesRuin.length; i++){
				Lines.stroke(5 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscalesRuin[i]);
				Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscalesRuin[i]);
			}
		}
		const trnsLen = new Vec2();
		trnsLen.trns(b.rot(), baseLen * lenscalesRuin[lenscalesRuin.length - 1]);
		Vars.renderer.lights.line(b.x, b.y, b.x + trnsLen.x, b.y + trnsLen.y);
		Draw.reset();
	}
})
ruinLaser.damage = 1200;
ruinLaser.speed = 0.000001;
ruinLaser.hitEffect = newEffect(45, e => {
    Draw.color(effectColor, effectColor2, 0.5 * e.fin());
	const c = new Floatc2({get(x, y){
		Fill.circle(e.x + x, e.y + y, e.fout() * 6);
	}}) 
    Angles.randLenVectors(e.id, 3, 40 * e.fin(), e.rotation, 360,c);
});
ruinLaser.despawnEffect = Fx.none;
ruinLaser.collidesTiles = false;
ruinLaser.pierce = true;
ruinLaser.hitSize = 250;
ruinLaser.drawSize = 250;
ruinLaser.bulletWidth = 60;
ruinLaser.lifetime = 45;
ruinLaser.keepVelocity = false;
ruinLaser.drawSize = lengthRuin * 2.5;
ruinLaser.shootEffect = newEffect(60, e => {
    Draw.color(effectColor);
    Fill.circle(e.x, e.y, e.fout() * 8);
    Draw.color(effectColor2);
    Fill.circle(e.x, e.y, e.fout() * 5);
});
ruinLaser.smokeEffect = newEffect(30, e => {
    Draw.color(effectColor, effectColor2, 0.5 * e.fin());
	Lines.stroke(e.fout() * 3);
	Lines.circle(e.x, e.y, e.fin() * 100);
    const d = new Floatc2({get(x, y){
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 28, 1 + 120 * e.fin(), e.rotation, 30,d);
    const c = new Floatc2({get(x, y){
        Fill.circle(e.x + x, e.y + y, e.fout() * 4.25);
    }}) 
    Angles.randLenVectors(e.id, 20, 1 + 40 * e.fin(), e.rotation, 360,c);
});


const ruinWeapon = extend(Weapon, {});
ruinWeapon.reload = 45;
ruinWeapon.bullet = ruinLaser;
ruinWeapon.recoil = 0;
ruinWeapon.length = 20;
ruinWeapon.width = 0;
ruinWeapon.shots = 1;
ruinWeapon.shootSound = Sounds.laser;
ruinWeapon.inaccuracy = 0;
ruinWeapon.ejectEffect = Fx.shootBigSmoke2;

const ruin = extendContent(UnitType, "坍缩者", {});
ruin.create(prov( () => extend(HoverUnit)));
ruin.constructor = prov( () => {
	const unitRuin = extend(HoverUnit,{
		write(stream){
			this.super$write(stream);
		},
		read(stream, revision){
			this.super$read(stream, revision);
		}
	});
	return unitRuin;
});
ruin.maxVelocity = 1.27;
ruin.weapon = ruinWeapon;
ruin.hitsize = 8;
ruin.mass = 10000;
ruin.speed = 0.11;
ruin.drag = 0.2;
ruin.flying = true;
ruin.hitsize = 20;
ruin.shootCone = 30;
ruin.health = 65000;
ruin.rotateWeapon = false;
ruin.mass = 1000;
ruin.engineOffset = 36;
ruin.engineSize = 10;
ruin.rotatespeed = 0.03;
ruin.baseRotateSpeed = 0.02;
ruin.range = lengthRuin - 80;
ruin.attackLength = lengthRuin - 80;















