const 尾迹磁轨 = newEffect(25,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
    Drawf.tri(e.x, e.y, 5 * e.fout(), 85 * e.fout(), e.rotation - 180);
    Drawf.tri(e.x, e.y, 5 * e.fout(), 25 * e.fout(), e.rotation);
        });

const 磁轨子弹 = extend(MissileBulletType,{
update(b){
        if(b.timer.get(1,1)){
            Effects.effect(尾迹磁轨,Color.valueOf("C2FF8300"), b.x, b.y, b.rot());
        }
        },
        hit(b){
        	for (var i = 0; i < Mathf.random(5); i++) {
        	Lightning.create(b.getTeam(),Color.valueOf("abdbff"), 50, b.x, b.y, Mathf.random(360), 40);     
}    
Effects.effect(newEffect(15,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 45);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 135);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 225);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 315);
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, e.fin() * 50);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 8 + 1);
             }})
             Angles.randLenVectors(e.id, 10, 50 * e.fin(),e.rotation, 360,d);
             }),Color.valueOf("dd753800"), b.x, b.y, b.rot());
    }
});
磁轨子弹.splashDamage = 45;
磁轨子弹.bulletSprite = "新视界-冲击子弹";
磁轨子弹.damage = 500;
磁轨子弹.splashDamageRadius = 60;
磁轨子弹.bulletWidth = 18;
磁轨子弹.bulletHeight = 70;
磁轨子弹.speed = 14;
磁轨子弹.homingPower = 0;
磁轨子弹.backColor = Color.valueOf("#abdbff");
磁轨子弹.frontColor = Color.valueOf("#f0f8ff");
磁轨子弹.trailColor = Color.valueOf("#abdbff");
磁轨子弹.hitEffect = newEffect(15,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 45);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 135);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 225);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), 315);
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, e.fin() * 50);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 8 + 1);
             }})
             Angles.randLenVectors(e.id, 10, 50 * e.fin(),e.rotation, 360,d);
             });
磁轨子弹.despawnEffect = Fx.shockwave;
磁轨子弹.shootEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("#abdbff"),Color.valueOf("#f0f8ff"),e.fin());
	Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation + 270);
	
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 10 + 2);
	}})
             Angles.randLenVectors(e.id, 10, 60 * e.fin(),e.rotation, 45,d);
             });
磁轨子弹.smokeEffect = newEffect(8,e => {
	Draw.color(Color.valueOf("#FFCC89"),Color.valueOf("#f0f8ff"),e.fin());
	Lines.stroke(e.fin() * 1.65);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 15 + 2);
	}})
             Angles.randLenVectors(e.id, 20, 75 * e.fin(),e.rotation, 0,d);
             });
磁轨子弹.hitSize = 4;
磁轨子弹.lifetime = 50;
磁轨子弹.pierce = true;

const 致密子弹 = extend(MissileBulletType,{
update(b){
        if (b.time()<0.001) {
            Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), 440);
        }
    },
    draw(b){}
});
致密子弹.damage = 1000;
致密子弹.inaccuracy = 1;
致密子弹.bulletWidth = 0;
致密子弹.bulletHeight = 0;
致密子弹.speed = 0.0001;
致密子弹.homingPower = 0;
致密子弹.hitEffect = newEffect(15,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation - 210);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation - 150);
    Lines.stroke(e.fout() * 2);
    Lines.circle(e.x, e.y, e.fin() * 50);
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 8 + 1);
             }})
             Angles.randLenVectors(e.id, 10, 50 * e.fin(),e.rotation, 360,d);
             });
致密子弹.despawnEffect = Fx.none;
致密子弹.shootEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
	Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation + 90);
    Drawf.tri(e.x, e.y, 7, 80 * e.fout(), e.rotation + 270);
	
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 10 + 2);
	}})
             Angles.randLenVectors(e.id, 10, 60 * e.fin(),e.rotation, 45,d);
             });
致密子弹.smokeEffect = newEffect(45,e => {
	Lines.stroke(e.fout() * 2.9725);
	Draw.color(Color.valueOf("dd7538"),Color.valueOf("FFF4BC"),e.fin());
	const d = new Floatc2({get(x, y){
	Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 17 + 2);
	}})
             Angles.randLenVectors(e.id, 10, 440 * e.fin() / 2 + 460 / 2,e.rotation, 0,d);
});
致密子弹.hitSize = 4;
致密子弹.lifetime = 1;
致密子弹.pierce = true;
const 磁轨炮 = extendContent(BurstTurret,"磁轨炮",{});
磁轨炮.ammo(铱板,磁轨子弹,致密合金,致密子弹);
磁轨炮.ammoUseEffect = Fx.shellEjectBig;
磁轨炮.range = 440;







const laserExp = newEffect(60, e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("ffffff"),e.fin());
	Lines.stroke(e.fout() * 4.5);
	Lines.circle(e.x, e.y, e.fin() * 80);
	Lines.stroke(e.fout() * 2.75);
	Lines.circle(e.x, e.y, e.fin() * 45);
	Lines.circle(e.x, e.y, e.fin() * 45);
	Fill.circle(e.x, e.y, e.fout() * 20);
	Fill.circle(e.x, e.y, e.fout() * 12);
	const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2);
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
	}}) 
	Angles.randLenVectors(e.id, 38, 1 + 60 * e.fin(), e.rotation, 360,d);
});

const colors照 = [Color.valueOf("FFF98C55"), Color.valueOf("FFF98C"), Color.valueOf("ffffff")];
const tscales照 = [2, 2, 2, 2];
const lenscales照 = [1, 1, 1, 1];
const length照 = 280;
const 照射激光 = extend(ArtilleryBulletType,{
	range(){
		return length照;
	},
	init(b){
		if (b == null) return;
		Damage.collideLine(b, b.getTeam(), this.hitEffect, b.x, b.y, b.rot(), this.range());
		Time.run(12, run( () => {
			Effects.effect(laserExp,Color.valueOf("ffffff00"), b.x + Angles.trnsx(b.rot(), this.range()), b.y + Angles.trnsy(b.rot(), this.range()), b.rot()); 
		}));
	},
	draw(b){
		const f = Mathf.curve(b.fin(), 0, 0.525);
		const baseLen = length照 * f;

		for(var s = 0; s < 3; s++){
			Draw.color(colors照[s]);
			for(var i = 0; i < tscales照.length; i++){
				Lines.stroke(5.5 * b.fout() * (s == 0 ? 1.5 : s == 1 ? 1 : 0.25) * tscales照[i]);
				Lines.lineAngle(b.x, b.y, b.rot(), baseLen * lenscales照[i]);
			}
		}
		Draw.reset();
	}
})
照射激光.damage = 400;
照射激光.speed = 0.0001;
照射激光.hitEffect = Fx.none
照射激光.despawnEffect = Fx.none;
照射激光.hitSize = 250;
照射激光.drawSize = length照 * 2.5;
照射激光.bulletWidth = 60;
照射激光.lifetime = 45;
照射激光.pierce = false;
照射激光.collidesTiles = false;
照射激光.collides = false;
照射激光.collidesAir = false;

const linkLen = 320;

const 光球 = extend(BasicBulletType,{
	update(b){
		if(b.timer.get(1,0)){
			Effects.effect(newEffect(60,e => {
				Draw.color(Color.valueOf("#FFF98C"));
				Fill.circle(e.x, e.y, e.fout() * 10);
				Draw.color(Color.valueOf("#ffffff"));
				Fill.circle(e.x, e.y, e.fout() * 6);
			}),Color.valueOf("dd753800"), b.x, b.y, b.rot());
		};
		if(b.timer.get(2,7)){
			Lightning.create(b.getTeam(),Color.valueOf("FFF98C"), 150, b.x,b.y,Mathf.random(360), Mathf.random(8,12)); 
			Units.nearbyEnemies(b.getTeam(), b.x - linkLen / 2, b.y - linkLen / 2, linkLen, linkLen, cons(unit => {
				Lightning.create(b.getTeam(),Color.valueOf("FFF98C"), 85, unit.x,unit.y,Mathf.random(360), Mathf.random(6, 10)); 
			}));
		};
	},
	draw(b){
		Units.nearbyEnemies(b.getTeam(), b.x - linkLen / 2, b.y - linkLen / 2, linkLen, linkLen, cons(unit => {
			Draw.color(Color.valueOf("FFF98C"));
			Drawf.laser(Core.atlas.find("新视界-minelaser"), Core.atlas.find("新视界-minelaser-end"),b.x, b.y, unit.x, unit.y, 1);
		}))
		Draw.color(Color.valueOf("FFF98C"));
		Fill.circle(b.x, b.y, 10);
		Draw.color(Color.valueOf("ffffff"));
		Fill.circle(b.x, b.y, 6);
	},
	hit(b){
		Effects.effect(newEffect(60, e => {
			Draw.color(Color.valueOf("#FFF98C"));
			Fill.circle(e.x, e.y, e.fout() * 40);
			Lines.stroke(e.fout() * 4.5);
			Lines.circle(e.x, e.y, e.fin() * 80);
			Lines.stroke(e.fout() * 2.75);
			Lines.circle(e.x, e.y, e.fin() * 45);
			const d = new Floatc2({get(x, y){
				Lines.stroke(e.fout() * 2);
				Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
			}})
			Angles.randLenVectors(e.id, 45, 1 + 65 * e.fin(), e.rotation, 360,d);
		}),Color.valueOf("ffffff00"), b.x, b.y, b.rot()); 
		
		for(var i = 0; i < 3; i++){
			Bullet.create(照射激光, b, b.x, b.y, Mathf.random(360));
		}
	},
	despawned(b){this.hit(b);}
})
光球.speed = 2.75;
光球.damage = 0;
光球.drawSize = linkLen * 2.5;
光球.splashDamageRadius = 40;
光球.splashDamage = 750;
光球.collidesTiles = true;
光球.pierce = false;
光球.collides = false;
光球.collidesAir = false;
光球.shootEffect = newEffect(12, e => {
    Draw.color(Color.valueOf("FFF98C"),Color.valueOf("ffffff"),e.fin());
    const d = new Floatc2({get(x, y){
    	Lines.stroke(e.fout() * 2.75);
    Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 10, 1 + 40 * e.fin(), e.rotation, 30,d);
});
光球.smokeEffect = newEffect(25,e => {
	Draw.color(Color.valueOf("FFF98C"),Color.valueOf("ffffff"),e.fin());
	const d = new Floatc2({get(x,y){
		Fill.square(e.x + x, e.y + y, 0.2 + e.fout() * 7, 45);
	}})
	Angles.randLenVectors(e.id, 7, 1 + e.fin() * 40,d);
	const c = new Floatc2({get(x, y){
		Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y),e.fslope() * 13 + 10);
	}}) 
	Lines.stroke(e.fout() * 2.725);
	Angles.randLenVectors(e.id, 9, 1+48 * e.fin(),e.rotation, 0,c);
}); 
光球.ammoMultiplier = 1;
光球.lifetime = 50;
光球.despawnEffect = newEffect(60, e => {
    Draw.color(Color.valueOf("#FFF98C"));
    Fill.circle(e.x, e.y, e.fout() * 40);
    Lines.stroke(e.fout() * 4.5);
    Lines.circle(e.x, e.y, e.fin() * 80);
    Lines.stroke(e.fout() * 2.75);
    Lines.circle(e.x, e.y, e.fin() * 45);
    const d = new Floatc2({get(x, y){
		Lines.stroke(e.fout() * 2);
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 12 + 1);
    }}) 
    Angles.randLenVectors(e.id, 45, 1 + 65 * e.fin(), e.rotation, 360,d);
    Draw.color(Color.valueOf("#ffffff"));
    Fill.circle(e.x, e.y, e.fout() * 25);
});
          

const 照射激光器 = extendContent(ArtilleryTurret,"照射激光器",{
})
照射激光器.ammo(darkenergy,光球);
照射激光器.shots = 1;
照射激光器.heatColor = Color.valueOf("#FFF98C");
照射激光器.velocityInaccuracy = 0.075;
照射激光器.ammoUseEffect = newEffect(20,e => {
	Draw.color(Color.valueOf("#FFF98C"),Color.valueOf("#ffffff"),e.fin());
	Lines.stroke(e.fin() * 2.25);
    Lines.circle(e.x, e.y, e.fout() * 56);
    const d = new Floatc2({get(x, y){
        Lines.lineAngle(e.x + x, e.y + y, Mathf.angle(x, y), e.fslope() * 8 + 0.425);
    }}) 
    Angles.randLenVectors(e.id, 20, 60 * e.fin(), e.rotation, 360,d);
});
